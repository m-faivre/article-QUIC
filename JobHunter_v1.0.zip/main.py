"""
JobHunter — Point d'entrée principal.
Lancement : python main.py
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

# 1. Base de données
from database.db_manager import init_db
init_db()

# 2. Qt
from PyQt6.QtWebEngineWidgets import QWebEngineView  # noqa: F401 — doit précéder QApplication
from PyQt6.QtWidgets import QApplication
from PyQt6.QtGui import QFont

# 3. Logger UI (doit être après QApplication)
app = QApplication(sys.argv)
app.setApplicationName("JobHunter")
app.setApplicationVersion("1.0.0")
app.setOrganizationName("JobHunter")

import utils.logger as log
log.init_ui_logging()          # ← signal Qt disponible dès ici
log.info(f"JobHunter démarré — Python {sys.version.split()[0]}")

# 4. Fenêtre principale
from ui.main_window import MainWindow

font = QFont("Segoe UI", 10)
app.setFont(font)

window = MainWindow()
window.show()

sys.exit(app.exec())
