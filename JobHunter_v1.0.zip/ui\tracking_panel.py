"""
Panneau de suivi des candidatures.

Features :
  - Barre de recherche (filtre temps-réel sur poste, entreprise, source, statut)
  - Tri par clic sur les en-têtes de colonne
  - Double-clic sur une cellule pour édition rapide (poste, entreprise, source, date)
  - Bouton ✏️ dans Actions pour ouvrir le dialogue d'édition complet
  - Stats tiles avec accent bar
"""
from PyQt6.QtCore import Qt, pyqtSignal, QTimer
from PyQt6.QtGui import QColor, QFont, QIcon
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QTableWidget, QTableWidgetItem, QHeaderView, QComboBox,
    QTextEdit, QDialog, QDialogButtonBox, QFrame, QMessageBox,
    QLineEdit,
)

import html as _html

import database.db_manager as db
from config import APPLICATION_STATUSES
from models.models import Application
from ui.styles import COLORS, STATUS_COLORS


def _esc(text: str) -> str:
    return _html.escape(str(text or ""), quote=True)


def _format_date_fr(iso_date: str) -> str:
    """Convertit une date ISO (YYYY-MM-DD...) en format FR (JJ/MM/AAAA)."""
    if not iso_date:
        return "—"
    try:
        from datetime import datetime
        dt = datetime.fromisoformat(iso_date.replace(" ", "T")[:19])
        return dt.strftime("%d/%m/%Y")
    except (ValueError, TypeError):
        return iso_date[:10] if iso_date else "—"


def _fr_to_iso(text: str) -> str | None:
    """Convertit JJ/MM/AAAA → YYYY-MM-DD. Retourne None si invalide."""
    import re
    m = re.match(r"^(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{4})$", text.strip())
    if not m:
        return None
    d, mo, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
    if not (1 <= d <= 31 and 1 <= mo <= 12 and 1900 <= y <= 2100):
        return None
    return f"{y:04d}-{mo:02d}-{d:02d}"


# Largeurs colonnes en pixels
_COL_WIDTHS = {
    0: 480,   # Poste
    1: 300,   # Entreprise
    2: 220,   # Source
    3: 200,   # Statut
    4: 230,   # Date envoi
    5: 200,   # Notes
    6: 280,   # Actions
}

_ROW_HEIGHT = 50

_MAX_NOTES_DISPLAY = 250   # troncature affichage colonne Notes

# Mapping colonne index → attribut Application pour le tri
_SORT_KEYS = {
    0: lambda a: (a.job_title or "").lower(),
    1: lambda a: (a.company or "").lower(),
    2: lambda a: (a.source or "").lower(),
    3: lambda a: (a.status or ""),
    4: lambda a: (a.sent_at or ""),            # ISO → tri naturel
    5: lambda a: (a.notes or "").lower(),
}

# Mapping colonne → champ Application pour l'édition inline
_COL_TO_FIELD = {
    0: "job_title",
    1: "company",
    2: "source",
    4: "sent_at",
}

# Style commun pour les boutons d'action dans la table
_BTN_STYLE = """
    QPushButton {{
        background-color: {bg};
        color: {fg};
        border: none;
        border-radius: 4px;
        padding: 2px 8px;
        font-size: 11px;
        font-weight: 600;
        min-height: 24px;
    }}
    QPushButton:hover {{
        background-color: {hover};
    }}
"""


class TrackingPanel(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._apps: list[Application] = []
        self._filtered: list[Application] = []
        self._search_text: str = ""
        self._sort_col: int = 4          # tri initial par date
        self._sort_asc: bool = False     # décroissant par défaut
        self._editing: bool = False      # empêche les refresh pendant l'édition
        self._build_ui()
        self.refresh()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # ── Header ──
        header = QWidget()
        header.setStyleSheet("background-color:#181825; border-bottom:1px solid #313244;")
        h_lay = QHBoxLayout(header)
        h_lay.setContentsMargins(16, 10, 16, 10)
        title = QLabel("📬  Suivi des candidatures")
        title.setStyleSheet("font-size:15px; font-weight:700; color:#cba6f7;")
        h_lay.addWidget(title)
        h_lay.addStretch()

        # Barre de recherche
        self._search_input = QLineEdit()
        self._search_input.setPlaceholderText("🔍  Rechercher (poste, entreprise, source…)")
        self._search_input.setClearButtonEnabled(True)
        self._search_input.setFixedWidth(320)
        self._search_input.setStyleSheet("""
            QLineEdit {
                background-color: #1e1e2e;
                border: 1px solid #45475a;
                border-radius: 6px;
                padding: 6px 10px;
                color: #cdd6f4;
                font-size: 12px;
            }
            QLineEdit:focus {
                border-color: #cba6f7;
            }
        """)
        self._search_timer = QTimer(self)
        self._search_timer.setSingleShot(True)
        self._search_timer.setInterval(200)
        self._search_timer.timeout.connect(self._apply_search)
        self._search_input.textChanged.connect(lambda: self._search_timer.start())
        h_lay.addWidget(self._search_input)
        h_lay.addSpacing(8)

        btn_refresh = QPushButton("🔄  Actualiser")
        btn_refresh.clicked.connect(self.refresh)
        h_lay.addWidget(btn_refresh)
        layout.addWidget(header)

        # ── Stats bar ──
        self._stats_bar = QWidget()
        self._stats_bar.setStyleSheet(
            "background-color:#181825; border-bottom:1px solid #313244;"
        )
        s_lay = QHBoxLayout(self._stats_bar)
        s_lay.setContentsMargins(16, 10, 16, 10)
        s_lay.setSpacing(16)
        self._stat_labels: dict[str, QLabel] = {}

        for status, (label, color) in APPLICATION_STATUSES.items():
            tile = QWidget()
            tile.setFixedHeight(48)
            tile.setMinimumWidth(100)
            tile.setStyleSheet(f"""
                QWidget {{
                    background-color: #1e1e2e;
                    border: 1px solid {color}55;
                    border-radius: 10px;
                    border-left: 4px solid {color};
                }}
            """)
            t_lay = QHBoxLayout(tile)
            t_lay.setContentsMargins(12, 4, 14, 4)
            t_lay.setSpacing(10)

            cnt = QLabel("0")
            cnt.setStyleSheet(
                f"font-size:20px; font-weight:800; color:{color}; border:none;"
            )
            cnt.setAlignment(Qt.AlignmentFlag.AlignCenter)
            cnt.setFixedWidth(32)

            lbl = QLabel(label)
            lbl.setStyleSheet(
                f"font-size:12px; font-weight:500; color:#a6adc8; border:none;"
            )

            t_lay.addWidget(cnt)
            t_lay.addWidget(lbl)

            self._stat_labels[status] = cnt
            s_lay.addWidget(tile)

        # Tile « Total »
        total_tile = QWidget()
        total_tile.setFixedHeight(48)
        total_tile.setMinimumWidth(100)
        total_tile.setStyleSheet("""
            QWidget {
                background-color: #1e1e2e;
                border: 1px solid #cdd6f455;
                border-radius: 10px;
                border-left: 4px solid #cdd6f4;
            }
        """)
        tt_lay = QHBoxLayout(total_tile)
        tt_lay.setContentsMargins(12, 4, 14, 4)
        tt_lay.setSpacing(10)

        self._total_count = QLabel("0")
        self._total_count.setStyleSheet(
            "font-size:20px; font-weight:800; color:#cdd6f4; border:none;"
        )
        self._total_count.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._total_count.setFixedWidth(32)

        total_lbl = QLabel("Total")
        total_lbl.setStyleSheet(
            "font-size:12px; font-weight:500; color:#a6adc8; border:none;"
        )

        tt_lay.addWidget(self._total_count)
        tt_lay.addWidget(total_lbl)
        s_lay.addWidget(total_tile)

        s_lay.addStretch()
        layout.addWidget(self._stats_bar)

        # ── Table ──
        self.table = QTableWidget()
        self.table.setColumnCount(7)
        self.table.setHorizontalHeaderLabels([
            "Poste", "Entreprise", "Source", "Statut",
            "Date envoi", "Notes", "Actions"
        ])
        hdr = self.table.horizontalHeader()
        hdr.setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        hdr.setStretchLastSection(False)
        for col, px in _COL_WIDTHS.items():
            hdr.resizeSection(col, px)
        # Tri par clic sur header
        hdr.setSortIndicatorShown(True)
        hdr.sectionClicked.connect(self._on_header_clicked)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.setAlternatingRowColors(False)
        # Désactiver le tri natif de QTableWidget (on gère nous-mêmes)
        self.table.setSortingEnabled(False)
        # Double-clic pour édition inline
        self.table.cellDoubleClicked.connect(self._on_cell_double_clicked)
        layout.addWidget(self.table, 1)

    # ─── Public API ───────────────────────────────────────────────────────────

    def refresh(self) -> None:
        if self._editing:
            return
        self._apps = db.get_applications()
        self._apply_filter()
        self._sort_apps()
        self._render()
        self._update_stats()

    def add_application(self, app: Application) -> None:
        db.save_application(app)
        self.refresh()

    # ─── Search / Filter ──────────────────────────────────────────────────────

    def _apply_search(self) -> None:
        """Appelé par le timer de recherche — filtre et re-rend."""
        self._search_text = self._search_input.text().strip().lower()
        self._apply_filter()
        self._sort_apps()
        self._render()

    def _apply_filter(self) -> None:
        """Filtre self._apps → self._filtered selon le texte de recherche."""
        q = self._search_text
        if not q:
            self._filtered = list(self._apps)
            return

        result = []
        for app in self._apps:
            # Chercher dans poste, entreprise, source, statut (label FR), notes
            status_label = APPLICATION_STATUSES.get(app.status, ("", ""))[0].lower()
            haystack = " ".join([
                (app.job_title or "").lower(),
                (app.company or "").lower(),
                (app.source or "").lower(),
                status_label,
                (app.location or "").lower(),
                (app.notes or "").lower(),
            ])
            if q in haystack:
                result.append(app)
        self._filtered = result

    # ─── Sorting ──────────────────────────────────────────────────────────────

    def _on_header_clicked(self, col: int) -> None:
        """Clic sur un header : trie par cette colonne (toggle asc/desc)."""
        if col == 6:
            return  # pas de tri sur Actions
        if col == self._sort_col:
            self._sort_asc = not self._sort_asc
        else:
            self._sort_col = col
            self._sort_asc = True  # premier clic = croissant
            # Exception : date → décroissant par défaut
            if col == 4:
                self._sort_asc = False

        # Mettre à jour l'indicateur visuel
        order = Qt.SortOrder.AscendingOrder if self._sort_asc else Qt.SortOrder.DescendingOrder
        self.table.horizontalHeader().setSortIndicator(col, order)

        self._sort_apps()
        self._render()

    def _sort_apps(self) -> None:
        """Trie self._filtered selon la colonne et l'ordre courants."""
        key_fn = _SORT_KEYS.get(self._sort_col)
        if key_fn:
            self._filtered.sort(key=key_fn, reverse=not self._sort_asc)

    # ─── Inline editing ───────────────────────────────────────────────────────

    def _on_cell_double_clicked(self, row: int, col: int) -> None:
        """Double-clic sur une cellule → édition inline si colonne éditable."""
        if col == 5:
            # Notes → ouvrir le dialogue de notes
            if 0 <= row < len(self._filtered):
                self._on_notes_clicked(self._filtered[row])
            return
        if col not in _COL_TO_FIELD and col != 3:
            return  # col 6 (Actions) n'est pas éditable inline

        if row < 0 or row >= len(self._filtered):
            return

        app = self._filtered[row]

        if col == 3:
            # Statut → on ne double-clique pas, le combo dans Actions le gère
            # Mais offrons quand même un choix rapide via dialogue
            self._edit_status_inline(app)
            return

        field = _COL_TO_FIELD[col]
        current_value = getattr(app, field, "") or ""

        # Pour la date, afficher en format FR
        if field == "sent_at":
            display_value = _format_date_fr(current_value)
            if display_value == "—":
                display_value = ""
        else:
            display_value = current_value

        # Créer un QLineEdit inline dans la cellule
        editor = QLineEdit(self.table)
        editor.setText(display_value)
        editor.selectAll()
        if field == "sent_at":
            editor.setPlaceholderText("JJ/MM/AAAA")
        editor.setStyleSheet("""
            QLineEdit {
                background-color: #1e1e2e;
                border: 2px solid #cba6f7;
                border-radius: 4px;
                padding: 4px 8px;
                color: #cdd6f4;
                font-size: 12px;
            }
        """)

        self._editing = True
        self.table.setCellWidget(row, col, editor)
        editor.setFocus()

        # Sauvegarder à la perte de focus ou Entrée (guard contre double appel)
        _done = [False]

        def _finish_edit():
            if _done[0]:
                return
            _done[0] = True
            new_value = editor.text().strip()
            self.table.removeCellWidget(row, col)
            self._editing = False

            # Validation
            if field == "sent_at":
                if new_value:
                    iso = _fr_to_iso(new_value)
                    if iso is None:
                        # Valeur invalide → restaurer
                        self._render()
                        return
                    new_value = iso
                # else: vide → on efface la date

            if new_value != current_value:
                db.update_application(app.id, {field: new_value})
                setattr(app, field, new_value)

            self._render()
            self._update_stats()

        def _cancel_edit():
            if _done[0]:
                return
            _done[0] = True
            self.table.removeCellWidget(row, col)
            self._editing = False
            self._render()

        editor.returnPressed.connect(_finish_edit)
        editor.editingFinished.connect(_finish_edit)

        # Échap pour annuler
        from PyQt6.QtCore import QEvent, QObject

        class _EscFilter(QObject):
            """Filtre Échap sur l'éditeur inline."""
            def __init__(self, cancel_fn, parent=None):
                super().__init__(parent)
                self._cancel = cancel_fn

            def eventFilter(self, obj, event):
                if (event.type() == QEvent.Type.KeyPress
                        and event.key() == Qt.Key.Key_Escape):
                    self._cancel()
                    return True
                return False

        # On garde une ref pour éviter le GC
        editor._esc_filter = _EscFilter(_cancel_edit, editor)
        editor.installEventFilter(editor._esc_filter)

    def _edit_status_inline(self, app: Application) -> None:
        """Double-clic sur Statut → dialogue rapide de sélection."""
        from PyQt6.QtWidgets import QInputDialog

        items = [label for _, (label, _) in APPLICATION_STATUSES.items()]
        keys = list(APPLICATION_STATUSES.keys())
        current_label = APPLICATION_STATUSES.get(app.status, ("En attente", ""))[0]
        current_idx = items.index(current_label) if current_label in items else 0

        item, ok = QInputDialog.getItem(
            self, "Modifier le statut",
            f"Statut pour «{app.job_title}» :",
            items, current_idx, False,
        )
        if ok and item:
            idx = items.index(item)
            new_status = keys[idx]
            if new_status != app.status:
                db.update_application_status(app.id, new_status)
                app.status = new_status
                self._render()
                self._update_stats()

    def _on_edit_clicked(self, app: Application) -> None:
        """Bouton ✏️ → ouvre le dialogue d'édition complet."""
        from ui.dialogs import EditApplicationDialog
        dlg = EditApplicationDialog(app, self)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            self.refresh()

    # ─── Internal ─────────────────────────────────────────────────────────────

    def _render(self) -> None:
        self.table.setRowCount(0)
        for app in self._filtered:
            row = self.table.rowCount()
            self.table.insertRow(row)

            self.table.setItem(row, 0, QTableWidgetItem(app.job_title))
            self.table.setItem(row, 1, QTableWidgetItem(app.company))
            self.table.setItem(row, 2, QTableWidgetItem(app.source))

            # Status badge
            status_label, status_color = APPLICATION_STATUSES.get(
                app.status, ("Inconnu", "#6c7086")
            )
            status_item = QTableWidgetItem(f"  {status_label}  ")
            status_item.setForeground(QColor(status_color))
            status_item.setFont(QFont("Segoe UI", 9, QFont.Weight.Bold))
            self.table.setItem(row, 3, status_item)

            self.table.setItem(row, 4, QTableWidgetItem(_format_date_fr(app.sent_at)))

            # Notes (tronquées à _MAX_NOTES_DISPLAY caractères)
            notes_text = (app.notes or "").replace("\n", " ").strip()
            if len(notes_text) > _MAX_NOTES_DISPLAY:
                notes_text = notes_text[:_MAX_NOTES_DISPLAY] + "…"
            notes_item = QTableWidgetItem(notes_text or "—")
            if notes_text:
                notes_item.setToolTip(app.notes)  # tooltip = texte complet
            notes_item.setForeground(QColor("#a6adc8" if notes_text else "#585b70"))
            self.table.setItem(row, 5, notes_item)

            # Actions widget
            actions = _ActionsWidget(app, self)
            actions.status_changed.connect(self._on_status_changed)
            actions.deleted.connect(self._on_deleted)
            actions.notes_clicked.connect(self._on_notes_clicked)
            actions.edit_clicked.connect(self._on_edit_clicked)
            self.table.setCellWidget(row, 6, actions)
            self.table.setRowHeight(row, _ROW_HEIGHT)

        # Label résultat recherche
        if self._search_text:
            total = len(self._apps)
            shown = len(self._filtered)
            self._search_input.setToolTip(f"{shown} / {total} candidature(s)")
        else:
            self._search_input.setToolTip("")

        # Re-forcer les largeurs après peuplement
        QTimer.singleShot(0, self._force_col_widths)

    def _force_col_widths(self):
        hdr = self.table.horizontalHeader()
        for col, px in _COL_WIDTHS.items():
            hdr.resizeSection(col, px)

    def _update_stats(self) -> None:
        counts = {s: 0 for s in APPLICATION_STATUSES}
        for app in self._apps:
            if app.status in counts:
                counts[app.status] += 1
        for status, lbl in self._stat_labels.items():
            lbl.setText(str(counts.get(status, 0)))
        self._total_count.setText(str(len(self._apps)))

    def _on_status_changed(self, app_id: int, status: str) -> None:
        db.update_application_status(app_id, status)
        self.refresh()

    def _on_deleted(self, app_id: int) -> None:
        reply = QMessageBox.question(
            self, "Confirmer",
            "Supprimer cette candidature ?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
        )
        if reply == QMessageBox.StandardButton.Yes:
            db.delete_application(app_id)
            self.refresh()

    def _on_notes_clicked(self, app: Application) -> None:
        dlg = _NotesDialog(app, self)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            db.update_application_notes(app.id, dlg.get_notes())
            self.refresh()


# ─── Helper widgets ────────────────────────────────────────────────────────────

class _ActionsWidget(QWidget):
    status_changed = pyqtSignal(int, str)
    deleted = pyqtSignal(int)
    notes_clicked = pyqtSignal(object)
    edit_clicked = pyqtSignal(object)

    def __init__(self, app: Application, parent=None):
        super().__init__(parent)
        self._app = app
        lay = QHBoxLayout(self)
        lay.setContentsMargins(4, 0, 4, 0)
        lay.setSpacing(4)

        self._combo = QComboBox()
        self._combo.setMinimumWidth(120)
        self._combo.setMaximumHeight(28)
        self._combo.setStyleSheet(
            "QComboBox { padding: 2px 8px; min-height: 22px; }"
        )
        # Bloquer les signaux pendant la construction pour éviter
        # des écritures DB parasites à chaque addItem()
        self._combo.blockSignals(True)
        for key, (label, _) in APPLICATION_STATUSES.items():
            self._combo.addItem(label, key)
        idx = self._combo.findData(app.status)
        if idx >= 0:
            self._combo.setCurrentIndex(idx)
        self._combo.blockSignals(False)
        self._combo.currentIndexChanged.connect(
            lambda i: self.status_changed.emit(app.id, self._combo.currentData())
        )
        lay.addWidget(self._combo, 1)

        # Bouton Modifier — bleu
        btn_edit = QPushButton("Modifier")
        btn_edit.setFixedHeight(28)
        btn_edit.setToolTip("Modifier la candidature")
        btn_edit.setStyleSheet(_BTN_STYLE.format(
            bg="#3b82f6", fg="#ffffff", hover="#60a5fa",
        ))
        btn_edit.clicked.connect(lambda: self.edit_clicked.emit(app))
        lay.addWidget(btn_edit)

        # Bouton Notes — violet
        btn_notes = QPushButton("Notes")
        btn_notes.setFixedHeight(28)
        btn_notes.setToolTip("Voir / éditer les notes")
        btn_notes.setStyleSheet(_BTN_STYLE.format(
            bg="#8b5cf6", fg="#ffffff", hover="#a78bfa",
        ))
        btn_notes.clicked.connect(lambda: self.notes_clicked.emit(app))
        lay.addWidget(btn_notes)

        # Bouton Suppr — rouge
        btn_del = QPushButton("Suppr.")
        btn_del.setFixedHeight(28)
        btn_del.setToolTip("Supprimer la candidature")
        btn_del.setStyleSheet(_BTN_STYLE.format(
            bg="#ef4444", fg="#ffffff", hover="#f87171",
        ))
        btn_del.clicked.connect(lambda: self.deleted.emit(app.id))
        lay.addWidget(btn_del)


class _NotesDialog(QDialog):
    def __init__(self, app: Application, parent=None):
        super().__init__(parent)
        self.setWindowTitle(f"Notes — {app.job_title}")
        self.setMinimumSize(400, 250)
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel(f"<b>{_esc(app.job_title)}</b> chez <b>{_esc(app.company)}</b>"))
        self._text = QTextEdit()
        self._text.setPlainText(app.notes or "")
        layout.addWidget(self._text)
        btns = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        layout.addWidget(btns)

    def get_notes(self) -> str:
        return self._text.toPlainText()
