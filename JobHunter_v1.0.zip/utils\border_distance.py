"""
Calcul de distance depuis la frontière franco-suisse.

Pour chaque offre suisse disposant de coordonnées GPS :
  1. Vérifie le cache DB (persistant entre sessions)
  2. Teste les 5 crossings les plus proches (haversine) via OSRM
  3. Retient le crossing avec le temps de trajet le plus court
  4. Persiste le résultat en DB pour les prochaines sessions

Fonctions publiques :
  find_nearest_crossings(lat, lng, n) → [dict]
  find_nearest_crossing(lat, lng)     → dict
  border_driving_time(lat, lng)       → {km, minutes, crossing, french_town, label} | None
  geocode_swiss(location)             → (lat, lng) | None
"""
import math
import re
import requests
from typing import Optional, Tuple

import utils.logger as log
from data.border_crossings import BORDER_CROSSINGS
from utils.geocoder import road_distance
import database.db_manager as db

# Cache mémoire (session) : évite de relire la DB à chaque appel
_mem_cache: dict = {}

# Cache pour le géocodage suisse
_geocode_swiss_cache: dict = {}


def _coord_key(lat: float, lng: float) -> str:
    """Clé de cache : coordonnées arrondies (~111 m de précision)."""
    return f"{round(lat, 3)},{round(lng, 3)}"


def geocode_swiss(location: str) -> Optional[Tuple[float, float]]:
    """Géocode un lieu suisse via Nominatim (OpenStreetMap).
    Ordre : mémoire → DB → Nominatim API.
    Retourne (lat, lng) ou None."""
    if not location or not location.strip():
        return None

    # Nettoyer : retirer codes postaux, numéros, etc.
    clean = re.sub(r"\d{4,5}", "", location).strip()
    # Retirer les suffixes comme "(BE)", "(ZH)" etc.
    clean = re.sub(r"\s*\([^)]*\)\s*", " ", clean).strip()
    if not clean:
        return None

    key = clean.lower()

    # 1. Cache mémoire
    if key in _geocode_swiss_cache:
        return _geocode_swiss_cache[key]

    # 2. Cache DB (persistant)
    try:
        cached = db.get_cached_geocode(f"ch:{key}")
        if cached is not None:
            _geocode_swiss_cache[key] = cached
            log.debug(f"[Swiss Geocoder] '{clean}' → {cached} (DB cache)")
            return cached
    except Exception:
        pass

    # 3. Nominatim API
    try:
        r = requests.get(
            "https://nominatim.openstreetmap.org/search",
            params={
                "q": f"{clean}, Switzerland",
                "format": "json",
                "limit": 1,
                "countrycodes": "ch",
            },
            headers={"User-Agent": "JobHunter/1.0"},
            timeout=6,
        )
        if r.status_code == 200:
            data = r.json()
            if data:
                lat = float(data[0]["lat"])
                lng = float(data[0]["lon"])
                result = (lat, lng)
                _geocode_swiss_cache[key] = result
                try:
                    db.save_cached_geocode(f"ch:{key}", lat, lng, "nominatim")
                except Exception:
                    pass
                log.debug(f"[Swiss Geocoder] '{clean}' → {result}")
                return result
    except Exception as e:
        log.debug(f"[Swiss Geocoder] '{clean}' échoué : {e}")

    _geocode_swiss_cache[key] = None
    return None


def _haversine(lat1: float, lng1: float, lat2: float, lng2: float) -> float:
    """Distance à vol d'oiseau en km."""
    R = 6371.0
    dlat = math.radians(lat2 - lat1)
    dlng = math.radians(lng2 - lng1)
    a = (math.sin(dlat / 2) ** 2 +
         math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) *
         math.sin(dlng / 2) ** 2)
    return R * 2 * math.asin(math.sqrt(a))


def find_nearest_crossings(lat: float, lng: float, n: int = 5) -> list[dict]:
    """Trouve les N passages frontaliers les plus proches par vol d'oiseau.
    Retourne une liste de dicts avec un champ 'crow_km' ajouté."""
    ranked = []
    for c in BORDER_CROSSINGS:
        km = _haversine(lat, lng, c["lat"], c["lng"])
        ranked.append({**c, "crow_km": round(km, 1)})
    ranked.sort(key=lambda x: x["crow_km"])
    return ranked[:n]


# Rétrocompatibilité (utilisé par debug_distance_tab)
def find_nearest_crossing(lat: float, lng: float) -> dict:
    """Trouve le passage frontalier le plus proche par vol d'oiseau."""
    return find_nearest_crossings(lat, lng, n=1)[0]


def _format_label(minutes: Optional[int], km: float, french_town: str,
                  crossing_name: str, as_crow: bool = False) -> str:
    """Formate le label de distance pour l'UI."""
    if minutes is not None:
        h, m = divmod(minutes, 60)
        duration = f"{h}h{m:02d}" if h > 0 else f"{m} min"
        return (
            f"\U0001f1e8\U0001f1ed  {duration} depuis {french_town} "
            f"(frontière {crossing_name})"
        )
    suffix = " (vol d'oiseau)" if as_crow else ""
    return f"\U0001f1e8\U0001f1ed  {km} km{suffix} depuis {french_town}"


def border_driving_time(
    job_lat: float,
    job_lng: float,
    timeout: int = 8,
) -> Optional[dict]:
    """Calcule le temps de trajet le plus court depuis la frontière.

    Ordre de recherche :
      1. Cache mémoire (session en cours)
      2. Cache DB (persistant entre sessions)
      3. Calcul OSRM sur les 5 crossings les plus proches

    Retourne :
        {
            "km":          float,
            "minutes":     int,
            "crossing":    str,
            "french_town": str,
            "label":       str,
        }
    ou None si le calcul échoue pour tous les crossings.
    """
    key = _coord_key(job_lat, job_lng)

    # 1. Cache mémoire
    if key in _mem_cache:
        return _mem_cache[key]

    # 2. Cache DB (persistant)
    try:
        cached = db.get_cached_distance(key)
        if cached is not None:
            _mem_cache[key] = cached
            log.debug(
                f"[Border] Cache DB hit : {cached['crossing']} → "
                f"({job_lat:.3f},{job_lng:.3f}) = {cached['km']} km, "
                f"{cached.get('minutes')} min"
            )
            return cached
    except Exception:
        pass  # DB indisponible → on calcule

    # 3. Calcul OSRM — tester les 5 crossings les plus proches
    candidates = find_nearest_crossings(job_lat, job_lng, n=5)
    if not candidates:
        return None

    p_job = (job_lat, job_lng)
    best = None
    best_minutes = None  # suivi séparé pour éviter les comparaisons None

    for c in candidates:
        p_french = (c["french_lat"], c["french_lng"])
        result = road_distance(p_french, p_job, timeout=timeout)
        if result is None:
            continue

        minutes = result.get("minutes")
        km = result["km"]
        as_crow = result.get("as_crow", False)

        if minutes is not None:
            # Vrai résultat OSRM — toujours prioritaire sur un fallback
            if best_minutes is None or minutes < best_minutes:
                best_minutes = minutes
                best = {
                    "km": km,
                    "minutes": minutes,
                    "crossing": c["name"],
                    "french_town": c["french_town"],
                    "osrm_ok": True,
                }
        elif best is None:
            # Fallback haversine — uniquement si rien de mieux
            best = {
                "km": km,
                "minutes": None,
                "crossing": c["name"],
                "french_town": c["french_town"],
                "osrm_ok": False,
            }

    if best is None:
        return None

    osrm_ok = best.pop("osrm_ok", False)

    best["label"] = _format_label(
        best.get("minutes"), best["km"],
        best["french_town"], best["crossing"],
        as_crow=(not osrm_ok),
    )

    # Persister en DB uniquement si OSRM a répondu (résultat fiable).
    # Les fallbacks haversine ne sont PAS cachés → retenté au prochain appel.
    if osrm_ok:
        _mem_cache[key] = best
        try:
            db.save_cached_distance(key, best)
        except Exception:
            pass
    else:
        # Cache mémoire seulement (évite de rappeler dans la même session)
        _mem_cache[key] = best
        log.debug(
            f"[Border] OSRM timeout pour ({job_lat:.3f},{job_lng:.3f}) "
            f"— fallback haversine, non persisté en DB"
        )

    log.debug(
        f"[Border] {best['crossing']} → job ({job_lat:.3f},{job_lng:.3f}) "
        f"= {best['km']} km, {best.get('minutes')} min"
        f"{'' if osrm_ok else ' (haversine)'}"
    )
    return best
