"""
France Travail — scraping HTML.

URL de recherche réelle :
  https://candidat.francetravail.fr/offres/recherche?
    lieux=01053  &motsCles=...  &offresPartenaires=true  &rayon=30  &tri=0

Géolocalisation : lookup local dans data/communes.csv (INSEE).
"""
import re
from typing import Optional

from bs4 import NavigableString

import utils.logger as log
from models.models import Job
from scrapers.base_scraper import BaseScraper
from utils.communes import get_code, get_display_name

BASE_URL   = "https://candidat.francetravail.fr"
SEARCH_URL = f"{BASE_URL}/offres/recherche"
DETAIL_URL = f"{BASE_URL}/offres/recherche/detail"

CONTRACT_MAP = {
    "CDI": "CDI", "CDD": "CDD", "Stage": "SAI",
    "Alternance": "CFA", "Intérim": "MIS",
}
_SKIP_H2    = {"employeur", "d'autres offres peuvent vous intéresser"}
_VALID_RADII = [5, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100]


def _nearest_radius(radius: int) -> int:
    return min(_VALID_RADII, key=lambda r: abs(r - radius))


def _format_description(el) -> str:
    lines, prev_blank = [], False
    for line in el.get_text(separator="\n").splitlines():
        line = line.strip()
        if line:
            lines.append(line); prev_blank = False
        elif not prev_blank:
            lines.append(""); prev_blank = True
    return "\n".join(lines).strip()


class FranceTravailScraper(BaseScraper):
    SOURCE_NAME = "France Travail"

    def search(self, keywords, location, radius=30, contract_type="Tous", max_results=50):
        # Résolution locale code INSEE
        code_insee = get_code(location) if location else None
        if location and not code_insee:
            log.warning(f"[France Travail] '{location}' non trouvé dans le référentiel communes")

        valid_radius = _nearest_radius(int(radius))
        params = {
            "motsCles":          keywords,
            "offresPartenaires": "true",
            "rayon":             str(valid_radius),
            "tri":               "0",
        }
        if code_insee:
            params["lieux"] = code_insee
            log.debug(f"[France Travail] Lieu '{location}' → INSEE {code_insee}")
        else:
            log.warning("[France Travail] Recherche sans localisation — résultats nationaux")

        ct = CONTRACT_MAP.get(contract_type)
        if ct:
            params["typeContrat"] = ct

        log.debug(f"[France Travail] GET {SEARCH_URL} params={params}")
        soup = self._soup(SEARCH_URL, params=params)
        if soup is None:
            return []

        cards = soup.select("li[data-id-offre]")
        log.info(f"[France Travail] {len(cards)} offres trouvées")
        jobs = [j for j in (self._parse(c) for c in cards[:max_results]) if j]
        log.info(f"[France Travail] {len(jobs)} offres parsées")
        return jobs

    def _parse(self, card) -> Optional[Job]:
        try:
            offer_id = card.get("data-id-offre", "")
            url      = f"{DETAIL_URL}/{offer_id}" if offer_id else ""

            title_el = (card.select_one("span.media-heading-title") or card.select_one("h2"))
            title = self._clean(title_el.get_text()) if title_el else ""
            if not title:
                return None

            link_el = card.select_one("a.media[href]") or card.select_one("a[href*='detail']")
            if link_el:
                href = link_el.get("href", "")
                url  = href if href.startswith("http") else f"{BASE_URL}{href}"

            sub = card.select_one("p.subtext")
            company, location_out = "", ""
            if sub:
                raw_company = "".join(str(c) for c in sub.children if isinstance(c, NavigableString))
                company = self._clean_company(re.sub(r'\s*-\s*$', '', raw_company).strip())
                span = sub.select_one("span")
                if span:
                    location_out = re.sub(r'^\d+\s*-\s*', '', span.get_text(strip=True)).strip()

            ct_el = (card.select_one("p.contrat:not(.visible-xs-inline-block)") or
                     card.select_one("p.contrat"))
            contract = ""
            if ct_el:
                txt = ct_el.get_text(strip=True)
                for c in ["CDI","CDD","Alternance","Stage","Intérim","Interim","Freelance"]:
                    if c.lower() in txt.lower():
                        contract = c; break

            desc_el = card.select_one("p.description")
            desc    = self._clean(desc_el.get_text()) if desc_el else ""
            date_el = card.select_one("p.date")
            date    = self._clean(date_el.get_text()) if date_el else ""

            return Job(
                id=self._make_id("France Travail", offer_id or url),
                title=title, company=company,
                location=location_out, contract_type=contract,
                description=desc, posted_date=date,
                source="France Travail", url=url,
            )
        except Exception as e:
            log.warning(f"[France Travail] Card ignorée : {e}")
            return None

    def get_details(self, job: Job) -> Job:
        if not job.url:
            return job
        soup = self._soup(job.url)
        if not soup:
            return job

        modal = soup.select_one(".modal-body")
        root  = modal or soup

        description = ""
        for sel in ["div.description.col-sm-8","div.description.col-md-7","div.description",".row > p"]:
            el = root.select_one(sel)
            if el:
                txt = _format_description(el)
                if len(txt) > 100:
                    description = txt; break

        extras = []
        for h2 in root.select("h2.subtitle, h2.t5"):
            heading = h2.get_text(strip=True)
            if any(s in heading.lower() for s in _SKIP_H2):
                continue
            bits = []
            for sib in h2.find_next_siblings():
                if sib.name and sib.name.startswith("h"): break
                txt = sib.get_text(separator="\n", strip=True)
                if txt: bits.append(txt)
            block = "\n".join(bits).strip()
            if block:
                extras.append(f"\n\n— {heading} —\n{block}")

        if description or extras:
            job.description = description + "".join(extras)

        for h2 in root.select("h2"):
            if "employeur" not in h2.get_text(strip=True).lower():
                continue
            div_media = h2.find_next_sibling("div", class_="media")
            if not div_media: break
            employer_texts = [t.strip() for t in div_media.stripped_strings]
            employer_name  = employer_texts[0] if employer_texts else job.company
            link = div_media.select_one("a[href*='page-employeur'], a[href*='recrute']")
            employer_url = link.get("href", "") if link else ""
            job.company_info = {"name": employer_name, "description": f"Employeur : {employer_name}", "url": employer_url}
            if employer_name and not job.company:
                job.company = employer_name
            break

        return job
