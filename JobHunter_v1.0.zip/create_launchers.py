"""
Cree les lanceurs JobHunter (bat + vbs).
Usage : python create_launchers.py <app_dir> <venv_dir>

Fichiers generes (tous avec chemins relatifs, portables) :
  - JobHunter.vbs        : lanceur principal (sans fenetre CMD)
  - JobHunter.bat        : lanceur via bat (fenetre CMD cachee, log erreurs)
  - JobHunter_DEBUG.bat  : lanceur debug (fenetre CMD visible)
"""
import sys
import os

app = sys.argv[1]

# ── JobHunter.vbs : lance l'app sans aucune fenetre console ──────────────
# Resout son propre dossier a l'execution → chemins relatifs portables
vbs = (
    'Dim fso, appDir\n'
    'Set fso = CreateObject("Scripting.FileSystemObject")\n'
    'appDir = fso.GetParentFolderName(WScript.ScriptFullName)\n'
    'Set WshShell = CreateObject("WScript.Shell")\n'
    'WshShell.CurrentDirectory = appDir\n'
    'WshShell.Run """" & appDir & "\\venv\\Scripts\\pythonw.exe"" ""'
    '" & appDir & "\\main.py""", 0, False\n'
)

# ── JobHunter.bat : lanceur bat classique (stderr → log) ────────────────
# %~dp0 = dossier du .bat (avec \ final), fonctionne quel que soit le PC
bat_normal = (
    '@echo off\n'
    'set "APP_DIR=%~dp0"\n'
    'if "%APP_DIR:~-1%"=="\\\\" set "APP_DIR=%APP_DIR:~0,-1%"\n'
    'cd /d "%APP_DIR%"\n'
    '"%APP_DIR%\\venv\\Scripts\\pythonw.exe" "%APP_DIR%\\main.py"'
    ' 2>> "%APP_DIR%\\runtime_log.txt"\n'
)

# ── JobHunter_DEBUG.bat : console visible pour diagnostic ────────────────
bat_debug = (
    '@echo off\n'
    'set "APP_DIR=%~dp0"\n'
    'if "%APP_DIR:~-1%"=="\\\\" set "APP_DIR=%APP_DIR:~0,-1%"\n'
    'title JobHunter [DEBUG]\n'
    'cd /d "%APP_DIR%"\n'
    'echo === JOBHUNTER DEBUG ===\n'
    'echo.\n'
    '"%APP_DIR%\\venv\\Scripts\\python.exe" "%APP_DIR%\\main.py"\n'
    'echo.\n'
    'echo Code de sortie : %errorlevel%\n'
    'pause\n'
)

files = {
    'JobHunter.vbs':       vbs,
    'JobHunter.bat':       bat_normal,
    'JobHunter_DEBUG.bat': bat_debug,
}

for name, content in files.items():
    path = os.path.join(app, name)
    with open(path, 'w', encoding='utf-8') as f:
        f.write(content)
    print("  -> " + path)

print("Lanceurs crees avec succes.")
