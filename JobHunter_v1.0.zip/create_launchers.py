"""
Cree les fichiers JobHunter.bat et JobHunter_DEBUG.bat
Usage : python create_launchers.py <app_dir> <venv_dir>
"""
import sys
import os

app  = sys.argv[1]
venv = sys.argv[2]

normal = (
    '@echo off\n'
    'cd /d "' + app + '"\n'
    '"' + venv + '\\Scripts\\pythonw.exe" "' + app + '\\main.py" 2>> "' + app + '\\runtime_log.txt"\n'
)

debug = (
    '@echo off\n'
    'title JobHunter [DEBUG]\n'
    'cd /d "' + app + '"\n'
    'echo === JOBHUNTER DEBUG ===\n'
    'echo.\n'
    '"' + venv + '\\Scripts\\python.exe" "' + app + '\\main.py"\n'
    'echo.\n'
    'echo Code de sortie : %errorlevel%\n'
    'pause\n'
)

with open(os.path.join(app, 'JobHunter.bat'), 'w', encoding='utf-8') as f:
    f.write(normal)

with open(os.path.join(app, 'JobHunter_DEBUG.bat'), 'w', encoding='utf-8') as f:
    f.write(debug)

print("Lanceurs crees avec succes.")
print("  -> " + os.path.join(app, 'JobHunter.bat'))
print("  -> " + os.path.join(app, 'JobHunter_DEBUG.bat'))
