"""
Onglet Suisse — recherche sur Jobup.ch + Jobs.ch avec filtrage par distance frontière.

Structure : SwissSearchPanel | QSplitter(ResultsPanel, DetailPanel)
Workers intégrés : SwissSearchWorker, BorderDistanceWorker
"""
import copy
from PyQt6.QtCore import Qt, pyqtSignal, QThread
from PyQt6.QtWidgets import QWidget, QHBoxLayout, QSplitter, QFrame

from models.models import Job
from scrapers.aggregator import _create_scraper, SWISS_SOURCE_NAMES, DetailWorker
from data.swiss_search_cities import SWISS_BORDER_CITIES, SWISS_BORDER_CITY_NAMES
from ui.swiss_search_panel import SwissSearchPanel
from ui.results_panel import ResultsPanel
from ui.detail_panel import DetailPanel
from utils.border_distance import border_driving_time, geocode_swiss
import utils.logger as log


# ─── Workers ──────────────────────────────────────────────────────────────────

class SwissSearchWorker(QThread):
    """Recherche Jobup.ch + Jobs.ch avec filtrage par temps de trajet frontière."""

    jobs_ready = pyqtSignal(list, dict)   # jobs filtrés, {job_id: border_result}
    progress   = pyqtSignal(str)          # message de statut

    def __init__(self, keywords: str, max_border_minutes: int,
                 cities: list[str] | None = None):
        super().__init__()
        self.keywords = keywords
        self.max_border_minutes = max_border_minutes
        self.cities = cities if cities else SWISS_BORDER_CITY_NAMES
        self._cancelled = False

    def cancel(self):
        self._cancelled = True

    def run(self):
        all_jobs = []
        seen_ids: set = set()  # déduplication par job_id

        # 1. Recherches ciblées par ville frontalière × source
        total_queries = len(self.cities) * len(SWISS_SOURCE_NAMES)
        query_num = 0

        for city in self.cities:
            for source_name in SWISS_SOURCE_NAMES:
                if self._cancelled:
                    return

                query_num += 1
                self.progress.emit(
                    f"[{query_num}/{total_queries}] {city} ({source_name})…"
                )

                scraper = _create_scraper(source_name)
                if scraper is None:
                    continue

                try:
                    jobs = scraper.search(
                        keywords=self.keywords,
                        location=city,
                        max_results=50,
                    )
                    new_count = 0
                    for job in jobs:
                        if job.id not in seen_ids:
                            seen_ids.add(job.id)
                            all_jobs.append(job)
                            new_count += 1
                    log.info(
                        f"[Swiss] {source_name} @ {city} : "
                        f"{len(jobs)} offres, {new_count} nouvelles"
                    )
                except Exception as e:
                    log.error(f"[Swiss] Erreur {source_name} @ {city} : {e}")

        if self._cancelled:
            return

        self.progress.emit(
            f"{len(all_jobs)} offres trouvées — filtrage par distance…"
        )

        # 2. Filtrer par distance frontière
        filtered = []
        border_info: dict = {}  # job.id → border result

        for i, job in enumerate(all_jobs):
            if self._cancelled:
                return

            if i > 0 and i % 10 == 0:
                self.progress.emit(
                    f"Filtrage : {i}/{len(all_jobs)} offres analysées…"
                )

            info = job.company_info if isinstance(job.company_info, dict) else {}
            lat = info.get("_lat")
            lng = info.get("_lng")

            if lat is None or lng is None:
                # Pas de coordonnées API → géocoder le lieu
                if job.location:
                    coords = geocode_swiss(job.location)
                    if coords:
                        lat, lng = coords
                        # Stocker pour usage ultérieur
                        if not isinstance(job.company_info, dict):
                            job.company_info = {}
                        job.company_info["_lat"] = lat
                        job.company_info["_lng"] = lng
                    else:
                        log.debug(
                            f"[Swiss] Exclu (géocodage impossible) : "
                            f"{job.title} @ {job.location}"
                        )
                        continue
                else:
                    log.debug(f"[Swiss] Exclu (pas de lieu) : {job.title}")
                    continue

            try:
                result = border_driving_time(lat, lng)
            except Exception as e:
                log.debug(f"[Swiss] Distance échouée pour {job.location}: {e}")
                continue

            if result is None:
                continue

            minutes = result.get("minutes")
            if minutes is not None and minutes > self.max_border_minutes:
                log.debug(
                    f"[Swiss] Exclu : {job.location} → {minutes} min "
                    f"(max {self.max_border_minutes})"
                )
                continue

            border_info[job.id] = result
            filtered.append(job)

        log.info(
            f"[Swiss] {len(filtered)}/{len(all_jobs)} offres retenues "
            f"(max {self.max_border_minutes} min)"
        )
        src_txt = " + ".join(SWISS_SOURCE_NAMES)
        cities_txt = f"{len(self.cities)} région(s)"
        self.progress.emit(
            f"✅  {len(filtered)} offre(s) retenue(s) sur {len(all_jobs)} "
            f"({src_txt}, {cities_txt})"
        )
        self.jobs_ready.emit(filtered, border_info)


class BorderDistanceWorker(QThread):
    """Calcule la distance frontière pour une offre individuelle."""
    distance_ready = pyqtSignal(object, object)  # job, result

    def __init__(self, job: Job):
        super().__init__()
        self.job = copy.deepcopy(job)

    def run(self):
        info = self.job.company_info if isinstance(self.job.company_info, dict) else {}
        lat = info.get("_lat")
        lng = info.get("_lng")

        # Géocodage fallback si pas de coordonnées
        if (lat is None or lng is None) and self.job.location:
            coords = geocode_swiss(self.job.location)
            if coords:
                lat, lng = coords

        result = None
        if lat is not None and lng is not None:
            try:
                result = border_driving_time(lat, lng)
            except Exception as e:
                log.debug(f"[Swiss] Border distance error: {e}")

        self.distance_ready.emit(self.job, result)


# ─── Onglet principal ─────────────────────────────────────────────────────────

class SwissTab(QWidget):
    """Widget autonome pour l'onglet de recherche Suisse."""

    save_job_requested      = pyqtSignal(object)
    application_changed     = pyqtSignal(object)
    status_changed          = pyqtSignal(str)       # → MainWindow status bar
    template_save_requested = pyqtSignal(dict)       # → MainWindow
    template_load_requested = pyqtSignal()            # → MainWindow
    distance_clicked        = pyqtSignal(str, str)   # (french_town, job_location) → carte

    def __init__(self, parent=None):
        super().__init__(parent)
        self._search_worker:   SwissSearchWorker   | None = None
        self._detail_worker:   DetailWorker        | None = None
        self._border_worker:   BorderDistanceWorker | None = None
        self._border_info:     dict = {}  # job.id → border result (cache)
        self._build_ui()

    def _build_ui(self):
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # Panneau de recherche
        self.search_panel = SwissSearchPanel()
        self.search_panel.search_requested.connect(self._on_search)
        self.search_panel.template_save_requested.connect(
            self.template_save_requested.emit
        )
        self.search_panel.template_load_requested.connect(
            self.template_load_requested.emit
        )
        layout.addWidget(self.search_panel)

        # Séparateur vertical
        sep = QFrame()
        sep.setFrameShape(QFrame.Shape.VLine)
        sep.setStyleSheet("color:#313244;")
        layout.addWidget(sep)

        # Splitter résultats / détail
        splitter = QSplitter(Qt.Orientation.Horizontal)
        splitter.setChildrenCollapsible(False)

        self.results_panel = ResultsPanel()
        self.results_panel.job_selected.connect(self._on_job_selected)
        self.results_panel.save_job_requested.connect(self.save_job_requested.emit)
        self.results_panel.application_changed.connect(self.application_changed.emit)
        splitter.addWidget(self.results_panel)

        self.detail_panel = DetailPanel()
        self.detail_panel.quick_tag_requested.connect(self.application_changed.emit)
        self.detail_panel.save_job_requested.connect(self.save_job_requested.emit)
        self.detail_panel.distance_clicked.connect(self.distance_clicked.emit)
        splitter.addWidget(self.detail_panel)

        splitter.setSizes([420, 700])
        layout.addWidget(splitter, 1)

    # ── Recherche ─────────────────────────────────────────────────────────────

    def _on_search(self, params: dict):
        if self._search_worker and self._search_worker.isRunning():
            self._search_worker.cancel()
            self._search_worker.wait(2000)

        self.search_panel.set_searching(True)
        self.results_panel.clear()
        self._border_info.clear()

        self._search_worker = SwissSearchWorker(
            keywords=params["keywords"],
            max_border_minutes=params["max_border_minutes"],
            cities=params.get("cities"),
        )
        self._search_worker.progress.connect(self._on_progress)
        self._search_worker.jobs_ready.connect(self._on_jobs_ready)
        self._search_worker.start()

    def _on_progress(self, msg: str):
        log.info(f"[Swiss] {msg}")
        self.status_changed.emit(f"\U0001f1e8\U0001f1ed  {msg}")

    def _on_jobs_ready(self, jobs: list, border_info: dict):
        self.search_panel.set_searching(False)
        self._border_info.update(border_info)
        self.results_panel.add_jobs(jobs)
        log.info(f"[Swiss] {len(jobs)} offres affichées")

    # ── Sélection d'offre ─────────────────────────────────────────────────────

    def _on_job_selected(self, job: Job):
        self.detail_panel.show_job(job)
        self.detail_panel.show_loading(True)

        # Afficher la distance frontière si déjà calculée
        cached = self._border_info.get(job.id)
        if cached:
            self.detail_panel.update_distance(job, cached)

        # Detail worker (description complète)
        if self._detail_worker and self._detail_worker.isRunning():
            self._detail_worker.wait(2000)
        self._detail_worker = DetailWorker(job)
        self._detail_worker.detail_ready.connect(self._on_detail_ready)
        self._detail_worker.start()

        # Border distance worker (si pas en cache)
        if not cached:
            if self._border_worker and self._border_worker.isRunning():
                self._border_worker.wait(2000)
            self._border_worker = BorderDistanceWorker(job)
            self._border_worker.distance_ready.connect(self._on_border_ready)
            self._border_worker.start()

    def _on_detail_ready(self, job: Job):
        self.detail_panel.show_loading(False)
        self.detail_panel.update_description(job)

    def _on_border_ready(self, job: Job, result):
        if result:
            self._border_info[job.id] = result
        self.detail_panel.update_distance(job, result)

    # ── API publique ──────────────────────────────────────────────────────────

    def reload_applied(self):
        try:
            self.results_panel.reload_applied()
        except Exception:
            pass

    def refresh_tag_status(self, job):
        try:
            self.detail_panel.refresh_tag_status(job)
        except Exception:
            pass

    def load_template(self, keywords: str, max_border_minutes: int):
        """Charge un template suisse dans le panneau de recherche."""
        self.search_panel.load_template(keywords, max_border_minutes)

    def cleanup(self):
        """Arrête les workers en cours."""
        for w in (self._search_worker, self._detail_worker, self._border_worker):
            if w and w.isRunning():
                if hasattr(w, "cancel"):
                    w.cancel()
                w.wait(2000)
