from pathlib import Path

APP_NAME = "JobHunter"
APP_VERSION = "1.0.0"

BASE_DIR = Path(__file__).parent
DATA_DIR = Path.home() / ".jobhunter"
DB_PATH = DATA_DIR / "jobhunter.db"

CONTRACT_TYPES = [
    "Tous",
    "CDI",
    "CDD",
    "Stage",
    "Alternance",
    "Freelance / Mission",
    "Intérim",
    "Temps partiel",
]

# Sources actives (celles bloquées ou endpoints morts sont exclues)
SOURCES = [
    "France Travail",        # HTML — fiable
    "HelloWork",             # HTML — fiable
    "Welcome to the Jungle", # API Algolia — fiable
    "APEC",                  # Angular (best-effort)
    "Meteojob",              # Angular SSR (best-effort)
]

APPLICATION_STATUSES = {
    "pending":   ("En attente",  "#f59e0b"),
    "sent":      ("Envoyée",     "#3b82f6"),
    "interview": ("Entretien",   "#8b5cf6"),
    "rejected":  ("Refusée",     "#ef4444"),
    "accepted":  ("Acceptée",    "#10b981"),
}
