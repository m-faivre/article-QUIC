"""
Meteojob — API REST (CleverConnect / OuterHR).

Endpoint principal :
  GET /api/joboffers/search
    ?what=<keywords>&where=<location>&page=1&limit=20&sorting=SCORING

Endpoint détail :
  GET /api/joboffers/<id>    → offre complète (description HTML, salaire, etc.)

Aucune authentification requise.

Types de contrat acceptés : CDI, CDD, INTERIM, FREELANCE, ALTERNANCE, STAGE, ...
"""
import re
import time
from typing import List, Optional

import utils.logger as log
from models.models import Job
from scrapers.base_scraper import BaseScraper

BASE = "https://www.meteojob.com"
SEARCH_URL = f"{BASE}/api/joboffers/search"
DETAIL_URL = f"{BASE}/api/joboffers"

CONTRACT_MAP = {
    "CDI":        "CDI",
    "CDD":        "CDD",
    "Intérim":    "INTERIM",
    "Freelance":  "FREELANCE",
    "Alternance": "ALTERNANCE",
    "Stage":      "STAGE",
}

# Nombre max de résultats par page (limité par l'API)
PAGE_SIZE = 20


class MeteojobScraper(BaseScraper):
    SOURCE_NAME = "Meteojob"

    def __init__(self):
        super().__init__()
        # L'API attend du JSON en retour, pas du HTML
        self.session.headers.update({
            "Accept": "application/json, text/plain, */*",
            "Referer": f"{BASE}/jobs",
        })

    # ── Recherche ─────────────────────────────────────────────────────────────

    def search(self, keywords, location, radius=30, contract_type="Tous", max_results=50):
        params = {
            "what":    keywords,
            "page":    1,
            "limit":   min(PAGE_SIZE, max_results),
            "sorting": "SCORING",
        }
        if location:
            params["where"] = location

        ct = CONTRACT_MAP.get(contract_type)
        if ct:
            params["contract"] = ct

        log.info(
            f"[Meteojob] Recherche : '{keywords}' | lieu={location} | "
            f"contrat={contract_type}"
        )
        log.debug(f"[Meteojob] GET {SEARCH_URL}  params={params}")

        all_jobs: List[Job] = []
        pages_fetched = 0
        max_pages = max(1, (max_results + PAGE_SIZE - 1) // PAGE_SIZE)

        while pages_fetched < max_pages:
            r = self._get(SEARCH_URL, params=params)
            if r is None:
                break

            try:
                data = r.json()
            except Exception:
                log.warning("[Meteojob] Réponse non-JSON")
                break

            total = data.get("total", 0)
            content = data.get("content", [])

            if pages_fetched == 0:
                log.info(f"[Meteojob] {total} offres totales trouvées")

            if not content:
                break

            for item in content:
                if len(all_jobs) >= max_results:
                    break
                job = self._parse(item)
                if job:
                    all_jobs.append(job)

            pages_fetched += 1

            # Page suivante ?
            if len(all_jobs) >= max_results or len(content) < PAGE_SIZE:
                break

            params["page"] = pages_fetched + 1
            time.sleep(0.5)

        log.info(f"[Meteojob] {len(all_jobs)} offres parsées")
        return all_jobs

    # ── Parsing d'une offre ───────────────────────────────────────────────────

    def _parse(self, item: dict) -> Optional[Job]:
        try:
            offer_id = str(item.get("id", ""))
            title = self._clean(item.get("title", ""))
            if not title:
                return None

            # Entreprise
            company_data = item.get("company") or {}
            if isinstance(company_data, dict):
                company_name = self._clean_company(company_data.get("name", ""))
                company_id = company_data.get("id", "")
            else:
                company_name = self._clean_company(str(company_data))
                company_id = ""

            # Localisation
            locality = self._clean(item.get("locality", ""))
            if not locality:
                locations = item.get("locations") or []
                if locations and isinstance(locations, list):
                    loc = locations[0]
                    parts = []
                    for k in ("name", "admin2Name", "admin1Name"):
                        v = loc.get(k, "")
                        if v and v not in parts:
                            parts.append(v)
                    locality = ", ".join(parts)

            # Type de contrat
            contracts = item.get("contractTypes") or []
            if isinstance(contracts, list):
                contract_str = ", ".join(contracts)
            else:
                contract_str = str(contracts)

            # Salaire
            salary = self._format_salary(item.get("salary") or {})

            # Date de publication
            pub_date = item.get("publicationDate", "")
            date_str = str(pub_date)[:10] if pub_date else ""

            # Description courte (pas HTML)
            desc_html = item.get("description", "")
            description = self._html_to_text(desc_html)[:500] if desc_html else ""

            # Description entreprise
            company_desc_html = item.get("companyDescription", "")
            company_desc = self._html_to_text(company_desc_html) if company_desc_html else ""

            # Company info pour le detail_panel
            company_info = {}
            if company_name:
                company_info["name"] = company_name
            if company_desc:
                company_info["description"] = company_desc
            elif company_name:
                company_info["description"] = f"Employeur : {company_name}"

            # URL de l'offre
            url = f"{BASE}/jobs/{offer_id}" if offer_id else ""

            # Expérience
            experience = ""
            labels = item.get("labels") or {}
            if isinstance(labels, dict):
                exp_list = labels.get("experienceLevelList") or []
                if exp_list:
                    experience = ", ".join(
                        e.get("label", str(e)) if isinstance(e, dict) else str(e)
                        for e in exp_list
                    )

            # Tags / compétences
            skills = item.get("skills") or []
            tags = [str(s) for s in skills] if isinstance(skills, list) else []

            return Job(
                id=self._make_id("Meteojob", offer_id or f"{title}|{company_name}"),
                title=title,
                company=company_name,
                location=locality,
                contract_type=self._clean(contract_str),
                salary=salary,
                posted_date=date_str,
                description=description,
                source="Meteojob",
                url=url,
                company_info=company_info,
                experience=experience,
                tags=tags,
            )
        except Exception as e:
            log.warning(f"[Meteojob] Offre ignorée : {e}")
            return None

    # ── Détail complet ────────────────────────────────────────────────────────

    def get_details(self, job: Job) -> Job:
        """Récupère la description complète via GET /api/joboffers/<id>."""
        if not job.url:
            return job

        # Extraire l'ID de l'URL : /jobs/12345678
        match = re.search(r"/jobs/(\d+)", job.url)
        if not match:
            return job

        offer_id = match.group(1)
        r = self._get(f"{DETAIL_URL}/{offer_id}")
        if r is None:
            return job

        try:
            data = r.json()
        except Exception:
            return job

        # Description complète
        desc_html = data.get("description", "")
        profile_html = data.get("profileDescription", "")
        full_desc = ""
        if desc_html:
            full_desc = self._html_to_text(desc_html)
        if profile_html:
            profile_text = self._html_to_text(profile_html)
            if profile_text:
                full_desc += "\n\nProfil recherché :\n" + profile_text

        if full_desc and len(full_desc) > len(job.description or ""):
            job.description = full_desc

        # Enrichir company_info
        company_desc = data.get("companyDescription", "")
        if company_desc:
            txt = self._html_to_text(company_desc)
            if txt:
                if not isinstance(job.company_info, dict):
                    job.company_info = {}
                job.company_info["description"] = txt

        return job

    # ── Helpers ───────────────────────────────────────────────────────────────

    @staticmethod
    def _format_salary(sal: dict) -> str:
        if not isinstance(sal, dict):
            return ""

        sal_from = sal.get("from")
        sal_to = sal.get("to")
        currency = sal.get("currency", "EUR")
        symbol = "€" if currency == "EUR" else currency

        if sal_from and sal_to:
            return (f"{int(sal_from):,} – {int(sal_to):,} {symbol}/an"
                    .replace(",", "\u202f"))
        elif sal_from:
            return f"≥ {int(sal_from):,} {symbol}/an".replace(",", "\u202f")
        return ""

    @staticmethod
    def _html_to_text(html: str) -> str:
        """Convertit du HTML basique en texte lisible."""
        if not html:
            return ""
        # <br> → newline
        text = re.sub(r"<br\s*/?>", "\n", html)
        # <li> → bullet
        text = re.sub(r"<li[^>]*>", "\n• ", text)
        # <p> → double newline
        text = re.sub(r"</?p[^>]*>", "\n", text)
        # Strip remaining tags
        text = re.sub(r"<[^>]+>", "", text)
        # Decode common entities
        text = text.replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
        text = text.replace("&nbsp;", " ").replace("&#39;", "'").replace("&quot;", '"')
        # Clean up whitespace
        lines = [line.strip() for line in text.splitlines()]
        text = "\n".join(line for line in lines if line)
        return text.strip()
