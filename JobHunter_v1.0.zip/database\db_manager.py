import sqlite3
import os
from contextlib import contextmanager
from pathlib import Path
from typing import List, Optional

from config import DB_PATH
from models.models import Job, SearchTemplate, SwissSearchTemplate, Application


def _get_conn() -> sqlite3.Connection:
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    return conn


@contextmanager
def _db():
    """Context manager qui ouvre, commit/rollback, puis ferme la connexion."""
    conn = _get_conn()
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db() -> None:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)

    with _db() as conn:
        conn.executescript("""
            -- Migrations
            PRAGMA foreign_keys=OFF;
            CREATE TABLE IF NOT EXISTS jobs (
                id            TEXT PRIMARY KEY,
                title         TEXT NOT NULL,
                company       TEXT,
                location      TEXT,
                contract_type TEXT,
                source        TEXT,
                url           TEXT,
                description   TEXT,
                salary        TEXT,
                posted_date   TEXT,
                company_info  TEXT,
                tags          TEXT,
                saved_at      DATETIME DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS templates (
                id             INTEGER PRIMARY KEY AUTOINCREMENT,
                name           TEXT NOT NULL UNIQUE,
                keywords       TEXT,
                location       TEXT,
                radius         INTEGER DEFAULT 30,
                contract_types TEXT,
                sources        TEXT,
                created_at     DATETIME DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS applications (
                id                  INTEGER PRIMARY KEY AUTOINCREMENT,
                job_id              TEXT,
                job_title           TEXT,
                company             TEXT,
                source              TEXT,
                status              TEXT DEFAULT 'pending',
                cv_path             TEXT,
                cover_letter_path   TEXT,
                notes               TEXT,
                job_url             TEXT,
                location            TEXT,
                contact             TEXT,
                sent_at             DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at          DATETIME DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS swiss_templates (
                id                 INTEGER PRIMARY KEY AUTOINCREMENT,
                name               TEXT NOT NULL UNIQUE,
                keywords           TEXT,
                max_border_minutes INTEGER DEFAULT 40,
                created_at         DATETIME DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS distance_cache (
                coord_key  TEXT PRIMARY KEY,
                km         REAL,
                minutes    INTEGER,
                crossing   TEXT,
                french_town TEXT,
                label      TEXT,
                cached_at  DATETIME DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS geocode_cache (
                location_key TEXT PRIMARY KEY,
                lat          REAL NOT NULL,
                lng          REAL NOT NULL,
                source       TEXT,
                cached_at    DATETIME DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS route_cache (
                route_key  TEXT PRIMARY KEY,
                km         REAL,
                minutes    INTEGER,
                cached_at  DATETIME DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS settings (
                key   TEXT PRIMARY KEY,
                value TEXT
            );

            CREATE TABLE IF NOT EXISTS hidden_jobs (
                job_id    TEXT PRIMARY KEY,
                hidden_at DATETIME DEFAULT CURRENT_TIMESTAMP
            );
        """)
    _migrate_db()


def _migrate_db() -> None:
    """Ajoute les colonnes manquantes (upgrade schema)."""
    with _db() as conn:
        cols = {r[1] for r in conn.execute("PRAGMA table_info(applications)").fetchall()}
        if "location" not in cols:
            conn.execute("ALTER TABLE applications ADD COLUMN location TEXT DEFAULT ''")
        if "contact" not in cols:
            conn.execute("ALTER TABLE applications ADD COLUMN contact TEXT DEFAULT ''")


# ─── Jobs ────────────────────────────────────────────────────────────────────

def save_job(job: Job) -> None:
    d = job.to_db_dict()
    with _db() as conn:
        conn.execute(
            """INSERT OR REPLACE INTO jobs
               (id,title,company,location,contract_type,source,url,
                description,salary,posted_date,company_info,tags)
               VALUES (:id,:title,:company,:location,:contract_type,:source,:url,
                       :description,:salary,:posted_date,:company_info,:tags)""",
            d,
        )


def get_saved_jobs() -> List[Job]:
    with _db() as conn:
        rows = conn.execute(
            "SELECT * FROM jobs ORDER BY saved_at DESC"
        ).fetchall()
    return [Job.from_db_row(r) for r in rows]


def delete_job(job_id: str) -> None:
    with _db() as conn:
        conn.execute("DELETE FROM jobs WHERE id=?", (job_id,))


# ─── Templates ───────────────────────────────────────────────────────────────

def save_template(tpl: SearchTemplate) -> None:
    d = tpl.to_db_dict()
    with _db() as conn:
        if tpl.id:
            conn.execute(
                """UPDATE templates SET name=:name,keywords=:keywords,location=:location,
                   radius=:radius,contract_types=:contract_types,sources=:sources
                   WHERE id=:id""",
                {**d, "id": tpl.id},
            )
        else:
            conn.execute(
                """INSERT INTO templates (name,keywords,location,radius,contract_types,sources)
                   VALUES (:name,:keywords,:location,:radius,:contract_types,:sources)""",
                d,
            )


def get_templates() -> List[SearchTemplate]:
    with _db() as conn:
        rows = conn.execute(
            "SELECT * FROM templates ORDER BY created_at DESC"
        ).fetchall()
    return [SearchTemplate.from_db_row(r) for r in rows]


def delete_template(template_id: int) -> None:
    with _db() as conn:
        conn.execute("DELETE FROM templates WHERE id=?", (template_id,))


# ─── Swiss Templates ──────────────────────────────────────────────────────────

def save_swiss_template(tpl: SwissSearchTemplate) -> None:
    d = tpl.to_db_dict()
    with _db() as conn:
        if tpl.id:
            conn.execute(
                """UPDATE swiss_templates SET name=:name,keywords=:keywords,
                   max_border_minutes=:max_border_minutes WHERE id=:id""",
                {**d, "id": tpl.id},
            )
        else:
            conn.execute(
                """INSERT INTO swiss_templates (name,keywords,max_border_minutes)
                   VALUES (:name,:keywords,:max_border_minutes)""",
                d,
            )


def get_swiss_templates() -> List[SwissSearchTemplate]:
    with _db() as conn:
        rows = conn.execute(
            "SELECT * FROM swiss_templates ORDER BY created_at DESC"
        ).fetchall()
    return [SwissSearchTemplate.from_db_row(r) for r in rows]


def delete_swiss_template(template_id: int) -> None:
    with _db() as conn:
        conn.execute("DELETE FROM swiss_templates WHERE id=?", (template_id,))


# ─── Applications ─────────────────────────────────────────────────────────────

def _truncate_company(name: str, max_words: int = 5) -> str:
    """Filet de sécurité : tronque un nom d'entreprise trop long."""
    if not name:
        return name
    # Couper au premier séparateur de phrase
    for sep in (".", ",", " - ", " – ", " | ", " / "):
        pos = name.find(sep)
        if 0 < pos < len(name) - 1:
            candidate = name[:pos].strip()
            if len(candidate) >= 2:
                name = candidate
                break
    words = name.split()
    if len(words) > max_words:
        name = " ".join(words[:max_words])
    return name


def save_application(app: Application) -> int:
    d = app.to_db_dict()
    # Sécurité : tronquer le nom d'entreprise si trop long
    if d.get("company") and len(d["company"].split()) > 5:
        d["company"] = _truncate_company(d["company"])
    # Si sent_at n'est pas fourni, utiliser le datetime courant (avec heure)
    if not d.get("sent_at"):
        from datetime import datetime
        d["sent_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with _db() as conn:
        cur = conn.execute(
            """INSERT INTO applications
               (job_id,job_title,company,source,status,cv_path,
                cover_letter_path,notes,job_url,location,contact,sent_at)
               VALUES (:job_id,:job_title,:company,:source,:status,:cv_path,
                       :cover_letter_path,:notes,:job_url,:location,:contact,:sent_at)""",
            d,
        )
        return cur.lastrowid


def update_application_status(app_id: int, status: str) -> None:
    with _db() as conn:
        conn.execute(
            "UPDATE applications SET status=?, updated_at=CURRENT_TIMESTAMP WHERE id=?",
            (status, app_id),
        )


def update_application_notes(app_id: int, notes: str) -> None:
    with _db() as conn:
        conn.execute(
            "UPDATE applications SET notes=?, updated_at=CURRENT_TIMESTAMP WHERE id=?",
            (notes, app_id),
        )


def get_applications() -> List[Application]:
    with _db() as conn:
        rows = conn.execute(
            "SELECT * FROM applications ORDER BY sent_at DESC"
        ).fetchall()
    return [Application.from_db_row(r) for r in rows]


def delete_application(app_id: int) -> None:
    with _db() as conn:
        conn.execute("DELETE FROM applications WHERE id=?", (app_id,))


# Fix #6 : colonnes autorisées figées en frozenset, requête construite uniquement
# à partir de littéraux connus (pas d'input utilisateur dans les noms de colonnes).
_ALLOWED_APP_FIELDS = frozenset({
    "company", "job_title", "location", "contact", "source", "status", "notes", "sent_at"
})


def update_application(app_id: int, fields: dict) -> None:
    """Met à jour les champs éditables d'une candidature."""
    safe = {k: v for k, v in fields.items() if k in _ALLOWED_APP_FIELDS}
    if not safe:
        return
    sets = ", ".join(f"{k}=:{k}" for k in safe)
    with _db() as conn:
        conn.execute(
            f"UPDATE applications SET {sets}, updated_at=CURRENT_TIMESTAMP WHERE id=:id",
            {**safe, "id": app_id},
        )


def get_applied_job_ids() -> set:
    """Retourne l'ensemble des job_id pour lesquels une candidature existe."""
    with _db() as conn:
        rows = conn.execute("SELECT DISTINCT job_id FROM applications").fetchall()
    return {r["job_id"] for r in rows}


# ─── Hidden jobs ──────────────────────────────────────────────────────────

def hide_job(job_id: str) -> None:
    """Masque une offre (elle n'apparaîtra plus dans les résultats par défaut)."""
    with _db() as conn:
        conn.execute(
            "INSERT OR IGNORE INTO hidden_jobs (job_id) VALUES (?)",
            (job_id,),
        )


def unhide_job(job_id: str) -> None:
    """Rend une offre masquée à nouveau visible."""
    with _db() as conn:
        conn.execute("DELETE FROM hidden_jobs WHERE job_id=?", (job_id,))


def get_hidden_job_ids() -> set:
    """Retourne l'ensemble des job_id masqués."""
    with _db() as conn:
        rows = conn.execute("SELECT job_id FROM hidden_jobs").fetchall()
    return {r["job_id"] for r in rows}


# ─── Distance cache ──────────────────────────────────────────────────────────

def get_cached_distance(coord_key: str) -> Optional[dict]:
    """Retourne le résultat de distance en cache ou None."""
    with _db() as conn:
        row = conn.execute(
            "SELECT km, minutes, crossing, french_town, label "
            "FROM distance_cache WHERE coord_key=?",
            (coord_key,),
        ).fetchone()
    if row is None:
        return None
    return {
        "km": row["km"],
        "minutes": row["minutes"],
        "crossing": row["crossing"],
        "french_town": row["french_town"],
        "label": row["label"],
    }


def save_cached_distance(coord_key: str, data: dict) -> None:
    """Persiste un résultat de distance en cache."""
    with _db() as conn:
        conn.execute(
            """INSERT OR REPLACE INTO distance_cache
               (coord_key, km, minutes, crossing, french_town, label)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (
                coord_key,
                data.get("km"),
                data.get("minutes"),
                data.get("crossing", ""),
                data.get("french_town", ""),
                data.get("label", ""),
            ),
        )


# ─── Geocode cache ───────────────────────────────────────────────────────────

def get_cached_geocode(location_key: str) -> Optional[tuple]:
    """Retourne (lat, lng) depuis le cache ou None."""
    with _db() as conn:
        row = conn.execute(
            "SELECT lat, lng FROM geocode_cache WHERE location_key=?",
            (location_key,),
        ).fetchone()
    if row is None:
        return None
    return (row["lat"], row["lng"])


def save_cached_geocode(location_key: str, lat: float, lng: float,
                        source: str = "") -> None:
    """Persiste un résultat de géocodage en cache."""
    with _db() as conn:
        conn.execute(
            """INSERT OR REPLACE INTO geocode_cache
               (location_key, lat, lng, source) VALUES (?, ?, ?, ?)""",
            (location_key, lat, lng, source),
        )


# ─── Route cache ─────────────────────────────────────────────────────────────

def get_cached_route(route_key: str) -> Optional[dict]:
    """Retourne {km, minutes} depuis le cache ou None."""
    with _db() as conn:
        row = conn.execute(
            "SELECT km, minutes FROM route_cache WHERE route_key=?",
            (route_key,),
        ).fetchone()
    if row is None:
        return None
    return {"km": row["km"], "minutes": row["minutes"]}


def save_cached_route(route_key: str, km: float, minutes: int) -> None:
    """Persiste un résultat de distance routière en cache."""
    with _db() as conn:
        conn.execute(
            """INSERT OR REPLACE INTO route_cache
               (route_key, km, minutes) VALUES (?, ?, ?)""",
            (route_key, km, minutes),
        )


# ─── Settings ─────────────────────────────────────────────────────────────────

def get_setting(key: str, default: str = "") -> str:
    with _db() as conn:
        row = conn.execute(
            "SELECT value FROM settings WHERE key=?", (key,)
        ).fetchone()
    return row["value"] if row else default


def set_setting(key: str, value: str) -> None:
    with _db() as conn:
        conn.execute(
            "INSERT OR REPLACE INTO settings (key,value) VALUES (?,?)",
            (key, value),
        )
