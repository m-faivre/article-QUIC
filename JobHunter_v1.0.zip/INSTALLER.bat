@echo off
setlocal enabledelayedexpansion
chcp 65001 >nul 2>&1
title JobHunter — Installation

set "APP_DIR=%~dp0"
if "%APP_DIR:~-1%"=="\" set "APP_DIR=%APP_DIR:~0,-1%"
set "VENV_DIR=%APP_DIR%\venv"
set "ICON=%APP_DIR%\assets\icon.ico"
set "LOG_FILE=%APP_DIR%\install_log.txt"
set "MIN_PY_MAJOR=3"
set "MIN_PY_MINOR=10"

echo [%date% %time%] === DEBUT INSTALLATION === > "%LOG_FILE%"
echo [%date% %time%] APP_DIR  = %APP_DIR% >> "%LOG_FILE%"
echo [%date% %time%] VENV_DIR = %VENV_DIR% >> "%LOG_FILE%"

echo.
echo  ============================================
echo    JOBHUNTER  -  Installation
echo    Log : %LOG_FILE%
echo  ============================================
echo.

:: ─── 1 : Python ──────────────────────────────────────────────────────────────
echo  [1/5] Recherche de Python...
echo [%date% %time%] Etape 1 : Python >> "%LOG_FILE%"

set "PYTHON_EXE="
python --version >nul 2>&1
if not errorlevel 1 ( set "PYTHON_EXE=python" & goto :python_found )
py --version >nul 2>&1
if not errorlevel 1 ( set "PYTHON_EXE=py" & goto :python_found )
python3 --version >nul 2>&1
if not errorlevel 1 ( set "PYTHON_EXE=python3" & goto :python_found )

for %%D in (
    "%LOCALAPPDATA%\Programs\Python\Python313\python.exe"
    "%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
    "%LOCALAPPDATA%\Programs\Python\Python311\python.exe"
    "%LOCALAPPDATA%\Programs\Python\Python310\python.exe"
    "C:\Python313\python.exe"
    "C:\Python312\python.exe"
    "C:\Python311\python.exe"
    "C:\Python310\python.exe"
) do (
    if exist %%D ( set "PYTHON_EXE=%%~D" & goto :python_found )
)

echo [%date% %time%] Python introuvable, telechargement >> "%LOG_FILE%"
echo  [!] Python introuvable. Telechargement de Python 3.11.9...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
    "Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/3.11.9/python-3.11.9-amd64.exe' -OutFile '%TEMP%\python_setup.exe' -UseBasicParsing"
if errorlevel 1 (
    echo [%date% %time%] ERREUR : telechargement Python echoue >> "%LOG_FILE%"
    echo  [ERREUR] Telechargement Python impossible.
    echo           Installez Python manuellement : https://www.python.org/downloads/
    pause & exit /b 1
)
echo        Installation silencieuse...
"%TEMP%\python_setup.exe" /quiet InstallAllUsers=0 PrependPath=1 Include_pip=1
del "%TEMP%\python_setup.exe" 2>nul
:: Recharger le PATH apres installation
for /f "tokens=2*" %%A in ('reg query "HKCU\Environment" /v PATH 2^>nul') do set "PATH=%%B;%PATH%"
python --version >nul 2>&1
if not errorlevel 1 ( set "PYTHON_EXE=python" & goto :python_found )
echo [%date% %time%] ERREUR : Python installe mais introuvable >> "%LOG_FILE%"
echo  [ERREUR] Python installe mais introuvable. Redemarrez le PC et relancez.
pause & exit /b 1

:python_found
:: Afficher et verifier la version
for /f "tokens=2 delims= " %%V in ('"%PYTHON_EXE%" --version 2^>^&1') do set "PY_VER=%%V"
echo  [OK] Python %PY_VER%
echo [%date% %time%] Python trouve : %PY_VER% >> "%LOG_FILE%"

:: Verification version minimum (3.10+)
for /f "tokens=1,2 delims=." %%A in ("%PY_VER%") do (
    set "PY_MAJ=%%A"
    set "PY_MIN=%%B"
)
set /a "PY_CHECK=PY_MAJ*100+PY_MIN"
set /a "MIN_CHECK=MIN_PY_MAJOR*100+MIN_PY_MINOR"
if !PY_CHECK! LSS !MIN_CHECK! (
    echo [%date% %time%] ERREUR : Python %PY_VER% trop ancien ^(minimum %MIN_PY_MAJOR%.%MIN_PY_MINOR%^) >> "%LOG_FILE%"
    echo.
    echo  [ERREUR] Python %PY_VER% detecte, mais JobHunter necessite Python %MIN_PY_MAJOR%.%MIN_PY_MINOR%+
    echo           Telechargez une version recente : https://www.python.org/downloads/
    pause & exit /b 1
)
echo        Version %PY_VER% ^>= %MIN_PY_MAJOR%.%MIN_PY_MINOR% OK
echo [%date% %time%] Version %PY_VER% OK ^(minimum %MIN_PY_MAJOR%.%MIN_PY_MINOR%^) >> "%LOG_FILE%"

:: ─── 2 : Venv ─────────────────────────────────────────────────────────────────
echo.
echo  [2/5] Environnement virtuel...
echo [%date% %time%] Etape 2 : venv >> "%LOG_FILE%"

if exist "%VENV_DIR%\Scripts\python.exe" (
    echo        Venv existant detecte, reutilisation.
    echo [%date% %time%] Venv existant reutilise >> "%LOG_FILE%"
    goto :venv_ok
)
if exist "%VENV_DIR%" (
    echo        Venv incomplet, suppression...
    echo [%date% %time%] Suppression venv incomplet >> "%LOG_FILE%"
    rmdir /s /q "%VENV_DIR%"
)
echo        Creation en cours...
"%PYTHON_EXE%" -m venv "%VENV_DIR%" >> "%LOG_FILE%" 2>&1
if errorlevel 1 (
    echo [%date% %time%] ERREUR : creation venv echouee >> "%LOG_FILE%"
    echo  [ERREUR] Impossible de creer le venv. Voir %LOG_FILE%
    pause & exit /b 1
)
echo  [OK] Venv cree.
echo [%date% %time%] Venv cree >> "%LOG_FILE%"

:venv_ok
for /f "delims=" %%V in ('"%VENV_DIR%\Scripts\python.exe" --version 2^>^&1') do (
    echo        Venv Python : %%V
    echo [%date% %time%] Venv Python : %%V >> "%LOG_FILE%"
)

:: ─── 3 : Dependances ──────────────────────────────────────────────────────────
echo.
echo  [3/5] Installation des dependances...
echo [%date% %time%] Etape 3 : dependances >> "%LOG_FILE%"

:: Mise a jour pip
echo        - Mise a jour de pip...
"%VENV_DIR%\Scripts\python.exe" -m pip install --upgrade pip >> "%LOG_FILE%" 2>&1

:: Installation depuis requirements.txt (source unique de verite)
if not exist "%APP_DIR%\requirements.txt" (
    echo [%date% %time%] ERREUR : requirements.txt introuvable >> "%LOG_FILE%"
    echo  [ERREUR] Fichier requirements.txt introuvable dans %APP_DIR%
    pause & exit /b 1
)
echo        - Installation des packages depuis requirements.txt...
"%VENV_DIR%\Scripts\python.exe" -m pip install -r "%APP_DIR%\requirements.txt" >> "%LOG_FILE%" 2>&1
if errorlevel 1 (
    echo [%date% %time%] ERREUR : pip install -r requirements.txt echoue >> "%LOG_FILE%"
    echo  [ERREUR] Installation des packages echouee. Voir %LOG_FILE%
    pause & exit /b 1
)

:: Afficher les versions installees
echo        Packages installes :
"%VENV_DIR%\Scripts\python.exe" -c "from importlib.metadata import version; pkgs=['PyQt6','PyQt6-WebEngine','requests','beautifulsoup4','lxml','winotify','openpyxl']; [print(f'         {p}: {version(p)}') for p in pkgs]" 2>nul
echo [%date% %time%] Packages installes OK >> "%LOG_FILE%"
echo  [OK] Dependances installees.

:: ─── 4 : Verification ────────────────────────────────────────────────────────
echo.
echo  [4/5] Verification de l'application...
echo [%date% %time%] Etape 4 : verification >> "%LOG_FILE%"

:: Verification des imports critiques
echo        - Verification des imports critiques...
"%VENV_DIR%\Scripts\python.exe" -c "import sys; sys.path.insert(0, r'%APP_DIR%'); import PyQt6.QtWidgets; import PyQt6.QtWebEngineWidgets; import requests; import bs4; import lxml; import winotify; import openpyxl; print('OK')" >> "%LOG_FILE%" 2>&1
if errorlevel 1 (
    echo [%date% %time%] ERREUR : verification imports echouee >> "%LOG_FILE%"
    echo  [ERREUR] Verification des imports echouee.
    echo           Diagnostic :
    "%VENV_DIR%\Scripts\python.exe" -c "import PyQt6.QtWidgets; print('         PyQt6 ............. OK')" 2>&1 || echo          PyQt6 ............. ERREUR
    "%VENV_DIR%\Scripts\python.exe" -c "import PyQt6.QtWebEngineWidgets; print('         PyQt6-WebEngine ... OK')" 2>&1 || echo          PyQt6-WebEngine ... ERREUR
    "%VENV_DIR%\Scripts\python.exe" -c "import requests; print('         requests .......... OK')" 2>&1 || echo          requests .......... ERREUR
    "%VENV_DIR%\Scripts\python.exe" -c "import bs4; print('         beautifulsoup4 .... OK')" 2>&1 || echo          beautifulsoup4 .... ERREUR
    "%VENV_DIR%\Scripts\python.exe" -c "import lxml; print('         lxml .............. OK')" 2>&1 || echo          lxml .............. ERREUR
    "%VENV_DIR%\Scripts\python.exe" -c "import winotify; print('         winotify .......... OK')" 2>&1 || echo          winotify .......... ERREUR
    "%VENV_DIR%\Scripts\python.exe" -c "import openpyxl; print('         openpyxl .......... OK')" 2>&1 || echo          openpyxl .......... ERREUR
    echo.
    echo           Voir %LOG_FILE% pour les details.
    pause & exit /b 1
)
echo  [OK] Tous les imports valides.
echo [%date% %time%] Verification imports OK >> "%LOG_FILE%"

:: Initialisation base de donnees
echo        - Initialisation de la base de donnees...
"%VENV_DIR%\Scripts\python.exe" -c "import sys; sys.path.insert(0, r'%APP_DIR%'); from database.db_manager import init_db; init_db(); print('OK')" >> "%LOG_FILE%" 2>&1
if errorlevel 1 (
    echo  [~] Init DB echouee (sera tentee au lancement).
    echo [%date% %time%] AVERTISSEMENT : init_db echoue >> "%LOG_FILE%"
) else (
    echo  [OK] Base de donnees prete.
    echo [%date% %time%] Init DB OK >> "%LOG_FILE%"
)

:: ─── 5 : Lanceurs et raccourcis ──────────────────────────────────────────────
echo.
echo  [5/5] Creation des lanceurs et raccourcis...
echo [%date% %time%] Etape 5 : lanceurs >> "%LOG_FILE%"

:: Creer les lanceurs (vbs + bat)
"%VENV_DIR%\Scripts\python.exe" "%APP_DIR%\create_launchers.py" "%APP_DIR%" "%VENV_DIR%" >> "%LOG_FILE%" 2>&1
if errorlevel 1 (
    echo [%date% %time%] ERREUR : ecriture lanceurs >> "%LOG_FILE%"
    echo  [ERREUR] Creation des lanceurs echouee. Voir %LOG_FILE%
    pause & exit /b 1
)
echo  [OK] Lanceurs crees.
echo [%date% %time%] Lanceurs crees >> "%LOG_FILE%"

:: Determiner si l'icone existe
set "ICON_CMD="
if exist "%ICON%" (
    set "ICON_CMD=$s.IconLocation='%ICON%';"
    echo        Icone : %ICON%
    echo [%date% %time%] Icone : %ICON% >> "%LOG_FILE%"
)

:: Raccourci Bureau (pointe vers .vbs = aucune fenetre CMD)
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
    "$ws=New-Object -ComObject WScript.Shell;" ^
    "$s=$ws.CreateShortcut([Environment]::GetFolderPath('Desktop')+'\JobHunter.lnk');" ^
    "$s.TargetPath='wscript.exe';" ^
    "$s.Arguments='\"\"\"'+'%APP_DIR%\JobHunter.vbs'+'\"\"\"';" ^
    "$s.WorkingDirectory='%APP_DIR%';" ^
    "$s.Description='JobHunter - Recherche emploi Suisse/France';" ^
    "%ICON_CMD%" ^
    "$s.Save()" >> "%LOG_FILE%" 2>&1

:: Raccourci Menu Demarrer
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
    "$ws=New-Object -ComObject WScript.Shell;" ^
    "$s=$ws.CreateShortcut([Environment]::GetFolderPath('Programs')+'\JobHunter.lnk');" ^
    "$s.TargetPath='wscript.exe';" ^
    "$s.Arguments='\"\"\"'+'%APP_DIR%\JobHunter.vbs'+'\"\"\"';" ^
    "$s.WorkingDirectory='%APP_DIR%';" ^
    "$s.Description='JobHunter - Recherche emploi Suisse/France';" ^
    "%ICON_CMD%" ^
    "$s.Save()" >> "%LOG_FILE%" 2>&1

echo  [OK] Raccourcis Bureau + Menu Demarrer crees.
echo [%date% %time%] Raccourcis crees >> "%LOG_FILE%"

:: ─── Fin ────────────────────────────────────────────────────────────────────
echo [%date% %time%] === INSTALLATION TERMINEE === >> "%LOG_FILE%"

echo.
echo  ============================================
echo     Installation terminee avec succes !
echo  ============================================
echo.
echo   Raccourci sur le Bureau : JobHunter
echo   Lanceur normal : %APP_DIR%\JobHunter.bat
echo   Lanceur debug  : %APP_DIR%\JobHunter_DEBUG.bat
echo.
echo   En cas de probleme :
echo     1. Lancez JobHunter_DEBUG.bat
echo     2. Consultez runtime_log.txt
echo     3. Consultez install_log.txt
echo.
set /p "LAUNCH=  Lancer JobHunter maintenant ? (O/N) : "
if /i "!LAUNCH!"=="O" (
    echo [%date% %time%] Lancement utilisateur >> "%LOG_FILE%"
    start "" "%VENV_DIR%\Scripts\pythonw.exe" "%APP_DIR%\main.py"
)
echo.
pause
endlocal
