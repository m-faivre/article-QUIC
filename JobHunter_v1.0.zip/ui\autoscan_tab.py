"""
Onglet auto-scan — affiche les résultats d'un template automatique.
Contient un splitter ResultsPanel | DetailPanel, exactement comme
l'onglet de recherche principal, mais sans le SearchPanel.
"""
from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtWidgets import QWidget, QHBoxLayout, QSplitter

from models.models import Job
from scrapers.aggregator import DetailWorker, DistanceWorker
from ui.results_panel import ResultsPanel
from ui.detail_panel import DetailPanel
import utils.logger as log


class AutoScanTab(QWidget):
    """Widget autonome pour un onglet auto-scan (un par template)."""

    # Re-émis vers MainWindow pour gérer candidatures / sauvegarde
    save_job_requested    = pyqtSignal(object)   # Job
    application_changed   = pyqtSignal(object)   # Job

    def __init__(self, template_name: str, parent=None):
        super().__init__(parent)
        self.template_name = template_name
        self._detail_worker: DetailWorker | None = None
        self._distance_worker: DistanceWorker | None = None
        self._build_ui()

    def _build_ui(self):
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        splitter = QSplitter(Qt.Orientation.Horizontal)
        splitter.setChildrenCollapsible(False)

        # Panneau résultats
        self.results_panel = ResultsPanel()
        self.results_panel.job_selected.connect(self._on_job_selected)
        self.results_panel.save_job_requested.connect(self.save_job_requested.emit)
        self.results_panel.application_changed.connect(self.application_changed.emit)
        splitter.addWidget(self.results_panel)

        # Panneau détail
        self.detail_panel = DetailPanel()
        self.detail_panel.quick_tag_requested.connect(self.application_changed.emit)
        self.detail_panel.save_job_requested.connect(self.save_job_requested.emit)
        splitter.addWidget(self.detail_panel)

        splitter.setSizes([420, 700])
        layout.addWidget(splitter)

    # ── API publique ──────────────────────────────────────────────────────────

    def add_jobs(self, jobs: list):
        """Ajoute des offres dans le ResultsPanel."""
        self.results_panel.add_jobs(jobs)

    def get_job_count(self) -> int:
        return len(self.results_panel._jobs)

    def reload_applied(self):
        """Rafraîchit les marqueurs 'postulé' dans la liste."""
        try:
            self.results_panel.reload_applied()
        except Exception:
            pass

    def refresh_tag_status(self, job):
        """Rafraîchit le bouton tag dans le detail panel."""
        try:
            self.detail_panel.refresh_tag_status(job)
        except Exception:
            pass

    # ── Sélection d'offre ─────────────────────────────────────────────────────

    def _on_job_selected(self, job: Job):
        self.detail_panel.show_job(job)
        self.detail_panel.show_loading(True)

        # Detail worker
        if self._detail_worker and self._detail_worker.isRunning():
            self._detail_worker.wait(2000)
        self._detail_worker = DetailWorker(job)
        self._detail_worker.detail_ready.connect(self._on_detail_ready)
        self._detail_worker.start()

        # Distance worker
        if self._distance_worker and self._distance_worker.isRunning():
            self._distance_worker.wait(2000)
        self._distance_worker = DistanceWorker(job)
        self._distance_worker.distance_ready.connect(self._on_distance_ready)
        self._distance_worker.start()

    def _on_detail_ready(self, job):
        self.detail_panel.show_loading(False)
        self.detail_panel.update_description(job)

    def _on_distance_ready(self, job, result):
        self.detail_panel.update_distance(job, result)

    # ── Cleanup ───────────────────────────────────────────────────────────────

    def cleanup(self):
        """Arrête les workers en cours."""
        if self._detail_worker and self._detail_worker.isRunning():
            self._detail_worker.wait(2000)
        if self._distance_worker and self._distance_worker.isRunning():
            self._distance_worker.wait(2000)
