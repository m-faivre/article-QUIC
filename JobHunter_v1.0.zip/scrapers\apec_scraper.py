"""
APEC — Scraper pour le site apec.fr (Angular SPA).

Endpoint : POST /cms/webservices/rechercheOffre (JSON body)

Localisation :
  - geo.api.gouv.fr → codeDepartement (int) + coordonnées GPS (lat/lon)
  - lieux = [<numéro département>]  (ex: [1] pour l'Ain)
  - pointGeolocDeReference = {latitude, longitude, distance}
  - distance est un sous-champ de pointGeolocDeReference (PAS au niveau racine !)

Distances autorisées par l'APEC : 5, 10, 15, 25, 50, 100 km.
"""
import json
import time
from typing import List, Optional

import utils.logger as log
from models.models import Job
from scrapers.base_scraper import BaseScraper

BASE = "https://www.apec.fr"

# Endpoint recherche APEC — POST avec body JSON
SEARCH_URL = f"{BASE}/cms/webservices/rechercheOffre"

# IDs typesConvention depuis l'URL confirmée par l'utilisateur
ALL_CONTRACT_IDS = [143684, 143685, 143686, 143687, 143706]

CONTRACT_IDS = {
    "CDI":        [143684],
    "CDD":        [143685],
    "Freelance":  [143686],
    "Alternance": [143687],
    "Stage":      [143706],
}

# Valeurs de distance autorisées par l'APEC
ALLOWED_DISTANCES = [5, 10, 15, 25, 50, 100]

# Cache : "ville" → {"dept": int, "lat": float, "lon": float}
_geo_cache: dict = {}


def _snap_distance(radius: int) -> int:
    """Arrondit le rayon à la valeur APEC autorisée la plus proche (par excès)."""
    for d in ALLOWED_DISTANCES:
        if radius <= d:
            return d
    return ALLOWED_DISTANCES[-1]  # 100 km max


class ApecScraper(BaseScraper):
    SOURCE_NAME = "APEC"

    def __init__(self):
        super().__init__()
        self.session.headers.update({
            "Accept":           "application/json, text/plain, */*",
            "Accept-Language":  "fr-FR,fr;q=0.9,en;q=0.8",
            "Content-Type":    "application/json",
            "X-Requested-With": "XMLHttpRequest",
            "Origin":           BASE,
            "Referer":          f"{BASE}/candidat/recherche-emploi.html/emploi",
        })

    # ── Géocodage via geo.api.gouv.fr ──────────────────────────────────────────

    def _resolve_location(self, location: str) -> dict:
        """
        Résout un nom de ville via geo.api.gouv.fr.
        Retourne {"dept": int, "lat": float, "lon": float} ou {} si échec.

        L'API APEC utilise :
          - lieux = [<numéro département>]  (ex: [1] pour l'Ain)
          - pointGeolocDeReference = {latitude, longitude, distance}
        """
        if not location:
            return {}
        key = location.lower().strip()
        if key in _geo_cache:
            return _geo_cache[key]

        try:
            r = self.session.get(
                "https://geo.api.gouv.fr/communes",
                params={
                    "nom": location,
                    "fields": "nom,codeDepartement,centre",
                    "limit": 1,
                    "boost": "population",
                },
                headers={k: v for k, v in self.session.headers.items()
                         if k.lower() != "content-type"},
                timeout=8,
            )
            if r.status_code == 200:
                communes = r.json()
                if communes:
                    commune = communes[0]
                    dept_str = commune.get("codeDepartement", "")
                    centre = commune.get("centre", {})
                    coords = centre.get("coordinates", [])

                    if dept_str and len(coords) == 2:
                        # geo.api.gouv.fr retourne [lon, lat] (GeoJSON)
                        lon, lat = coords
                        dept = int(dept_str)
                        result = {"dept": dept, "lat": lat, "lon": lon}
                        log.info(
                            f"[APEC] '{location}' → dept {dept:02d} "
                            f"({commune.get('nom', '')}) GPS ({lat:.4f}, {lon:.4f})"
                        )
                        _geo_cache[key] = result
                        return result
        except Exception as e:
            log.debug(f"[APEC] geo.api.gouv.fr échoué : {e}")

        log.warning(f"[APEC] Lieu '{location}' non résolu → recherche nationale")
        _geo_cache[key] = {}
        return {}

    # ── Recherche ─────────────────────────────────────────────────────────────

    def search(self, keywords, location, radius=30, contract_type="Tous", max_results=50):
        geo = self._resolve_location(location) if location else {}
        conv_ids = CONTRACT_IDS.get(contract_type, ALL_CONTRACT_IDS)
        distance = _snap_distance(radius)
        n_results = min(max_results, 50)

        log.info(
            f"[APEC] Recherche : '{keywords}' | lieu={location} → dept={geo.get('dept')} | "
            f"distance={radius}→{distance}km | contrat={contract_type}"
        )

        # ── Body JSON pour le POST ──
        payload = {
            "motsCles":        keywords,
            "typeClient":      "CADRE",
            "typesConvention": conv_ids,
            "sorts":           [{"type": "SCORE", "direction": "DESCENDING"}],
            "pagination":      {"range": n_results, "startIndex": 0},
            "activeFiltre":    True,
        }

        # Localisation : département + GPS + distance
        if "dept" in geo:
            payload["lieux"] = [geo["dept"]]
            if "lat" in geo and "lon" in geo:
                payload["pointGeolocDeReference"] = {
                    "latitude":  geo["lat"],
                    "longitude": geo["lon"],
                    "distance":  distance,
                }

        log.debug(f"[APEC] POST {SEARCH_URL}")
        log.debug(f"[APEC]   payload: {json.dumps(payload, ensure_ascii=False)}")

        try:
            time.sleep(1.0)
            r = self.session.post(SEARCH_URL, json=payload, timeout=15)
            log.info(f"[APEC] → {r.status_code}  {len(r.content)} octets")
        except Exception as e:
            log.error(f"[APEC] Requête échouée : {e}")
            return []

        if r.status_code != 200:
            log.warning(f"[APEC] HTTP {r.status_code}")
            try:
                err = r.json().get("message", "")[:200]
                log.debug(f"[APEC] Erreur serveur : {err}")
            except Exception:
                pass
            return []

        try:
            data = r.json()
        except Exception:
            log.warning("[APEC] Réponse non-JSON")
            return []

        return self._parse_response(data, max_results)

    # ── Parsing de la réponse ─────────────────────────────────────────────────

    def _parse_response(self, data: dict, max_results: int) -> List[Job]:
        """Parse la réponse JSON APEC."""
        if isinstance(data, list):
            items = data
        elif isinstance(data, dict):
            items = (data.get("resultats") or data.get("offres") or
                     data.get("results")   or data.get("data")   or [])
        else:
            log.warning(f"[APEC] Type de réponse inattendu : {type(data)}")
            return []

        nb_total = data.get("totalCount") or data.get("nbTotal") or data.get("count")
        if nb_total is not None:
            log.info(f"[APEC] {nb_total} offres totales")
        log.info(f"[APEC] {len(items) if isinstance(items, list) else '?'} offres reçues")

        if not items:
            if isinstance(data, dict):
                log.debug(f"[APEC] Clés réponse : {list(data.keys())}")
            return []

        return self._parse_items(items, max_results)

    # ── Parsing des items ─────────────────────────────────────────────────────

    def _parse_items(self, items, max_results) -> List[Job]:
        jobs = []
        for o in items[:max_results]:
            if not isinstance(o, dict):
                continue
            title = (o.get("intitule") or o.get("titre") or o.get("title") or
                     o.get("label")    or o.get("jobTitle", ""))
            if not title:
                continue

            num = o.get("numeroOffre") or o.get("numOffre") or o.get("id", "")
            url = (f"{BASE}/candidat/recherche-emploi.html/emploi/detail-offre/{num}"
                   if num else o.get("url", ""))

            def _s(v):
                return v.get("libelle", "") if isinstance(v, dict) else str(v or "")

            raw_date = (o.get("dateCreation") or o.get("datePublication") or
                        o.get("date") or "")
            posted_date = str(raw_date)[:10] if raw_date else ""

            # Description : texteOffre contient un résumé fourni par l'API
            description = self._clean(o.get("texteOffre", ""))

            # Entreprise
            company = self._clean_company(
                _s(o.get("nomCommercial") or o.get("nomEntreprise") or o.get("entreprise", ""))
            )

            # Infos entreprise (company_info) — le detail_panel attend
            # les clés "description" et "url" pour l'affichage.
            company_info = {}
            if company:
                company_info["name"] = company
                company_info["description"] = f"Employeur : {company}"
            if o.get("offreConfidentielle"):
                company_info["description"] = "Offre confidentielle"

            jobs.append(Job(
                id=self._make_id("APEC", str(num) or url or title),
                title=self._clean(title),
                company=company,
                location=self._clean(
                    _s(o.get("lieuTravail") or o.get("lieuTexte") or o.get("lieu", ""))
                ),
                contract_type=self._clean(_s(o.get("typeContrat") or o.get("contrat", ""))),
                salary=self._clean(_s(o.get("salaire") or o.get("salaireTexte", ""))),
                source="APEC",
                url=url,
                posted_date=posted_date,
                description=description,
                company_info=company_info,
            ))
        log.info(f"[APEC] {len(jobs)} offres parsées")
        return jobs

    # ── Détail complet ────────────────────────────────────────────────────────
    # L'APEC est un SPA Angular : la page HTML ne contient pas le contenu
    # des offres (rendu côté client). L'API de détail requiert une session
    # authentifiée (401). On se contente du texteOffre fourni par la
    # recherche, qui est déjà extrait dans _parse_items.

    def get_details(self, job: Job) -> Job:
        return job
