"""
Agrégateur — orchestre tous les scrapers actifs.

Sources actives (5) :
  France Travail  — HTML, li[data-id-offre], fiable
  HelloWork       — HTML, ul[aria-label='liste des offres'], fiable
  WTTJ            — API Algolia publique, très fiable
  APEC            — Angular, API à détecter (best-effort)
  Meteojob        — REST API, fiable

Sources supprimées (toujours bloquées) :
  Monster, Indeed, LinkedIn, Cadremploi, Jobijoba, Regionsjob
"""
import copy
from PyQt6.QtCore import QThread, pyqtSignal
import utils.logger as log
from models.models import Job
from scrapers.france_travail_scraper import FranceTravailScraper
from scrapers.hellowork_scraper      import HelloWorkScraper
from scrapers.wttj_scraper           import WelcomeJungleScraper
from scrapers.apec_scraper           import ApecScraper
from scrapers.meteojob_scraper       import MeteojobScraper
from scrapers.jobup_scraper          import JobupScraper
from scrapers.jobsch_scraper         import JobsChScraper

# Mapping nom → classe (pas des instances, pour la thread-safety)
_SCRAPER_CLASSES = {
    "France Travail":        FranceTravailScraper,
    "HelloWork":             HelloWorkScraper,
    "Welcome to the Jungle": WelcomeJungleScraper,
    "APEC":                  ApecScraper,
    "Meteojob":              MeteojobScraper,
    "Jobup.ch":              JobupScraper,
    "Jobs.ch":               JobsChScraper,
}

# Sources pour la recherche France uniquement
_SWISS_SOURCES = {"Jobup.ch", "Jobs.ch"}
ALL_SOURCE_NAMES = [n for n in _SCRAPER_CLASSES if n not in _SWISS_SOURCES]

# Sources pour la recherche Suisse
SWISS_SOURCE_NAMES = [n for n in _SCRAPER_CLASSES if n in _SWISS_SOURCES]

# Rétro-compatibilité : dictionnaire d'instances pour les imports existants
# (utilisé uniquement pour get_details dans DetailWorker — accès séquentiel)
ALL_SCRAPERS = {name: cls() for name, cls in _SCRAPER_CLASSES.items()}


def _create_scraper(name: str):
    """Crée une nouvelle instance de scraper (thread-safe)."""
    cls = _SCRAPER_CLASSES.get(name)
    return cls() if cls else None


class SearchWorker(QThread):
    jobs_batch   = pyqtSignal(list)
    source_done  = pyqtSignal(str, int)
    source_error = pyqtSignal(str, str)
    all_done     = pyqtSignal(int)

    def __init__(self, keywords, location, radius, contract_type,
                 sources, max_per_source=50):
        super().__init__()
        self.keywords       = keywords
        self.location       = location
        self.radius         = radius
        self.contract_type  = contract_type
        self.sources        = sources
        self.max_per_source = max_per_source
        self._cancelled     = False

    def cancel(self):
        self._cancelled = True

    def run(self):
        total = 0
        log.info(
            f"Recherche : '{self.keywords}' @ '{self.location or 'France entière'}' "
            f"— {len(self.sources)} sources"
        )
        for name in self.sources:
            if self._cancelled:
                log.info("Recherche annulée par l'utilisateur")
                break
            # Nouvelle instance par source → pas de partage de Session entre threads
            scraper = _create_scraper(name)
            if scraper is None:
                log.warning(f"Source '{name}' inconnue ou désactivée")
                continue
            log.info(f"━━ Interrogation de {name}…")
            try:
                jobs = scraper.search(
                    keywords     = self.keywords,
                    location     = self.location,
                    radius       = self.radius,
                    contract_type= self.contract_type,
                    max_results  = self.max_per_source,
                )
                total += len(jobs)
                self.jobs_batch.emit(jobs)
                self.source_done.emit(name, len(jobs))
            except Exception as e:
                log.error(f"[{name}] Exception non gérée : {e}")
                self.source_error.emit(name, str(e))

        log.info(f"Recherche terminée — {total} offres brutes au total")
        self.all_done.emit(total)


class DetailWorker(QThread):
    detail_ready = pyqtSignal(object)

    def __init__(self, job: Job):
        super().__init__()
        self.job = copy.deepcopy(job)

    def run(self):
        scraper = _create_scraper(self.job.source)
        if scraper:
            try:
                self.job = scraper.get_details(self.job)
            except Exception as e:
                log.warning(f"get_details échoué ({self.job.source}) : {e}")
        self.detail_ready.emit(self.job)


class DistanceWorker(QThread):
    """Calcule la distance routière domicile→poste en arrière-plan."""
    distance_ready = pyqtSignal(object, object)

    def __init__(self, job: Job):
        super().__init__()
        self.job = copy.deepcopy(job)

    def run(self):
        try:
            from utils.geocoder import distance_from_home
            result = distance_from_home(self.job.location)
        except Exception as e:
            log.debug(f"[Distance] Erreur : {e}")
            result = None
        self.distance_ready.emit(self.job, result)
