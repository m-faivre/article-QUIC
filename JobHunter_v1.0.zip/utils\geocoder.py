"""
Géocodage et calcul de distance routière.

Sources utilisées (sans clé API) :
  - geo.api.gouv.fr    → coordonnées GPS d'une ville/adresse française
  - router.project-osrm.org → distance routière et durée entre deux points

Fonctions publiques :
  geocode(query)           → (lat, lng) ou None
  road_distance(p1, p2)    → {"km": float, "minutes": int} ou None
  distance_from_home(job)  → {"km": float, "minutes": int, "label": str} ou None
"""
import re
import math
import requests
from typing import Optional, Tuple

import utils.logger as log
import database.db_manager as db

# APIs publiques sans clé
_GEOCODE_COMMUNE_URL = "https://geo.api.gouv.fr/communes"
_GEOCODE_SEARCH_URL  = "https://api-adresse.data.gouv.fr/search/"   # BAN
_OSRM_URL = "https://router.project-osrm.org/route/v1/driving/{lng1},{lat1};{lng2},{lat2}"

_geocode_cache: dict = {}
_session: Optional[requests.Session] = None


def _get_session() -> requests.Session:
    global _session
    if _session is None:
        _session = requests.Session()
        _session.headers.update({
            "User-Agent": "JobHunter/1.0 (contact: jobhunter@local)",
        })
    return _session


def _haversine(lat1, lng1, lat2, lng2) -> float:
    """Distance à vol d'oiseau en km (fallback si OSRM indisponible)."""
    R = 6371.0
    dlat = math.radians(lat2 - lat1)
    dlng = math.radians(lng2 - lng1)
    a = (math.sin(dlat / 2) ** 2 +
         math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) *
         math.sin(dlng / 2) ** 2)
    return R * 2 * math.asin(math.sqrt(a))


def geocode(query: str) -> Optional[Tuple[float, float]]:
    """
    Retourne (lat, lng) pour une ville ou adresse française.
    Ordre de recherche : mémoire → DB → geo.api.gouv.fr → BAN.
    Retourne None si non trouvé.
    """
    if not query or not query.strip():
        return None

    key = query.lower().strip()

    # 1. Cache mémoire
    if key in _geocode_cache:
        return _geocode_cache[key]

    # 2. Cache DB (persistant)
    try:
        cached = db.get_cached_geocode(f"fr:{key}")
        if cached is not None:
            _geocode_cache[key] = cached
            log.debug(f"[Geocoder] '{query}' → {cached} (DB cache)")
            return cached
    except Exception:
        pass

    sess = _get_session()

    # 3. Communes (plus fiable pour les noms de villes)
    try:
        r = sess.get(
            _GEOCODE_COMMUNE_URL,
            params={"nom": query, "fields": "centre,codesPostaux", "limit": 1, "boost": "population"},
            timeout=6,
        )
        if r.status_code == 200:
            data = r.json()
            if data:
                coords = data[0].get("centre", {}).get("coordinates", [])
                if len(coords) == 2:
                    result = (coords[1], coords[0])  # GeoJSON: [lng, lat] → (lat, lng)
                    _geocode_cache[key] = result
                    try:
                        db.save_cached_geocode(f"fr:{key}", result[0], result[1], "commune")
                    except Exception:
                        pass
                    log.debug(f"[Geocoder] '{query}' → {result} (commune)")
                    return result
    except Exception as e:
        log.debug(f"[Geocoder] commune '{query}' échoué : {e}")

    # 4. BAN (Base Adresse Nationale) — pour adresses complètes
    try:
        r = sess.get(
            _GEOCODE_SEARCH_URL,
            params={"q": query, "limit": 1},
            timeout=6,
        )
        if r.status_code == 200:
            feats = r.json().get("features", [])
            if feats:
                coords = feats[0]["geometry"]["coordinates"]  # [lng, lat]
                result = (coords[1], coords[0])
                _geocode_cache[key] = result
                try:
                    db.save_cached_geocode(f"fr:{key}", result[0], result[1], "BAN")
                except Exception:
                    pass
                log.debug(f"[Geocoder] '{query}' → {result} (BAN)")
                return result
    except Exception as e:
        log.debug(f"[Geocoder] BAN '{query}' échoué : {e}")

    log.debug(f"[Geocoder] '{query}' non trouvé")
    return None


def _route_key(p1: Tuple[float, float], p2: Tuple[float, float]) -> str:
    """Clé de cache pour un couple de points (~111 m de précision)."""
    return (f"{round(p1[0], 3)},{round(p1[1], 3)}"
            f"→{round(p2[0], 3)},{round(p2[1], 3)}")


def road_distance(
    p1: Tuple[float, float],
    p2: Tuple[float, float],
    timeout: int = 8,
) -> Optional[dict]:
    """
    Calcule la distance routière entre deux points (lat, lng).
    Ordre : cache DB → OSRM public → fallback haversine.
    Retourne {"km": float, "minutes": int} ou None si indisponible.
    """
    lat1, lng1 = p1
    lat2, lng2 = p2

    # 1. Cache DB (persistant — uniquement résultats OSRM fiables)
    rkey = _route_key(p1, p2)
    try:
        cached = db.get_cached_route(rkey)
        if cached is not None:
            log.debug(
                f"[Geocoder] Route DB cache hit : {cached['km']} km, "
                f"{cached['minutes']} min"
            )
            return cached
    except Exception:
        pass

    # 2. OSRM
    url = _OSRM_URL.format(lat1=lat1, lng1=lng1, lat2=lat2, lng2=lng2)
    try:
        r = _get_session().get(
            url,
            params={"overview": "false", "annotations": "false"},
            timeout=timeout,
        )
        if r.status_code == 200:
            data = r.json()
            if data.get("code") == "Ok" and data.get("routes"):
                route = data["routes"][0]
                km      = round(route["distance"] / 1000.0, 1)
                minutes = int(route["duration"] / 60)
                log.debug(f"[Geocoder] Distance routière : {km} km, {minutes} min")
                # Persister en DB (résultat fiable)
                try:
                    db.save_cached_route(rkey, km, minutes)
                except Exception:
                    pass
                return {"km": km, "minutes": minutes}
    except Exception as e:
        log.debug(f"[Geocoder] OSRM échoué : {e}")

    # 3. Fallback vol d'oiseau (non persisté → retenté au prochain appel)
    km = _haversine(lat1, lng1, lat2, lng2)
    log.debug(f"[Geocoder] Distance vol d'oiseau : {km:.1f} km (fallback)")
    return {"km": round(km, 1), "minutes": None, "as_crow": True}


def _clean_location(location: str) -> str:
    """Nettoie le champ location d'une offre pour améliorer le géocodage."""
    if not location:
        return ""
    # Retirer codes dept : "69 - Lyon" → "Lyon"
    location = re.sub(r'^\d{2,3}\s*[-–]\s*', '', location).strip()
    # Retirer arrondissements : "Lyon 9e Arrondissement" → "Lyon"
    location = re.sub(r'\s+\d+[eè]?\s+arrondissement', '', location, flags=re.IGNORECASE).strip()
    return location


def distance_from_home(job_location: str) -> Optional[dict]:
    """
    Calcule la distance entre le domicile configuré et le lieu du poste.
    Retourne {km, minutes, label} ou None si domicile non configuré.
    """
    # Récupérer le domicile depuis les settings
    home_lat = db.get_setting("home_lat", "")
    home_lng = db.get_setting("home_lng", "")
    home_city = db.get_setting("home_city", "")

    if not home_lat or not home_lng:
        return None

    try:
        p_home = (float(home_lat), float(home_lng))
    except ValueError:
        return None

    cleaned = _clean_location(job_location)
    if not cleaned:
        return None

    p_job = geocode(cleaned)
    if not p_job:
        return None

    result = road_distance(p_home, p_job)
    if result is None:
        return None

    # Formater le label
    km = result["km"]
    minutes = result.get("minutes")
    as_crow = result.get("as_crow", False)

    if minutes is not None:
        h, m = divmod(minutes, 60)
        if h > 0:
            duration = f"{h}h{m:02d}"
        else:
            duration = f"{m} min"
        label = f"🚗  {km} km  ·  {duration} de {home_city or 'chez vous'}"
    else:
        suffix = " (vol d'oiseau)" if as_crow else ""
        label = f"📏  {km} km{suffix}"

    return {"km": km, "minutes": minutes, "label": label}
