"""
Onglet Debug Distances — vérification visuelle du calcul de distance frontière.

Permet de saisir un lieu en France et un lieu en Suisse, puis affiche :
  - Les coordonnées géocodées
  - Le point de frontière retenu (+ top 5)
  - La distance haversine et routière (OSRM)
  - Une carte Leaflet avec les 3 points
"""
import math

from PyQt6.QtCore import Qt, QThread, pyqtSignal
from PyQt6.QtWidgets import (
    QWidget, QHBoxLayout, QVBoxLayout, QLabel,
    QLineEdit, QPushButton, QTextEdit, QFrame,
    QScrollArea, QSizePolicy,
)
from PyQt6.QtWebEngineWidgets import QWebEngineView

import utils.logger as log
from utils.geocoder import geocode as geocode_france, road_distance
from utils.border_distance import (
    geocode_swiss, find_nearest_crossing, _haversine,
)
from data.border_crossings import BORDER_CROSSINGS


# ─── Carte Leaflet (HTML inline) ────────────────────────────────────────────

_LEAFLET_HTML = """<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"/>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<style>
  html, body, #map { margin:0; padding:0; width:100%; height:100%; }
  body { background: #1e1e2e; }
</style>
</head>
<body>
<div id="map"></div>
<script>
var map = L.map('map').setView([46.8, 6.6], 8);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '© OpenStreetMap',
    maxZoom: 18
}).addTo(map);

var markers = L.layerGroup().addTo(map);
var polyline = null;

function clearMap() {
    markers.clearLayers();
    if (polyline) { map.removeLayer(polyline); polyline = null; }
}

function makeIcon(color) {
    return L.divIcon({
        className: '',
        html: '<div style="background:'+color+';width:14px;height:14px;border-radius:50%;border:2px solid #fff;box-shadow:0 0 4px rgba(0,0,0,.5);"></div>',
        iconSize: [18, 18],
        iconAnchor: [9, 9]
    });
}

function updateMap(frLat, frLng, chLat, chLng, crLat, crLng, crName, topCrossings) {
    clearMap();

    // Markers
    var mFr = L.marker([frLat, frLng], {icon: makeIcon('#89b4fa')})
        .bindPopup('<b>🇫🇷 France</b><br>'+frLat.toFixed(4)+', '+frLng.toFixed(4));
    var mCh = L.marker([chLat, chLng], {icon: makeIcon('#f38ba8')})
        .bindPopup('<b>🇨🇭 Suisse</b><br>'+chLat.toFixed(4)+', '+chLng.toFixed(4));
    var mCr = L.marker([crLat, crLng], {icon: makeIcon('#a6e3a1')})
        .bindPopup('<b>🚗 '+crName+'</b><br>'+crLat.toFixed(4)+', '+crLng.toFixed(4));

    markers.addLayer(mFr);
    markers.addLayer(mCh);
    markers.addLayer(mCr);

    // Top crossings (petits markers gris)
    if (topCrossings) {
        for (var i = 0; i < topCrossings.length; i++) {
            var tc = topCrossings[i];
            var m = L.marker([tc.lat, tc.lng], {icon: makeIcon('#6c7086')})
                .bindPopup('#'+(i+1)+' '+tc.name+' ('+tc.km+' km)');
            markers.addLayer(m);
        }
    }

    // Polyline FR → crossing → CH
    polyline = L.polyline(
        [[frLat, frLng], [crLat, crLng], [chLat, chLng]],
        {color: '#cba6f7', weight: 2, dashArray: '8 4', opacity: 0.8}
    ).addTo(map);

    // Fit bounds
    var bounds = L.latLngBounds([[frLat, frLng], [chLat, chLng], [crLat, crLng]]);
    map.fitBounds(bounds, {padding: [40, 40]});
}
</script>
</body>
</html>"""


# ─── Worker ──────────────────────────────────────────────────────────────────

class DebugDistanceWorker(QThread):
    """Géocode les deux lieux et calcule toutes les infos de distance."""

    finished = pyqtSignal(dict)
    error = pyqtSignal(str)

    def __init__(self, lieu_fr: str, lieu_ch: str):
        super().__init__()
        self._lieu_fr = lieu_fr
        self._lieu_ch = lieu_ch

    def run(self):
        try:
            result = {}

            # 1. Géocodage France
            coords_fr = geocode_france(self._lieu_fr)
            if coords_fr is None:
                self.error.emit(f"Impossible de géocoder le lieu français : «{self._lieu_fr}»")
                return
            result["fr_lat"], result["fr_lng"] = coords_fr
            result["fr_input"] = self._lieu_fr

            # 2. Géocodage Suisse
            coords_ch = geocode_swiss(self._lieu_ch)
            if coords_ch is None:
                self.error.emit(f"Impossible de géocoder le lieu suisse : «{self._lieu_ch}»")
                return
            result["ch_lat"], result["ch_lng"] = coords_ch
            result["ch_input"] = self._lieu_ch

            # 3. Haversine directe FR ↔ CH
            result["direct_haversine_km"] = round(
                _haversine(result["fr_lat"], result["fr_lng"],
                           result["ch_lat"], result["ch_lng"]), 1
            )

            # 4. Crossing le plus proche du lieu CH
            crossing = find_nearest_crossing(result["ch_lat"], result["ch_lng"])
            result["crossing_name"] = crossing["name"]
            result["crossing_lat"] = crossing["lat"]
            result["crossing_lng"] = crossing["lng"]
            result["crossing_french_town"] = crossing["french_town"]
            result["crossing_french_lat"] = crossing["french_lat"]
            result["crossing_french_lng"] = crossing["french_lng"]
            result["crossing_crow_km"] = crossing["crow_km"]

            # 5. Top 5 crossings
            all_crossings = []
            for c in BORDER_CROSSINGS:
                km = _haversine(result["ch_lat"], result["ch_lng"], c["lat"], c["lng"])
                all_crossings.append({
                    "name": c["name"],
                    "french_town": c["french_town"],
                    "lat": c["lat"],
                    "lng": c["lng"],
                    "crow_km": round(km, 1),
                })
            all_crossings.sort(key=lambda x: x["crow_km"])
            result["top_crossings"] = all_crossings[:5]

            # 6. Distance routière OSRM : ville française du crossing → lieu CH
            p_french = (crossing["french_lat"], crossing["french_lng"])
            p_ch = (result["ch_lat"], result["ch_lng"])
            osrm = road_distance(p_french, p_ch, timeout=10)
            if osrm:
                result["osrm_km"] = osrm["km"]
                result["osrm_minutes"] = osrm.get("minutes")
                result["osrm_as_crow"] = osrm.get("as_crow", False)
            else:
                result["osrm_km"] = None
                result["osrm_minutes"] = None
                result["osrm_as_crow"] = False

            # 7. Distance routière OSRM : lieu FR saisi → lieu CH
            p_fr_input = (result["fr_lat"], result["fr_lng"])
            osrm_direct = road_distance(p_fr_input, p_ch, timeout=10)
            if osrm_direct:
                result["direct_osrm_km"] = osrm_direct["km"]
                result["direct_osrm_minutes"] = osrm_direct.get("minutes")
                result["direct_osrm_as_crow"] = osrm_direct.get("as_crow", False)
            else:
                result["direct_osrm_km"] = None
                result["direct_osrm_minutes"] = None
                result["direct_osrm_as_crow"] = False

            # 8. Label formaté (comme dans border_distance.py)
            if result["osrm_minutes"] is not None:
                h, m = divmod(result["osrm_minutes"], 60)
                dur = f"{h}h{m:02d}" if h > 0 else f"{m} min"
                result["label"] = (
                    f"\U0001f1e8\U0001f1ed  {dur} depuis "
                    f"{crossing['french_town']} (frontière {crossing['name']})"
                )
            elif result["osrm_km"] is not None:
                suffix = " (vol d'oiseau)" if result["osrm_as_crow"] else ""
                result["label"] = (
                    f"\U0001f1e8\U0001f1ed  {result['osrm_km']} km{suffix} "
                    f"depuis {crossing['french_town']}"
                )
            else:
                result["label"] = "(calcul OSRM échoué)"

            self.finished.emit(result)

        except Exception as e:
            log.exception("[DebugDistance] Erreur worker")
            self.error.emit(str(e))


# ─── Widget principal ────────────────────────────────────────────────────────

class DebugDistanceTab(QWidget):
    """Onglet de debug pour vérifier les calculs de distance frontière."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._worker: DebugDistanceWorker | None = None
        self._build_ui()

    # ─── UI ──────────────────────────────────────────────────────────────────

    def _build_ui(self):
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # ── Panneau gauche : saisie + résultats ──
        left = QWidget()
        left.setFixedWidth(380)
        left_layout = QVBoxLayout(left)
        left_layout.setContentsMargins(12, 12, 12, 12)
        left_layout.setSpacing(8)

        title = QLabel("🗺️  Debug distances frontière")
        title.setStyleSheet("font-size:14px; font-weight:bold; color:#cba6f7;")
        left_layout.addWidget(title)

        desc = QLabel(
            "Saisissez un lieu en France et un en Suisse pour\n"
            "visualiser le calcul de distance complet."
        )
        desc.setStyleSheet("color:#6c7086; font-size:11px;")
        desc.setWordWrap(True)
        left_layout.addWidget(desc)

        left_layout.addSpacing(4)

        # Lieu France
        lbl_fr = QLabel("🇫🇷  Lieu en France")
        lbl_fr.setStyleSheet("font-weight:bold; color:#89b4fa;")
        left_layout.addWidget(lbl_fr)
        self._input_fr = QLineEdit()
        self._input_fr.setPlaceholderText("Annemasse, Saint-Julien-en-Genevois…")
        left_layout.addWidget(self._input_fr)

        left_layout.addSpacing(4)

        # Lieu Suisse
        lbl_ch = QLabel("🇨🇭  Lieu en Suisse")
        lbl_ch.setStyleSheet("font-weight:bold; color:#f38ba8;")
        left_layout.addWidget(lbl_ch)
        self._input_ch = QLineEdit()
        self._input_ch.setPlaceholderText("Genève, Lausanne, Bern…")
        left_layout.addWidget(self._input_ch)

        left_layout.addSpacing(8)

        # Bouton calculer
        self._btn_calc = QPushButton("🔍  Calculer")
        self._btn_calc.setProperty("class", "primary")
        self._btn_calc.setCursor(Qt.CursorShape.PointingHandCursor)
        self._btn_calc.clicked.connect(self._on_calculate)
        left_layout.addWidget(self._btn_calc)

        # Entrée avec Enter
        self._input_fr.returnPressed.connect(self._on_calculate)
        self._input_ch.returnPressed.connect(self._on_calculate)

        left_layout.addSpacing(8)

        # Résultats
        lbl_results = QLabel("📊  Résultats")
        lbl_results.setStyleSheet("font-weight:bold; color:#cdd6f4;")
        left_layout.addWidget(lbl_results)

        self._txt_results = QTextEdit()
        self._txt_results.setReadOnly(True)
        self._txt_results.setStyleSheet(
            "font-family: 'Cascadia Code', 'Consolas', monospace;"
            "font-size: 11px;"
            "background: #181825;"
            "border: 1px solid #313244;"
            "border-radius: 4px;"
            "padding: 8px;"
        )
        self._txt_results.setPlaceholderText("Les résultats du calcul apparaîtront ici…")
        left_layout.addWidget(self._txt_results, 1)

        layout.addWidget(left)

        # ── Séparateur ──
        sep = QFrame()
        sep.setFrameShape(QFrame.Shape.VLine)
        sep.setStyleSheet("color:#313244;")
        layout.addWidget(sep)

        # ── Panneau droit : carte ──
        self._map_view = QWebEngineView()
        self._map_view.setHtml(_LEAFLET_HTML)
        layout.addWidget(self._map_view, 1)

    # ─── Logique ─────────────────────────────────────────────────────────────

    def _on_calculate(self):
        lieu_fr = self._input_fr.text().strip()
        lieu_ch = self._input_ch.text().strip()

        if not lieu_fr:
            self._txt_results.setHtml(
                '<span style="color:#f38ba8;">⚠️ Veuillez saisir un lieu en France.</span>'
            )
            return
        if not lieu_ch:
            self._txt_results.setHtml(
                '<span style="color:#f38ba8;">⚠️ Veuillez saisir un lieu en Suisse.</span>'
            )
            return

        self._btn_calc.setEnabled(False)
        self._btn_calc.setText("⏳  Calcul en cours…")
        self._txt_results.setHtml(
            '<span style="color:#6c7086;">Géocodage et calcul en cours…</span>'
        )

        if self._worker and self._worker.isRunning():
            self._worker.wait(3000)

        self._worker = DebugDistanceWorker(lieu_fr, lieu_ch)
        self._worker.finished.connect(self._on_result)
        self._worker.error.connect(self._on_error)
        self._worker.start()

    def _on_result(self, r: dict):
        self._btn_calc.setEnabled(True)
        self._btn_calc.setText("🔍  Calculer")

        # ── Construire le texte résultat ──
        lines = []
        lines.append("═══════════════════════════════════════")
        lines.append("  GÉOCODAGE")
        lines.append("═══════════════════════════════════════")
        lines.append(f"  🇫🇷 «{r['fr_input']}»")
        lines.append(f"     → lat: {r['fr_lat']:.6f}  lng: {r['fr_lng']:.6f}")
        lines.append(f"     (source: geo.api.gouv.fr)")
        lines.append("")
        lines.append(f"  🇨🇭 «{r['ch_input']}»")
        lines.append(f"     → lat: {r['ch_lat']:.6f}  lng: {r['ch_lng']:.6f}")
        lines.append(f"     (source: Nominatim/OSM)")

        lines.append("")
        lines.append("═══════════════════════════════════════")
        lines.append("  DISTANCE DIRECTE (FR saisie → CH)")
        lines.append("═══════════════════════════════════════")
        lines.append(f"  Vol d'oiseau : {r['direct_haversine_km']} km")
        if r.get("direct_osrm_km") is not None:
            mins = r.get("direct_osrm_minutes")
            crow = " ⚠️ (fallback haversine)" if r.get("direct_osrm_as_crow") else ""
            lines.append(f"  Route OSRM  : {r['direct_osrm_km']} km")
            if mins is not None:
                h, m = divmod(mins, 60)
                dur = f"{h}h{m:02d}" if h > 0 else f"{m} min"
                lines.append(f"  Durée OSRM  : {dur}{crow}")
        else:
            lines.append("  Route OSRM  : ❌ échec")

        lines.append("")
        lines.append("═══════════════════════════════════════")
        lines.append("  POINT DE FRONTIÈRE RETENU")
        lines.append("═══════════════════════════════════════")
        lines.append(f"  Crossing : {r['crossing_name']}")
        lines.append(f"     lat: {r['crossing_lat']:.6f}  lng: {r['crossing_lng']:.6f}")
        lines.append(f"  Ville FR : {r['crossing_french_town']}")
        lines.append(f"     lat: {r['crossing_french_lat']:.6f}  lng: {r['crossing_french_lng']:.6f}")
        lines.append(f"  Distance CH → crossing : {r['crossing_crow_km']} km (haversine)")

        lines.append("")
        lines.append("═══════════════════════════════════════")
        lines.append("  CALCUL FRONTALIER (comme l'app)")
        lines.append("  Trajet : ville FR du crossing → CH")
        lines.append("═══════════════════════════════════════")
        if r.get("osrm_km") is not None:
            crow = " ⚠️ (fallback haversine)" if r.get("osrm_as_crow") else ""
            lines.append(f"  Route OSRM  : {r['osrm_km']} km")
            if r.get("osrm_minutes") is not None:
                h, m = divmod(r["osrm_minutes"], 60)
                dur = f"{h}h{m:02d}" if h > 0 else f"{m} min"
                lines.append(f"  Durée OSRM  : {dur}{crow}")
        else:
            lines.append("  Route OSRM  : ❌ échec")
        lines.append(f"  Label final : {r.get('label', '—')}")

        lines.append("")
        lines.append("═══════════════════════════════════════")
        lines.append("  TOP 5 CROSSINGS LES PLUS PROCHES")
        lines.append("═══════════════════════════════════════")
        for i, tc in enumerate(r.get("top_crossings", []), 1):
            sel = " ◄ RETENU" if tc["name"] == r["crossing_name"] else ""
            lines.append(
                f"  {i}. {tc['name']} ({tc['french_town']})"
                f"  —  {tc['crow_km']} km{sel}"
            )

        self._txt_results.setPlainText("\n".join(lines))

        # ── Mettre à jour la carte ──
        top_js = "[" + ",".join(
            f"{{name:'{tc['name']}',lat:{tc['lat']},lng:{tc['lng']},km:{tc['crow_km']}}}"
            for tc in r.get("top_crossings", [])[1:]  # exclure le 1er (déjà affiché en vert)
        ) + "]"

        js = (
            f"updateMap("
            f"{r['fr_lat']},{r['fr_lng']},"
            f"{r['ch_lat']},{r['ch_lng']},"
            f"{r['crossing_lat']},{r['crossing_lng']},"
            f"'{r['crossing_name']}',"
            f"{top_js}"
            f");"
        )
        self._map_view.page().runJavaScript(js)

    def _on_error(self, msg: str):
        self._btn_calc.setEnabled(True)
        self._btn_calc.setText("🔍  Calculer")
        self._txt_results.setHtml(
            f'<span style="color:#f38ba8;">❌ {msg}</span>'
        )

    def cleanup(self):
        """Arrête proprement le worker si actif."""
        if self._worker and self._worker.isRunning():
            self._worker.wait(2000)
