"""
Fenêtre principale de JobHunter.
"""
import re
from datetime import datetime, timedelta

from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtGui import QAction
from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QSplitter, QTabWidget, QLabel, QStatusBar,
    QMessageBox, QFrame, QTabBar
)

import utils.logger as log
import database.db_manager as db
from models.models import Application
from scrapers.aggregator import SearchWorker, DetailWorker, DistanceWorker
from scrapers.auto_scan import AutoScanWorker
from ui.search_panel import SearchPanel
from ui.results_panel import ResultsPanel
from ui.detail_panel import DetailPanel
from ui.tracking_panel import TrackingPanel
from ui.debug_panel import DebugPanel
from ui.debug_distance_tab import DebugDistanceTab
from ui.autoscan_tab import AutoScanTab
from ui.swiss_tab import SwissTab
from ui.dialogs import (
    SaveTemplateDialog, LoadTemplateDialog,
    SaveSwissTemplateDialog, LoadSwissTemplateDialog,
    SettingsDialog, EditApplicationDialog,
)
from ui.styles import DARK_STYLESHEET
from utils.excel_export import export_applications
from utils.notifier import notify_toast

# ─── Constantes ───────────────────────────────────────────────────────────────

_IGNORE_EMAILS = {"noreply", "no-reply", "ne-pas-repondre", "nepasrepondre",
                  "mailer-daemon", "postmaster"}


def _extract_contact(job) -> str:
    """Extrait un email ou téléphone depuis la description/company_info du job.

    Retourne la première correspondance trouvée (email prioritaire),
    ou chaîne vide si rien de pertinent.
    """
    texts = []
    if job.description:
        texts.append(job.description)
    if job.company_info and isinstance(job.company_info, dict):
        for v in job.company_info.values():
            if isinstance(v, str):
                texts.append(v)
    blob = "\n".join(texts)
    if not blob:
        return ""

    # Email
    emails = re.findall(r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}", blob)
    for em in emails:
        local = em.split("@")[0].lower()
        if local not in _IGNORE_EMAILS:
            return em

    # Téléphone FR
    phones = re.findall(
        r"(?:\+33[\s.]?\d|0\d)[\s.\-]?\d{2}[\s.\-]?\d{2}[\s.\-]?\d{2}[\s.\-]?\d{2}",
        blob,
    )
    if phones:
        return phones[0].strip()

    return ""


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        log.init_ui_logging()   # signal Qt dispo dès ici, après QApplication
        log.info("Démarrage de JobHunter…")
        self.setWindowTitle("JobHunter  —  Agrégateur d'offres d'emploi")
        self.setMinimumSize(1200, 750)
        self.showMaximized()

        self._worker:          SearchWorker   | None = None
        self._detail_worker:   DetailWorker   | None = None
        self._distance_worker: DistanceWorker | None = None
        self._auto_worker:     AutoScanWorker | None = None
        self._auto_scan_tabs:  list[AutoScanTab] = []
        self._auto_scan_timer: QTimer | None = None

        self.setStyleSheet(DARK_STYLESHEET)
        self._build_ui()
        self._build_menu()
        log.info("Interface chargée.")

        # Auto-scan différé (laisse le temps à l'UI de s'afficher)
        QTimer.singleShot(1500, self._maybe_auto_scan)

    # ─── Build UI ─────────────────────────────────────────────────────────────

    def _build_ui(self):
        self.tabs = QTabWidget()
        self.tabs.setTabPosition(QTabWidget.TabPosition.South)
        self.setCentralWidget(self.tabs)

        # ── Onglet Recherche ──
        search_tab = QWidget()
        s_layout = QHBoxLayout(search_tab)
        s_layout.setContentsMargins(0, 0, 0, 0)
        s_layout.setSpacing(0)

        self.search_panel = SearchPanel()
        self.search_panel.search_requested.connect(self._on_search)
        self.search_panel.template_save_requested.connect(self._on_save_template)
        self.search_panel.template_load_requested.connect(self._on_load_template)
        s_layout.addWidget(self.search_panel)

        sep = QFrame()
        sep.setFrameShape(QFrame.Shape.VLine)
        sep.setStyleSheet("color:#313244;")
        s_layout.addWidget(sep)

        splitter = QSplitter(Qt.Orientation.Horizontal)
        splitter.setChildrenCollapsible(False)

        # Panneau résultats — attribut : self.results_panel
        self.results_panel = ResultsPanel()
        self.results_panel.job_selected.connect(self._on_job_selected)
        self.results_panel.save_job_requested.connect(self._on_save_job)
        self.results_panel.application_changed.connect(self._on_application_changed)
        splitter.addWidget(self.results_panel)

        # Panneau détail
        self.detail_panel = DetailPanel()
        self.detail_panel.quick_tag_requested.connect(self._on_application_changed)
        self.detail_panel.save_job_requested.connect(self._on_save_job)
        self.detail_panel.distance_clicked.connect(self._on_distance_clicked)
        splitter.addWidget(self.detail_panel)

        splitter.setSizes([420, 700])
        s_layout.addWidget(splitter, 1)

        # ── Onglet Candidatures ──
        self.tracking_panel = TrackingPanel()

        # ── Onglet Logs ──
        self.debug_panel = DebugPanel()

        # ── Onglet Debug Distances ──
        self.debug_distance_tab = DebugDistanceTab()

        # ── Onglet Suisse ──
        self.swiss_tab = SwissTab()
        self.swiss_tab.save_job_requested.connect(self._on_save_job)
        self.swiss_tab.application_changed.connect(self._on_application_changed)
        self.swiss_tab.status_changed.connect(self._set_status)
        self.swiss_tab.template_save_requested.connect(self._on_save_swiss_template)
        self.swiss_tab.template_load_requested.connect(self._on_load_swiss_template)
        self.swiss_tab.distance_clicked.connect(self._on_distance_clicked)

        self.tabs.addTab(search_tab,              "🔍  Recherche")
        self.tabs.addTab(self.swiss_tab,           "\U0001f1e8\U0001f1ed  Suisse")
        self.tabs.addTab(self.tracking_panel,      "📬  Candidatures")
        self.tabs.addTab(self.debug_panel,         "📋  Logs")
        self.tabs.addTab(self.debug_distance_tab,  "🗺️  Carte distances")

        # Onglets fermables (seuls les auto-scan le sont)
        self.tabs.setTabsClosable(True)
        self.tabs.tabCloseRequested.connect(self._on_tab_close_requested)
        # Masquer le bouton close sur les 4 onglets fixes
        self._N_FIXED_TABS = 5
        for i in range(self._N_FIXED_TABS):
            self.tabs.tabBar().setTabButton(
                i, QTabBar.ButtonPosition.RightSide, None
            )
            self.tabs.tabBar().setTabButton(
                i, QTabBar.ButtonPosition.LeftSide, None
            )

        # Status bar
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        self._lbl_status  = QLabel("Prêt")
        self._lbl_sources = QLabel("")
        self._lbl_sources.setStyleSheet("color:#6c7086; margin-right:8px;")
        self.status_bar.addWidget(self._lbl_status)
        self.status_bar.addPermanentWidget(self._lbl_sources)

    def _build_menu(self):
        mb = self.menuBar()

        # Fichier
        menu_file = mb.addMenu("Fichier")
        act_export_xl = QAction("📊  Exporter candidatures (Excel)…", self)
        act_export_xl.triggered.connect(self._on_export_excel_manual)
        menu_file.addAction(act_export_xl)
        menu_file.addSeparator()
        act_settings = QAction("⚙️  Paramètres…", self)
        act_settings.setShortcut("Ctrl+,")
        act_settings.triggered.connect(self._on_settings)
        menu_file.addAction(act_settings)
        menu_file.addSeparator()
        act_quit = QAction("Quitter", self)
        act_quit.setShortcut("Ctrl+Q")
        act_quit.triggered.connect(self.close)
        menu_file.addAction(act_quit)

        # Templates
        menu_tpl = mb.addMenu("Templates")
        act_save_tpl = QAction("💾  Sauvegarder la recherche actuelle", self)
        act_save_tpl.triggered.connect(
            lambda: self._on_save_template(self.search_panel.get_params())
        )
        menu_tpl.addAction(act_save_tpl)
        act_load_tpl = QAction("📂  Charger un template", self)
        act_load_tpl.triggered.connect(self._on_load_template)
        menu_tpl.addAction(act_load_tpl)

        # Aide
        menu_help = mb.addMenu("Aide")
        act_logs = QAction("📋  Ouvrir l'onglet Logs", self)
        act_logs.triggered.connect(lambda: self.tabs.setCurrentWidget(self.debug_panel))
        menu_help.addAction(act_logs)
        menu_help.addSeparator()
        act_about = QAction("À propos de JobHunter", self)
        act_about.triggered.connect(self._on_about)
        menu_help.addAction(act_about)

    # ─── Recherche ────────────────────────────────────────────────────────────

    def _on_search(self, params: dict) -> None:
        if not params.get("keywords") and not params.get("location"):
            QMessageBox.warning(self, "Critères manquants",
                "Veuillez entrer au moins un mot-clé ou une localisation.")
            return
        if not params.get("sources"):
            QMessageBox.warning(self, "Aucune source", "Sélectionnez au moins une source.")
            return

        if self._worker and self._worker.isRunning():
            self._worker.cancel()
            self._worker.wait(1000)

        self.results_panel.clear()
        self.search_panel.set_searching(True)
        self._set_status("Recherche en cours…")
        self._lbl_sources.setText("  ".join(f"⏳ {s}" for s in params["sources"]))

        log.info(
            f"Recherche : '{params['keywords']}' @ '{params.get('location','France entière')}'"
            f" rayon={params.get('radius')}km sources={params['sources']}"
        )

        self._worker = SearchWorker(
            keywords=params["keywords"],
            location=params["location"],
            radius=params["radius"],
            contract_type=params["contract_type"],
            sources=params["sources"],
            max_per_source=50,
        )
        self._worker.jobs_batch.connect(self._on_jobs_received)
        self._worker.source_done.connect(self._on_source_done)
        self._worker.source_error.connect(self._on_source_error)
        self._worker.all_done.connect(self._on_search_done)
        self._worker.start()

    def _on_jobs_received(self, jobs: list) -> None:
        self.results_panel.add_jobs(jobs)

    def _on_source_done(self, source: str, count: int) -> None:
        self._set_status(f"{source} : {count} offre(s)")

    def _on_source_error(self, source: str, error: str) -> None:
        log.warning(f"[{source}] Erreur scraping : {error}")
        self._set_status(f"⚠️  {source} : erreur")

    def _on_search_done(self, total: int) -> None:
        self.search_panel.set_searching(False)
        self._set_status(f"✅  Recherche terminée — {total} offre(s) au total")
        self._lbl_sources.setText("")
        self.tabs.setCurrentIndex(0)

    # ─── Sélection d'offre ────────────────────────────────────────────────────

    def _on_job_selected(self, job) -> None:
        log.debug(f"Offre sélectionnée : '{job.title}' — {job.company} ({job.source})")
        self.detail_panel.show_job(job)
        self.detail_panel.show_loading(True)

        if self._detail_worker and self._detail_worker.isRunning():
            self._detail_worker.wait(2000)
        self._detail_worker = DetailWorker(job)
        self._detail_worker.detail_ready.connect(self._on_detail_ready)
        self._detail_worker.start()

        if self._distance_worker and self._distance_worker.isRunning():
            self._distance_worker.wait(2000)
        self._distance_worker = DistanceWorker(job)
        self._distance_worker.distance_ready.connect(self._on_distance_ready)
        self._distance_worker.start()

    def _on_detail_ready(self, job) -> None:
        self.detail_panel.show_loading(False)
        self.detail_panel.update_description(job)

    def _on_distance_ready(self, job, result) -> None:
        self.detail_panel.update_distance(job, result)

    # ─── Candidatures ────────────────────────────────────────────────────────

    def _on_application_changed(self, job) -> None:
        """
        Point d'entrée unique pour créer/éditer une candidature.
        Appelé depuis :
          - Bouton '🏷️ Marquer postulé' du panneau détail
          - Menu contextuel '🏷️ Marquer comme postulé' de la liste
          - Menu contextuel '✏️ Éditer la candidature' de la liste

        Si pas encore postulé → crée la candidature puis ouvre le dialogue d'édition.
        Si déjà postulé       → ouvre directement le dialogue d'édition.
        """
        log.info(f"Tag / édition candidature : '{job.title}' — {job.company}")
        try:
            apps = db.get_applications()
            app  = next((a for a in apps if a.job_id == job.id), None)

            is_new = app is None
            if is_new:
                # Extraire email/téléphone de la description ou des infos
                contact = _extract_contact(job)

                app = Application(
                    job_id    = job.id,
                    job_title = job.title,
                    company   = job.company   or "",
                    source    = job.source    or "",
                    status    = "sent",
                    job_url   = job.url       or "",
                    location  = job.location  or "",
                    contact   = contact,
                )

            # Ouvrir le dialogue d'édition (pré-rempli)
            dlg = EditApplicationDialog(app, self)
            if dlg.exec() == EditApplicationDialog.DialogCode.Accepted:
                # Ne persister que si l'utilisateur a validé
                if is_new:
                    app.id = db.save_application(app)
                    log.info(f"Candidature créée (id={app.id}) pour '{job.title}'")
                self._refresh_after_application(job)
                self._set_status(f"✅  Candidature : {job.title}")

        except Exception:
            log.exception(f"Erreur dans _on_application_changed pour '{job.title}'")

    def _refresh_after_application(self, job) -> None:
        """Rafraîchit tous les widgets après création/modification d'une candidature."""
        try:
            self.results_panel.reload_applied()
        except Exception:
            log.exception("reload_applied échoué")
        try:
            self.detail_panel.refresh_tag_status(job)
        except Exception:
            log.exception("refresh_tag_status échoué")
        try:
            self.tracking_panel.refresh()
        except Exception:
            log.exception("tracking_panel.refresh échoué")
        # Rafraîchir l'onglet Suisse
        try:
            self.swiss_tab.reload_applied()
            self.swiss_tab.refresh_tag_status(job)
        except Exception:
            pass
        # Rafraîchir aussi les onglets auto-scan
        for tab in self._auto_scan_tabs:
            try:
                tab.reload_applied()
                tab.refresh_tag_status(job)
            except Exception:
                pass
        try:
            self._export_applications_excel()
        except Exception:
            log.exception("export excel échoué")

    def _export_applications_excel(self) -> None:
        """Export silencieux après chaque action sur les candidatures."""
        try:
            apps = db.get_applications()
            if apps:
                path = export_applications(apps)
                log.debug(f"Excel exporté : {path}")
        except Exception:
            log.exception("Export Excel échoué")

    def _on_export_excel_manual(self) -> None:
        """Export manuel avec confirmation et ouverture du fichier."""
        import os
        apps = db.get_applications()
        if not apps:
            QMessageBox.information(self, "Export Excel", "Aucune candidature à exporter.")
            return
        try:
            path = export_applications(apps)
            reply = QMessageBox.question(
                self, "Export réussi",
                f"{len(apps)} candidature(s) exportée(s) vers :\n{path}\n\nOuvrir le fichier ?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            )
            if reply == QMessageBox.StandardButton.Yes:
                os.startfile(str(path))
        except Exception:
            log.exception("Export Excel manuel échoué")

    # ─── Offre sauvegardée ───────────────────────────────────────────────────

    def _on_save_job(self, job) -> None:
        try:
            db.save_job(job)
            log.info(f"Offre sauvegardée : '{job.title}'")
            self._set_status(f"⭐  Offre sauvegardée : {job.title}")
        except Exception:
            log.exception("Sauvegarde offre échouée")

    # ─── Templates ───────────────────────────────────────────────────────────

    def _on_save_template(self, params: dict) -> None:
        dlg = SaveTemplateDialog(params, self)
        if dlg.exec():
            tpl = dlg.get_template()
            if tpl:
                db.save_template(tpl)
                log.info(f"Template sauvegardé : '{tpl.name}'")
                self._set_status(f"💾  Template «{tpl.name}» sauvegardé")

    def _on_load_template(self) -> None:
        dlg = LoadTemplateDialog(self)
        if dlg.exec():
            tpl = dlg.get_selected()
            if tpl:
                self.search_panel.load_template(tpl)
                log.info(f"Template chargé : '{tpl.name}'")
                self._set_status(f"📂  Template «{tpl.name}» chargé")

    # ─── Swiss Templates ──────────────────────────────────────────────────────

    def _on_save_swiss_template(self, params: dict) -> None:
        dlg = SaveSwissTemplateDialog(params, self)
        if dlg.exec():
            tpl = dlg.get_template()
            if tpl:
                db.save_swiss_template(tpl)
                log.info(f"Template Suisse sauvegardé : '{tpl.name}'")
                self._set_status(f"💾  Template Suisse «{tpl.name}» sauvegardé")

    def _on_load_swiss_template(self) -> None:
        dlg = LoadSwissTemplateDialog(self)
        if dlg.exec():
            tpl = dlg.get_selected()
            if tpl:
                self.swiss_tab.load_template(tpl.keywords, tpl.max_border_minutes)
                log.info(f"Template Suisse chargé : '{tpl.name}'")
                self._set_status(f"📂  Template Suisse «{tpl.name}» chargé")

    # ─── Carte distances ─────────────────────────────────────────────────────

    def _on_distance_clicked(self, french_town: str, job_location: str) -> None:
        """Ouvre l'onglet carte avec les lieux pré-remplis et lance le calcul."""
        self.debug_distance_tab._input_fr.setText(french_town)
        self.debug_distance_tab._input_ch.setText(job_location)
        self.tabs.setCurrentWidget(self.debug_distance_tab)
        self.debug_distance_tab._on_calculate()

    # ─── Paramètres ──────────────────────────────────────────────────────────

    def _on_settings(self) -> None:
        dlg = SettingsDialog(self)
        dlg.exec()

    # ─── À propos ────────────────────────────────────────────────────────────

    def _on_about(self) -> None:
        QMessageBox.about(
            self, "À propos de JobHunter",
            "<h2>JobHunter v1.0</h2>"
            "<p>Agrégateur d'offres d'emploi multi-sources pour Windows.</p>"
            "<p>Sources : France Travail · HelloWork · Welcome to the Jungle · APEC · Meteojob</p>"
            "<p><b>Raccourcis :</b><br>"
            "Ctrl+, → Paramètres&nbsp;&nbsp;&nbsp;Ctrl+Q → Quitter</p>",
        )

    # ─── Auto-scan ─────────────────────────────────────────────────────────────

    def _maybe_auto_scan(self) -> None:
        """Vérifie si un auto-scan doit être lancé selon l'horaire configuré."""
        enabled = db.get_setting("auto_scan_enabled", "false")
        if enabled != "true":
            log.debug("[AutoScan] Désactivé dans les paramètres.")
            return

        now = datetime.now()

        # Horaire configuré (défaut 08:00)
        scan_time_str = db.get_setting("auto_scan_time", "08:00")
        try:
            parts = scan_time_str.split(":")
            scan_hour, scan_min = int(parts[0]), int(parts[1])
        except (ValueError, IndexError):
            scan_hour, scan_min = 8, 0

        # Heure cible aujourd'hui
        target_today = now.replace(
            hour=scan_hour, minute=scan_min, second=0, microsecond=0
        )

        # Vérifier le dernier scan
        last_scan = db.get_setting("last_auto_scan", "")
        if last_scan:
            try:
                last_dt = datetime.fromisoformat(last_scan)
                # Si le dernier scan est après la cible d'aujourd'hui → déjà fait
                if last_dt >= target_today:
                    log.info(
                        f"[AutoScan] Déjà effectué aujourd'hui à "
                        f"{last_dt.strftime('%H:%M')} (cible {scan_time_str})"
                    )
                    self._schedule_next_auto_scan(scan_hour, scan_min)
                    return
            except (ValueError, TypeError):
                pass  # timestamp invalide → on relance

        # L'heure cible est passée ou pas de scan aujourd'hui → lancer
        if now >= target_today:
            templates = db.get_templates()
            if not templates:
                log.info("[AutoScan] Aucun template sauvegardé.")
                return
            log.info(f"[AutoScan] Lancement pour {len(templates)} template(s)")
            self._run_auto_scan(templates)
        else:
            # L'heure n'est pas encore arrivée → programmer le timer
            delay_ms = int((target_today - now).total_seconds() * 1000)
            log.info(
                f"[AutoScan] Programmé à {scan_time_str} "
                f"(dans {delay_ms // 60000} min)"
            )
            self._auto_scan_timer = QTimer(self)
            self._auto_scan_timer.setSingleShot(True)
            self._auto_scan_timer.timeout.connect(self._trigger_scheduled_scan)
            self._auto_scan_timer.start(delay_ms)

    def _trigger_scheduled_scan(self) -> None:
        """Déclenché par le timer à l'horaire configuré."""
        log.info("[AutoScan] Horaire atteint — lancement du scan.")
        templates = db.get_templates()
        if not templates:
            log.info("[AutoScan] Aucun template sauvegardé.")
            return
        self._run_auto_scan(templates)

    def _schedule_next_auto_scan(self, hour: int, minute: int) -> None:
        """Programme le prochain auto-scan pour demain à l'heure donnée."""
        now = datetime.now()
        tomorrow_target = (now + timedelta(days=1)).replace(
            hour=hour, minute=minute, second=0, microsecond=0
        )
        delay_ms = int((tomorrow_target - now).total_seconds() * 1000)
        log.info(
            f"[AutoScan] Prochain scan demain à {hour:02d}:{minute:02d} "
            f"(dans {delay_ms // 3600000}h{(delay_ms % 3600000) // 60000:02d}min)"
        )
        self._auto_scan_timer = QTimer(self)
        self._auto_scan_timer.setSingleShot(True)
        self._auto_scan_timer.timeout.connect(self._trigger_scheduled_scan)
        self._auto_scan_timer.start(delay_ms)

    def _run_auto_scan(self, templates) -> None:
        """Ferme les anciens onglets auto-scan et lance le worker."""
        self._close_auto_scan_tabs()

        self._auto_worker = AutoScanWorker(templates)
        self._auto_worker.template_started.connect(self._on_auto_template_started)
        self._auto_worker.template_jobs.connect(self._on_auto_template_jobs)
        self._auto_worker.template_done.connect(self._on_auto_template_done)
        self._auto_worker.all_done.connect(self._on_auto_scan_done)
        self._auto_worker.start()

        self._set_status("🔄  Auto-scan en cours…")

    def _on_auto_template_started(self, name: str) -> None:
        self._set_status(f"🔄  Auto-scan : «{name}»…")

    def _on_auto_template_jobs(self, name: str, jobs: list) -> None:
        """Crée un onglet auto-scan pour ce template."""
        tab = AutoScanTab(name)
        tab.save_job_requested.connect(self._on_save_job)
        tab.application_changed.connect(self._on_application_changed)
        tab.add_jobs(jobs)

        count = len(jobs)
        self.tabs.addTab(tab, f"🔍 {name} ({count})")
        self._auto_scan_tabs.append(tab)

        # Pas de bouton close sur les onglets fixes, mais les auto-scan l'ont déjà
        log.info(f"[AutoScan] Onglet «{name}» créé avec {count} offre(s)")

    def _on_auto_template_done(self, name: str, count: int) -> None:
        self._set_status(f"🔄  Auto-scan : «{name}» → {count} offre(s)")

    def _on_auto_scan_done(self, total: int) -> None:
        """Fin de l'auto-scan : sauvegarde timestamp, toast, programme le suivant."""
        db.set_setting("last_auto_scan", datetime.now().isoformat())
        self._auto_worker = None

        if total > 0:
            self._set_status(f"✅  Auto-scan terminé — {total} nouvelle(s) offre(s)")
            notify_toast(
                "JobHunter — Auto-scan",
                f"{total} nouvelle(s) offre(s) trouvée(s) dans "
                f"{len(self._auto_scan_tabs)} template(s).",
            )
            # Basculer vers le premier onglet auto-scan
            if self._auto_scan_tabs:
                self.tabs.setCurrentWidget(self._auto_scan_tabs[0])
        else:
            self._set_status("✅  Auto-scan terminé — aucune nouvelle offre")

        # Programmer le prochain scan pour demain
        scan_time_str = db.get_setting("auto_scan_time", "08:00")
        try:
            parts = scan_time_str.split(":")
            self._schedule_next_auto_scan(int(parts[0]), int(parts[1]))
        except (ValueError, IndexError):
            self._schedule_next_auto_scan(8, 0)

    def _on_tab_close_requested(self, index: int) -> None:
        """Ferme un onglet auto-scan (les onglets fixes sont protégés)."""
        if index < self._N_FIXED_TABS:
            return  # Ne jamais fermer Recherche / Candidatures / Logs

        widget = self.tabs.widget(index)
        self.tabs.removeTab(index)

        if isinstance(widget, AutoScanTab):
            widget.cleanup()
            if widget in self._auto_scan_tabs:
                self._auto_scan_tabs.remove(widget)
            widget.deleteLater()

    def _close_auto_scan_tabs(self) -> None:
        """Ferme tous les onglets auto-scan existants."""
        for tab in list(self._auto_scan_tabs):
            idx = self.tabs.indexOf(tab)
            if idx >= 0:
                self.tabs.removeTab(idx)
            tab.cleanup()
            tab.deleteLater()
        self._auto_scan_tabs.clear()

    # ─── Helpers ─────────────────────────────────────────────────────────────

    def _set_status(self, msg: str) -> None:
        self._lbl_status.setText(msg)

    def closeEvent(self, event):
        log.info("Fermeture de JobHunter.")
        if self._auto_scan_timer and self._auto_scan_timer.isActive():
            self._auto_scan_timer.stop()
        if self._worker and self._worker.isRunning():
            self._worker.cancel()
            self._worker.wait(2000)
        if self._auto_worker and self._auto_worker.isRunning():
            self._auto_worker.cancel()
            self._auto_worker.wait(2000)
        self.swiss_tab.cleanup()
        self.debug_distance_tab.cleanup()
        self._close_auto_scan_tabs()
        event.accept()
