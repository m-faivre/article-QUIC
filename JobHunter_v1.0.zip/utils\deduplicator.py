"""
Moteur de déduplication des offres d'emploi.
Critères : titre normalisé + entreprise normalisée + lieu + date de publication.

Système de score pondéré :
  - Titre (Jaccard ≥ seuil)  : obligatoire pour être candidat
  - Entreprise                : +2 pts si match, +1 si l'un est vide
  - Lieu                      : +2 pts si match, +1 si l'un est vide
  - Date de parution          : +2 pts si ≤3j, +1 si l'une est vide
  Score ≥ 4 → considéré comme doublon.

Optimisation : pré-indexation par entreprise normalisée pour éviter O(n²)
sur la totalité des offres. La comparaison Jaccard ne se fait qu'entre
offres de la même entreprise (ou entreprise vide).
"""
import re
import unicodedata
from collections import defaultdict
from datetime import date
from typing import List, Tuple

from models.models import Job

# Score minimum pour considérer deux offres comme doublons
# (sur 6 points max : entreprise 2 + lieu 2 + date 2)
_DUP_SCORE_THRESHOLD = 4


def _normalize(text: str) -> str:
    """Normalise un texte pour comparaison : minuscules, sans accents, sans ponctuation."""
    if not text:
        return ""
    # Supprimer les accents
    text = unicodedata.normalize("NFD", text)
    text = "".join(c for c in text if unicodedata.category(c) != "Mn")
    # Minuscules
    text = text.lower()
    # Supprimer suffixes courants (H/F, F/H, (h/f) etc.)
    text = re.sub(r"\(?\s*[hf]\s*/\s*[fh]\s*\)?", "", text)
    # Garder uniquement alphanum et espaces
    text = re.sub(r"[^a-z0-9\s]", " ", text)
    # Normaliser les espaces
    text = re.sub(r"\s+", " ", text).strip()
    return text


def _title_words(title: str) -> frozenset:
    """Retourne les mots normalisés d'un titre (résultat cachable)."""
    return frozenset(_normalize(title).split())


def _jaccard(words_a: frozenset, words_b: frozenset) -> float:
    """Similarité de Jaccard entre deux ensembles de mots."""
    if not words_a or not words_b:
        return 0.0
    intersection = len(words_a & words_b)
    union = len(words_a | words_b)
    return intersection / union if union > 0 else 0.0


def _company_key(company: str) -> str:
    """Clé de regroupement par entreprise."""
    return _normalize(company)


def _company_match(na: str, nb: str) -> bool:
    """Vérifie si deux noms d'entreprise normalisés correspondent."""
    if not na or not nb:
        return True  # Si l'un est vide, on ne peut pas exclure
    return na == nb or na in nb or nb in na


def _location_match(loc_a: str, loc_b: str) -> bool:
    """Vérifie si deux lieux normalisés correspondent (inclusion partielle)."""
    na = _normalize(loc_a)
    nb = _normalize(loc_b)
    if not na or not nb:
        return True  # Si l'un est vide, on ne peut pas exclure
    return na == nb or na in nb or nb in na


def _date_close(d1_str: str, d2_str: str, max_days: int = 3) -> bool:
    """Vérifie si deux dates sont à max_days jours d'écart ou moins."""
    if not d1_str or not d2_str:
        return True  # Si l'une est vide, on ne peut pas exclure
    try:
        d1 = date.fromisoformat(d1_str[:10])
        d2 = date.fromisoformat(d2_str[:10])
        return abs((d1 - d2).days) <= max_days
    except ValueError:
        return True  # Date mal formée, on ignore ce critère


def _dup_score(job: "Job", ref: "Job") -> int:
    """Calcule un score de similarité sur les critères secondaires.

    Retourne un score de 0 à 6 :
      - Entreprise : 2 (match) / 1 (un vide) / 0 (différent)
      - Lieu       : 2 (match) / 1 (un vide) / 0 (différent)
      - Date       : 2 (≤3j)  / 1 (un vide) / 0 (>3j)
    """
    score = 0

    # Entreprise
    na, nb = _normalize(job.company), _normalize(ref.company)
    if not na or not nb:
        score += 1
    elif _company_match(na, nb):
        score += 2

    # Lieu
    la, lb = _normalize(job.location), _normalize(ref.location)
    if not la or not lb:
        score += 1
    elif _location_match(job.location, ref.location):
        score += 2

    # Date de parution
    da, db = (job.posted_date or "").strip(), (ref.posted_date or "").strip()
    if not da or not db:
        score += 1
    elif _date_close(da, db):
        score += 2

    return score


def deduplicate(
    jobs: List[Job],
    title_threshold: float = 0.75,
) -> Tuple[List[Job], List[Job]]:
    """
    Sépare les offres en deux listes : uniques et doublons.

    Algorithme :
      1. Le titre doit dépasser le seuil Jaccard (condition nécessaire).
      2. Un score pondéré (entreprise + lieu + date) doit atteindre le seuil
         pour confirmer le doublon.

    Optimisation : indexation par entreprise pour réduire les comparaisons.
    Seules les offres d'une même entreprise (ou entreprise vide) sont comparées.

    Args:
        jobs: Liste complète des offres
        title_threshold: Seuil de similarité de titre (0.75 = 75% des mots en commun)

    Returns:
        (unique_jobs, duplicate_jobs)
    """
    if not jobs:
        return [], []

    unique: List[Job] = []
    duplicates: List[Job] = []

    # Index : company_key → liste de (job, title_words) parmi les uniques
    company_index: dict[str, list] = defaultdict(list)

    for job in jobs:
        job_ckey = _company_key(job.company)
        job_words = _title_words(job.title)
        is_dup = False

        # Candidats : même entreprise + entreprises vides (qui matchent tout)
        candidate_keys = {job_ckey}
        if job_ckey:
            candidate_keys.add("")  # Les offres sans entreprise matchent tout
        # Aussi chercher dans les clés qui contiennent/sont contenues dans job_ckey
        for existing_key in list(company_index.keys()):
            if _company_match(job_ckey, existing_key):
                candidate_keys.add(existing_key)

        for ckey in candidate_keys:
            for ref, ref_words in company_index.get(ckey, []):
                # 1. Similarité de titre (condition nécessaire)
                sim = _jaccard(job_words, ref_words)
                if sim < title_threshold:
                    continue

                # 2. Score pondéré (entreprise + lieu + date)
                score = _dup_score(job, ref)
                if score < _DUP_SCORE_THRESHOLD:
                    continue

                # C'est un doublon — enrichir la référence
                is_dup = True
                if not ref.description and job.description:
                    ref.description = job.description
                if not ref.salary and job.salary:
                    ref.salary = job.salary
                if not ref.company_info and job.company_info:
                    ref.company_info = job.company_info
                ref.tags.append(f"Aussi sur : {job.source}")
                break

            if is_dup:
                break

        if is_dup:
            duplicates.append(job)
        else:
            unique.append(job)
            company_index[job_ckey].append((job, job_words))

    return unique, duplicates
