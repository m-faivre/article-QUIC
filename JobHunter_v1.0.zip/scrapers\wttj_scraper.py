"""
Welcome to the Jungle — API Algolia.

Credentials fixes (window.env) :
  App ID  : CSEKHVMS53
  API Key : 4bd8f6215d0cc52b26430765769e65a0
  Index   : wttj_jobs_production_fr

Géolocalisation :
  - aroundLatLng  = "lat,lng"   → coordonnées GPS (géocodé via geo.api.gouv.fr)
  - aroundRadius  = N           → rayon en MÈTRES (standard Algolia)

Recherche :
  - Algolia fait du OR par défaut entre les mots de la query.
  - Pour forcer une recherche exacte : guillemets + advancedSyntax=true.

Distances acceptées par le frontend WTTJ : 5, 10, 20, 50, 100 km.
"""
import json
import time
from typing import Optional

import utils.logger as log
from models.models import Job
from scrapers.base_scraper import BaseScraper

ALGOLIA_APP_ID  = "CSEKHVMS53"
ALGOLIA_API_KEY = "4bd8f6215d0cc52b26430765769e65a0"
ALGOLIA_INDEX   = "wttj_jobs_production_fr"
ALGOLIA_URL     = (
    f"https://{ALGOLIA_APP_ID}-dsn.algolia.net"
    f"/1/indexes/{ALGOLIA_INDEX}/query"
)
WTTJ_BASE = "https://www.welcometothejungle.com"

# geo.api.gouv.fr → communes françaises sans clé API
GEOCODE_URL = "https://geo.api.gouv.fr/communes"

CONTRACT_FILTERS = {
    "CDI":        "FULL_TIME",
    "CDD":        "TEMPORARY",
    "Stage":      "INTERNSHIP",
    "Alternance": "APPRENTICESHIP",
    "Freelance":  "FREELANCE",
}

# Distances autorisées par le frontend WTTJ (km)
ALLOWED_DISTANCES = [5, 10, 20, 50, 100]

# Mapping salary_period → libellé lisible
SALARY_PERIODS = {
    "yearly":  "an",
    "monthly": "mois",
    "daily":   "jour",
    "hourly":  "h",
}

_geocode_cache: dict = {}


def _snap_distance(radius: int) -> int:
    """Arrondit le rayon à la valeur WTTJ autorisée la plus proche (par excès)."""
    for d in ALLOWED_DISTANCES:
        if radius <= d:
            return d
    return ALLOWED_DISTANCES[-1]


def _geocode_fr(session, city: str) -> Optional[str]:
    """
    Retourne "lat,lng" pour une ville française via geo.api.gouv.fr.
    Exemple : "Bourg-en-Bresse" → "46.2027,5.2469"
    """
    key = city.lower().strip()
    if key in _geocode_cache:
        return _geocode_cache[key]
    try:
        r = session.get(
            GEOCODE_URL,
            params={"nom": city, "fields": "centre", "limit": 1,
                    "boost": "population"},
            timeout=6,
        )
        if r.status_code == 200:
            data = r.json()
            if data:
                coords = data[0].get("centre", {}).get("coordinates", [])
                if len(coords) == 2:
                    # GeoJSON = [longitude, latitude]
                    lat_lng = f"{coords[1]},{coords[0]}"
                    log.debug(f"[WTTJ] Géocodage '{city}' → {lat_lng}")
                    _geocode_cache[key] = lat_lng
                    return lat_lng
    except Exception as e:
        log.debug(f"[WTTJ] Géocodage échoué pour '{city}' : {e}")
    return None


class WelcomeJungleScraper(BaseScraper):
    SOURCE_NAME = "Welcome to the Jungle"

    def search(self, keywords, location, radius=30, contract_type="Tous", max_results=50):
        distance_km = _snap_distance(radius)

        # ── Query ──────────────────────────────────────────────────────────
        # Algolia fait du OR par défaut entre les mots, mais le mode
        # advancedSyntax + guillemets est incompatible avec la géoloc
        # (renvoie 0 résultats). On envoie la query telle quelle,
        # comme le fait le frontend WTTJ.
        body: dict = {
            "query":        keywords,
            "hitsPerPage":  min(max_results, 100),
            "page":         0,
            "facetFilters": [["offices.country_code:FR"]],
        }

        # ── Géolocalisation ──────────────────────────────────────────────
        if location:
            lat_lng = _geocode_fr(self.session, location)
            if lat_lng:
                body["aroundLatLng"]  = lat_lng
                body["aroundRadius"]  = distance_km * 1000  # km → mètres
            else:
                log.warning(f"[WTTJ] Géocodage raté pour '{location}', recherche nationale")

        # ── Filtre contrat ────────────────────────────────────────────────
        ct = CONTRACT_FILTERS.get(contract_type)
        if ct:
            body["facetFilters"].append([f"contract_type:{ct}"])

        log.debug(f"[WTTJ] POST → {json.dumps(body, ensure_ascii=False)[:300]}")

        try:
            time.sleep(0.5)
            r = self.session.post(
                ALGOLIA_URL,
                json=body,
                headers={
                    "X-Algolia-Application-Id": ALGOLIA_APP_ID,
                    "X-Algolia-API-Key":        ALGOLIA_API_KEY,
                    "Content-Type":             "application/json",
                    "Origin":                   WTTJ_BASE,
                    "Referer":                  WTTJ_BASE + "/fr/jobs",
                },
                timeout=15,
            )
            log.info(f"[WTTJ] → {r.status_code}  {len(r.content)} octets")
            if r.status_code != 200:
                try:
                    err = r.json()
                    log.warning(f"[WTTJ] Erreur Algolia : {err.get('message','?')} ({err.get('status','?')})")
                except Exception:
                    log.warning(f"[WTTJ] HTTP {r.status_code} : {r.text[:200]}")
                return []
        except Exception as e:
            log.error(f"[WTTJ] Requête échouée : {e}")
            return []

        try:
            data = r.json()
        except Exception as e:
            log.error(f"[WTTJ] JSON invalide : {e}")
            return []

        hits = data.get("hits", [])
        log.info(f"[WTTJ] {data.get('nbHits','?')} offres totales, {len(hits)} hits reçus")

        jobs = [j for j in (self._parse(h) for h in hits) if j]
        log.info(f"[WTTJ] {len(jobs)} offres parsées")
        return jobs

    # ── Parsing hit Algolia ───────────────────────────────────────────────────

    def _parse(self, h: dict) -> Optional[Job]:
        try:
            name = h.get("name", "")
            if not name:
                return None

            org      = h.get("organization") or {}
            obj_id   = h.get("objectID", "")
            slug_job = h.get("slug", "")

            # URL de l'offre
            org_ref = org.get("reference", "") if isinstance(org, dict) else ""
            slug_org = org.get("slug", "") if isinstance(org, dict) else ""
            url = (f"{WTTJ_BASE}/fr/companies/{slug_org}/jobs/{slug_job}"
                   if slug_org and slug_job else "")

            # Localisation — offices est un tableau
            offices = h.get("offices") or []
            if isinstance(offices, list) and offices:
                office = offices[0]
            elif isinstance(offices, dict):
                office = offices
            else:
                office = {}
            city = office.get("city", "") if isinstance(office, dict) else ""

            # Contrat — contract_type est une string dans les hits
            contract = h.get("contract_type", "")

            # Salaire
            sal_min = h.get("salary_minimum")
            sal_max = h.get("salary_maximum")
            sal_cur = h.get("salary_currency", "EUR")
            sal_per = h.get("salary_period", "yearly")
            period_label = SALARY_PERIODS.get(sal_per, sal_per)
            currency = "€" if sal_cur == "EUR" else sal_cur
            salary  = ""
            if sal_min and sal_max:
                salary = (f"{int(sal_min):,} – {int(sal_max):,} {currency}/{period_label}"
                          .replace(",", "\u202f"))
            elif sal_min:
                salary = f"≥ {int(sal_min):,} {currency}/{period_label}".replace(",", "\u202f")

            # Date
            pub = h.get("published_at_date") or h.get("published_at", "")
            date_str = str(pub)[:10] if pub else ""

            # Description
            desc = h.get("summary", "")

            return Job(
                id=self._make_id("Welcome to the Jungle", obj_id or url or name),
                title=self._clean(name),
                company=self._clean_company(org.get("name", "") if isinstance(org, dict) else str(org)),
                location=self._clean(str(city)),
                contract_type=self._clean(str(contract)),
                salary=salary,
                posted_date=date_str,
                description=self._clean(str(desc))[:400] if desc else "",
                source="Welcome to the Jungle",
                url=url,
            )
        except Exception as e:
            log.warning(f"[WTTJ] Hit ignoré : {e}")
            return None

    # ── Détail complet ────────────────────────────────────────────────────────

    def get_details(self, job: Job) -> Job:
        """Récupère la description complète via la page de l'offre (JSON-LD ou HTML)."""
        if not job.url:
            return job

        soup = self._soup(job.url)
        if not soup:
            return job

        # JSON-LD JobPosting (priorité)
        import re as _re
        for script in soup.find_all("script", type="application/ld+json"):
            try:
                ld = json.loads(script.string or "")
                if isinstance(ld, list):
                    ld = next((x for x in ld if x.get("@type") == "JobPosting"), {})
                if ld.get("@type") == "JobPosting":
                    raw = ld.get("description", "")
                    if raw:
                        txt = _re.sub(r"<br\s*/?>", "\n", raw)
                        txt = _re.sub(r"<[^>]+>", "", txt).strip()
                        if len(txt) > 100:
                            job.description = txt
                            return job
            except Exception:
                pass

        # Fallback HTML
        for sel in ["[data-testid='job-description']", ".job-description",
                    "[class*='jobDescription']", "article"]:
            el = soup.select_one(sel)
            if el:
                txt = el.get_text(separator="\n", strip=True)
                if len(txt) > 100:
                    job.description = txt
                    return job

        return job
