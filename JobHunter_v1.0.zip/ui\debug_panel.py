"""
Panneau de debug — logs en temps réel dans l'onglet Logs.
Se connecte au signal du logger APRÈS init_ui_logging().
"""
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QTextEdit,
    QPushButton, QCheckBox, QLabel, QFileDialog,
)
from PyQt6.QtCore import Qt, pyqtSlot
from PyQt6.QtGui import QTextCursor, QColor, QFont

import utils.logger as log
from ui.styles import COLORS

LEVEL_COLORS = {
    "DEBUG":   "#6c7086",
    "INFO":    "#cdd6f4",
    "WARNING": "#f9e2af",
    "ERROR":   "#f38ba8",
}


class DebugPanel(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._paused = False
        self._counts = {"DEBUG": 0, "INFO": 0, "WARNING": 0, "ERROR": 0}
        self._build_ui()

        # Brancher le signal — get_signal() peut être None si init pas encore appelé
        sig = log.get_signal()
        if sig is not None:
            sig.message.connect(self._on_message)
        else:
            # Retry après construction (cas où init_ui_logging est appelé après)
            from PyQt6.QtCore import QTimer
            QTimer.singleShot(200, self._try_connect_signal)

    def _try_connect_signal(self):
        sig = log.get_signal()
        if sig is not None:
            try:
                sig.message.connect(self._on_message)
                log.info("Panneau de logs connecté.")
            except Exception:
                pass

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(6)

        # ── Barre d'outils ────────────────────────────────────────────────────
        bar = QHBoxLayout()

        lbl = QLabel("📋  Logs en temps réel")
        lbl.setStyleSheet("color:#cdd6f4; font-weight:bold; font-size:13px;")
        bar.addWidget(lbl)
        bar.addStretch()

        self.chk_debug = QCheckBox("DEBUG")
        self.chk_debug.setChecked(True)
        self.chk_debug.setStyleSheet(f"color:{LEVEL_COLORS['DEBUG']};")
        bar.addWidget(self.chk_debug)

        self.chk_info = QCheckBox("INFO")
        self.chk_info.setChecked(True)
        self.chk_info.setStyleSheet(f"color:{LEVEL_COLORS['INFO']};")
        bar.addWidget(self.chk_info)

        self.chk_warn = QCheckBox("WARN")
        self.chk_warn.setChecked(True)
        self.chk_warn.setStyleSheet(f"color:{LEVEL_COLORS['WARNING']};")
        bar.addWidget(self.chk_warn)

        self.chk_err = QCheckBox("ERROR")
        self.chk_err.setChecked(True)
        self.chk_err.setStyleSheet(f"color:{LEVEL_COLORS['ERROR']};")
        bar.addWidget(self.chk_err)

        btn_pause = QPushButton("⏸ Pause")
        btn_pause.setCheckable(True)
        btn_pause.setFixedWidth(80)
        btn_pause.toggled.connect(lambda c: setattr(self, '_paused', c))
        btn_pause.setStyleSheet(
            "QPushButton{background:#313244;color:#cdd6f4;border:1px solid #45475a;"
            "border-radius:5px;padding:3px 8px;}"
            "QPushButton:checked{background:#f9e2af33;color:#f9e2af;}"
        )
        bar.addWidget(btn_pause)

        btn_clear = QPushButton("🗑 Effacer")
        btn_clear.setFixedWidth(80)
        btn_clear.clicked.connect(self._on_clear)
        btn_clear.setStyleSheet(
            "QPushButton{background:#313244;color:#cdd6f4;border:1px solid #45475a;"
            "border-radius:5px;padding:3px 8px;}"
        )
        bar.addWidget(btn_clear)

        btn_save = QPushButton("💾 Sauver")
        btn_save.setFixedWidth(80)
        btn_save.clicked.connect(self._on_save)
        btn_save.setStyleSheet(
            "QPushButton{background:#313244;color:#cdd6f4;border:1px solid #45475a;"
            "border-radius:5px;padding:3px 8px;}"
        )
        bar.addWidget(btn_save)

        layout.addLayout(bar)

        # ── Zone de texte ─────────────────────────────────────────────────────
        self.text = QTextEdit()
        self.text.setReadOnly(True)
        self.text.setFont(QFont("Consolas", 9))
        self.text.setStyleSheet(
            "QTextEdit {"
            f"  background:{COLORS['mantle']}; color:{COLORS['text']};"
            f"  border:1px solid {COLORS['surface']}; border-radius:6px; padding:6px;"
            "}"
        )
        layout.addWidget(self.text)

        # ── Compteurs ─────────────────────────────────────────────────────────
        foot = QHBoxLayout()
        self._count_bar = QLabel("DEBUG: 0   INFO: 0   WARN: 0   ERROR: 0")
        self._count_bar.setStyleSheet("color:#6c7086; font-size:10px;")
        foot.addWidget(self._count_bar)
        foot.addStretch()
        lbl_file = QLabel(f"📄 Fichier : {log.LOG_FILE}")
        lbl_file.setStyleSheet("color:#45475a; font-size:10px;")
        foot.addWidget(lbl_file)
        layout.addLayout(foot)

    # ── Slots ─────────────────────────────────────────────────────────────────

    @pyqtSlot(str, str)
    def _on_message(self, level: str, text: str):
        if self._paused:
            return
        shown = {
            "DEBUG":   self.chk_debug.isChecked(),
            "INFO":    self.chk_info.isChecked(),
            "WARNING": self.chk_warn.isChecked(),
            "ERROR":   self.chk_err.isChecked(),
        }
        if not shown.get(level, True):
            return

        self._counts[level] = self._counts.get(level, 0) + 1
        self._update_counts()

        color = LEVEL_COLORS.get(level, "#cdd6f4")
        cursor = self.text.textCursor()
        cursor.movePosition(QTextCursor.MoveOperation.End)
        fmt = cursor.charFormat()
        fmt.setForeground(QColor(color))
        cursor.setCharFormat(fmt)
        cursor.insertText(text + "\n")
        self.text.verticalScrollBar().setValue(
            self.text.verticalScrollBar().maximum()
        )

    def _on_clear(self):
        self.text.clear()
        self._counts = {"DEBUG": 0, "INFO": 0, "WARNING": 0, "ERROR": 0}
        self._update_counts()

    def _on_save(self):
        path, _ = QFileDialog.getSaveFileName(
            self, "Sauvegarder les logs", "jobhunter_debug.txt",
            "Fichiers texte (*.txt)"
        )
        if path:
            with open(path, "w", encoding="utf-8") as f:
                f.write(self.text.toPlainText())

    def _update_counts(self):
        d = self._counts
        self._count_bar.setText(
            f"DEBUG: {d.get('DEBUG',0)}   INFO: {d.get('INFO',0)}   "
            f"WARN: {d.get('WARNING',0)}   ERROR: {d.get('ERROR',0)}"
        )
