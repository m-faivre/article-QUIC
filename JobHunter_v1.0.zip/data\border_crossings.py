"""
Points de passage frontaliers franco-suisses.

Chaque entrée représente un passage routier réel avec la commune française
de plus de 1 000 habitants la plus proche.
Coordonnées GPS vérifiées sur OpenStreetMap.

Couverture : de Genève (sud) à Bâle (nord), toute la frontière.
"""

BORDER_CROSSINGS = [
    # ═══════════════════════════════════════════════════════════════════════
    # HAUTE-SAVOIE (74) — Bassin genevois & Annemasse
    # ═══════════════════════════════════════════════════════════════════════
    {
        "name": "Bardonnex",
        "lat": 46.1658, "lng": 6.1092,
        "french_town": "Saint-Julien-en-Genevois",
        "french_lat": 46.1432, "french_lng": 6.0840,
    },
    {
        "name": "Ambilly",
        "lat": 46.1975, "lng": 6.2250,
        "french_town": "Annemasse",
        "french_lat": 46.1934, "french_lng": 6.2340,
    },
    {
        "name": "Moillesulaz",
        "lat": 46.2025, "lng": 6.2445,
        "french_town": "Ambilly",
        "french_lat": 46.1987, "french_lng": 6.2291,
    },
    {
        "name": "Thônex-Vallard",
        "lat": 46.2075, "lng": 6.2551,
        "french_town": "Gaillard",
        "french_lat": 46.1865, "french_lng": 6.2173,
    },
    {
        "name": "Pierre-à-Bochet",
        "lat": 46.2100, "lng": 6.2700,
        "french_town": "Ville-la-Grand",
        "french_lat": 46.2038, "french_lng": 6.2543,
    },
    {
        "name": "Perly",
        "lat": 46.1610, "lng": 6.1010,
        "french_town": "Viry",
        "french_lat": 46.1332, "french_lng": 6.0501,
    },
    {
        "name": "Archamps (A40)",
        "lat": 46.1550, "lng": 6.1250,
        "french_town": "Archamps",
        "french_lat": 46.1487, "french_lng": 6.1252,
    },
    {
        "name": "Collonges-Valleiry",
        "lat": 46.1360, "lng": 5.9830,
        "french_town": "Valleiry",
        "french_lat": 46.1186, "french_lng": 5.9756,
    },
    {
        "name": "Anières-Hermance",
        "lat": 46.2800, "lng": 6.2320,
        "french_town": "Douvaine",
        "french_lat": 46.3050, "french_lng": 6.3050,
    },
    # ═══════════════════════════════════════════════════════════════════════
    # AIN (01) — Pays de Gex
    # ═══════════════════════════════════════════════════════════════════════
    {
        "name": "Ferney-Voltaire",
        "lat": 46.2570, "lng": 6.1080,
        "french_town": "Ferney-Voltaire",
        "french_lat": 46.2558, "french_lng": 6.1083,
    },
    {
        "name": "Meyrin-St-Genis",
        "lat": 46.2340, "lng": 6.0720,
        "french_town": "Saint-Genis-Pouilly",
        "french_lat": 46.2439, "french_lng": 6.0249,
    },
    {
        "name": "Collex-Bossy",
        "lat": 46.2750, "lng": 6.1230,
        "french_town": "Ornex",
        "french_lat": 46.2728, "french_lng": 6.0975,
    },
    {
        "name": "Divonne-les-Bains",
        "lat": 46.3580, "lng": 6.1350,
        "french_town": "Divonne-les-Bains",
        "french_lat": 46.3569, "french_lng": 6.1379,
    },
    {
        "name": "Col de la Faucille",
        "lat": 46.3670, "lng": 5.9920,
        "french_town": "Gex",
        "french_lat": 46.3333, "french_lng": 6.0578,
    },
    {
        "name": "Crassier",
        "lat": 46.3780, "lng": 6.1650,
        "french_town": "Divonne-les-Bains",
        "french_lat": 46.3569, "french_lng": 6.1379,
    },
    # ═══════════════════════════════════════════════════════════════════════
    # HAUTE-SAVOIE (74) — Chablais / Léman sud
    # ═══════════════════════════════════════════════════════════════════════
    {
        "name": "Machilly-Genève Eaux-Vives",
        "lat": 46.2700, "lng": 6.2900,
        "french_town": "Sciez",
        "french_lat": 46.3337, "french_lng": 6.3830,
    },
    {
        "name": "Veigy-Foncenex",
        "lat": 46.2700, "lng": 6.2600,
        "french_town": "Bons-en-Chablais",
        "french_lat": 46.2600, "french_lng": 6.3580,
    },
    {
        "name": "Thonon (bac Léman)",
        "lat": 46.3710, "lng": 6.4790,
        "french_town": "Thonon-les-Bains",
        "french_lat": 46.3706, "french_lng": 6.4790,
    },
    {
        "name": "Évian (bac Léman)",
        "lat": 46.4010, "lng": 6.5900,
        "french_town": "Évian-les-Bains",
        "french_lat": 46.4013, "french_lng": 6.5882,
    },
    {
        "name": "Saint-Gingolph",
        "lat": 46.3945, "lng": 6.8050,
        "french_town": "Saint-Gingolph",
        "french_lat": 46.3932, "french_lng": 6.8015,
    },
    # ═══════════════════════════════════════════════════════════════════════
    # HAUTE-SAVOIE (74) — Vallée de Chamonix
    # ═══════════════════════════════════════════════════════════════════════
    {
        "name": "Châtelard (Finhaut)",
        "lat": 46.0830, "lng": 6.9650,
        "french_town": "Chamonix-Mont-Blanc",
        "french_lat": 45.9237, "french_lng": 6.8694,
    },
    {
        "name": "Vallorcine",
        "lat": 46.0460, "lng": 6.9310,
        "french_town": "Chamonix-Mont-Blanc",
        "french_lat": 45.9237, "french_lng": 6.8694,
    },
    # ═══════════════════════════════════════════════════════════════════════
    # JURA (39) — Les Rousses / Morez
    # ═══════════════════════════════════════════════════════════════════════
    {
        "name": "Les Rousses (La Cure)",
        "lat": 46.4600, "lng": 6.0730,
        "french_town": "Les Rousses",
        "french_lat": 46.4840, "french_lng": 6.0600,
    },
    {
        "name": "Bois-d'Amont",
        "lat": 46.5330, "lng": 6.1250,
        "french_town": "Morez",
        "french_lat": 46.5230, "french_lng": 6.0252,
    },
    # ═══════════════════════════════════════════════════════════════════════
    # DOUBS (25) — Pontarlier / Morteau / Villers-le-Lac
    # ═══════════════════════════════════════════════════════════════════════
    {
        "name": "Vallorbe",
        "lat": 46.7130, "lng": 6.3790,
        "french_town": "Jougne",
        "french_lat": 46.7630, "french_lng": 6.3884,
    },
    {
        "name": "Jougne",
        "lat": 46.7630, "lng": 6.3870,
        "french_town": "Jougne",
        "french_lat": 46.7630, "french_lng": 6.3884,
    },
    {
        "name": "Les Verrières",
        "lat": 46.9080, "lng": 6.4830,
        "french_town": "Pontarlier",
        "french_lat": 46.9073, "french_lng": 6.3548,
    },
    {
        "name": "Col des Roches (Le Locle)",
        "lat": 47.0560, "lng": 6.7200,
        "french_town": "Villers-le-Lac",
        "french_lat": 47.0595, "french_lng": 6.6718,
    },
    {
        "name": "Biaufond",
        "lat": 47.1080, "lng": 6.7660,
        "french_town": "Morteau",
        "french_lat": 47.0592, "french_lng": 6.6102,
    },
    {
        "name": "Le Locle-Morteau",
        "lat": 47.0550, "lng": 6.7430,
        "french_town": "Le Russey",
        "french_lat": 47.1570, "french_lng": 6.7430,
    },
    # ═══════════════════════════════════════════════════════════════════════
    # DOUBS (25) — Maîche / Saint-Hippolyte
    # ═══════════════════════════════════════════════════════════════════════
    {
        "name": "Goumois",
        "lat": 47.2600, "lng": 6.9520,
        "french_town": "Maîche",
        "french_lat": 47.2526, "french_lng": 6.8020,
    },
    {
        "name": "Saint-Ursanne (Clos du Doubs)",
        "lat": 47.3650, "lng": 7.1540,
        "french_town": "Saint-Hippolyte",
        "french_lat": 47.3200, "french_lng": 6.8100,
    },
    # ═══════════════════════════════════════════════════════════════════════
    # DOUBS (25) / TERRITOIRE DE BELFORT (90) — Porrentruy / Delle
    # ═══════════════════════════════════════════════════════════════════════
    {
        "name": "Damvant",
        "lat": 47.3670, "lng": 6.9010,
        "french_town": "Pont-de-Roide-Vermondans",
        "french_lat": 47.3829, "french_lng": 6.7660,
    },
    {
        "name": "Fahy",
        "lat": 47.4220, "lng": 6.9430,
        "french_town": "Hérimoncourt",
        "french_lat": 47.4403, "french_lng": 6.8842,
    },
    {
        "name": "Boncourt",
        "lat": 47.4890, "lng": 6.9530,
        "french_town": "Delle",
        "french_lat": 47.5095, "french_lng": 6.9976,
    },
    {
        "name": "Beurnevésin",
        "lat": 47.4930, "lng": 7.0270,
        "french_town": "Delle",
        "french_lat": 47.5095, "french_lng": 6.9976,
    },
    {
        "name": "Réchésy",
        "lat": 47.4950, "lng": 7.0780,
        "french_town": "Beaucourt",
        "french_lat": 47.4869, "french_lng": 6.9265,
    },
    {
        "name": "Pfetterhouse",
        "lat": 47.5060, "lng": 7.1750,
        "french_town": "Dannemarie",
        "french_lat": 47.6309, "french_lng": 7.1196,
    },
    # ═══════════════════════════════════════════════════════════════════════
    # HAUT-RHIN (68) — Sundgau / Bâle
    # ═══════════════════════════════════════════════════════════════════════
    {
        "name": "Rodersdorf",
        "lat": 47.4850, "lng": 7.4550,
        "french_town": "Ferrette",
        "french_lat": 47.4937, "french_lng": 7.3121,
    },
    {
        "name": "Leymen",
        "lat": 47.4920, "lng": 7.4820,
        "french_town": "Leymen",
        "french_lat": 47.4921, "french_lng": 7.4731,
    },
    {
        "name": "Bâle-Hésingue (A35/A3)",
        "lat": 47.5720, "lng": 7.5360,
        "french_town": "Hésingue",
        "french_lat": 47.5694, "french_lng": 7.5218,
    },
    {
        "name": "Bâle-Bartenheim",
        "lat": 47.5500, "lng": 7.5100,
        "french_town": "Bartenheim",
        "french_lat": 47.6340, "french_lng": 7.4700,
    },
    {
        "name": "Bâle-Saint-Louis (A35/E25)",
        "lat": 47.5580, "lng": 7.5870,
        "french_town": "Saint-Louis",
        "french_lat": 47.5853, "french_lng": 7.5651,
    },
    {
        "name": "Huningue",
        "lat": 47.5890, "lng": 7.5900,
        "french_town": "Huningue",
        "french_lat": 47.5946, "french_lng": 7.5823,
    },
    {
        "name": "Village-Neuf",
        "lat": 47.6030, "lng": 7.5680,
        "french_town": "Village-Neuf",
        "french_lat": 47.6094, "french_lng": 7.5632,
    },
    {
        "name": "Kembs",
        "lat": 47.6310, "lng": 7.5050,
        "french_town": "Kembs",
        "french_lat": 47.6346, "french_lng": 7.4998,
    },
    {
        "name": "Sierentz",
        "lat": 47.6530, "lng": 7.4540,
        "french_town": "Sierentz",
        "french_lat": 47.6568, "french_lng": 7.4513,
    },
]
