"""
Export des candidatures vers un fichier Excel (.xlsx).

Colonnes :
  Entreprise | Poste | Lieu | Plateforme | Date d'envoi | Contact | Statut | Notes | Lien

  sous ~/.jobhunter/candidatures.xlsx
et écrasé/mis à jour à chaque export.
"""
from __future__ import annotations

import os
from datetime import datetime
from pathlib import Path
from typing import List

try:
    import openpyxl
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.utils import get_column_letter
    _OPENPYXL_OK = True
except ImportError:
    _OPENPYXL_OK = False

from config import BASE_DIR
import utils.logger as log

EXCEL_PATH = BASE_DIR / "candidatures.xlsx"

# ── Couleurs palette sombre cohérente avec l'UI ──────────────────────────────
C_HEADER_BG  = "1E1E2E"   # fond header
C_HEADER_FG  = "CDD6F4"   # texte header
C_ROW_EVEN   = "252536"   # ligne paire
C_ROW_ODD    = "1E1E2E"   # ligne impaire
C_ACCENT     = "CBA6F7"   # violet
C_TEXT       = "CDD6F4"   # texte normal
C_SUBTEXT    = "89B4FA"   # bleu clair (entreprise)
C_BORDER     = "313244"   # bordure

# Statuts → couleur de fond de la cellule
STATUS_COLORS = {
    "pending":   "F59E0B",
    "sent":      "3B82F6",
    "interview": "8B5CF6",
    "rejected":  "EF4444",
    "accepted":  "10B981",
}
STATUS_LABELS = {
    "pending":   "En attente",
    "sent":      "Envoyée",
    "interview": "Entretien",
    "rejected":  "Refusée",
    "accepted":  "Acceptée",
}

COLUMNS = [
    ("Entreprise",    22),
    ("Poste",         30),
    ("Lieu",          18),
    ("Plateforme",    18),
    ("Date d'envoi",  16),
    ("Contact",       22),
    ("Statut",        14),
    ("Notes",         35),
    ("Lien",          40),
]


def _thin_border(color: str = C_BORDER) -> Border:
    s = Side(border_style="thin", color=color)
    return Border(left=s, right=s, top=s, bottom=s)


def _cell_font(bold=False, color=C_TEXT, size=10) -> Font:
    return Font(name="Calibri", bold=bold, color=color, size=size)


def export_applications(applications: list) -> Path:
    """
    Crée ou écrase le fichier Excel avec la liste des candidatures.
    Retourne le chemin du fichier généré.
    """
    if not _OPENPYXL_OK:
        raise ImportError(
            "Le module 'openpyxl' est requis pour l'export Excel.\n"
            "Installez-le avec : pip install openpyxl"
        )
    BASE_DIR.mkdir(parents=True, exist_ok=True)
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Candidatures"

    # ── En-tête ──────────────────────────────────────────────────────────────
    header_fill   = PatternFill("solid", fgColor=C_HEADER_BG)
    header_font   = _cell_font(bold=True, color=C_HEADER_FG, size=11)
    header_align  = Alignment(horizontal="center", vertical="center", wrap_text=False)
    header_border = _thin_border("45475A")

    for col_idx, (name, width) in enumerate(COLUMNS, start=1):
        cell = ws.cell(row=1, column=col_idx, value=name)
        cell.font    = header_font
        cell.fill    = header_fill
        cell.alignment = header_align
        cell.border  = header_border
        ws.column_dimensions[get_column_letter(col_idx)].width = width

    ws.row_dimensions[1].height = 24
    ws.freeze_panes = "A2"

    # ── Données ───────────────────────────────────────────────────────────────
    for row_idx, app in enumerate(applications, start=2):
        is_even = (row_idx % 2 == 0)
        bg_color = C_ROW_EVEN if is_even else C_ROW_ODD
        row_fill = PatternFill("solid", fgColor=bg_color)
        border   = _thin_border()

        # Formatage de la date
        raw_date = getattr(app, "sent_at", "") or ""
        try:
            dt = datetime.fromisoformat(raw_date.replace(" ", "T")[:19])
            date_str = dt.strftime("%d/%m/%Y %H:%M")
        except Exception:
            date_str = raw_date[:16] if raw_date else ""

        status_label = STATUS_LABELS.get(app.status, app.status)

        row_data = [
            getattr(app, "company",     ""),
            getattr(app, "job_title",   ""),
            getattr(app, "location",    ""),
            getattr(app, "source",      ""),
            date_str,
            getattr(app, "contact",     ""),
            status_label,
            getattr(app, "notes",       ""),
            getattr(app, "job_url",     ""),
        ]

        for col_idx, value in enumerate(row_data, start=1):
            cell = ws.cell(row=row_idx, column=col_idx, value=value or "")
            cell.fill   = row_fill
            cell.border = border
            cell.font   = _cell_font(color=C_TEXT)
            cell.alignment = Alignment(vertical="center", wrap_text=(col_idx == 8))

            # Couleur spéciale colonne Entreprise
            if col_idx == 1:
                cell.font = _cell_font(bold=True, color=C_SUBTEXT)

            # Colonne Statut → fond coloré
            if col_idx == 7:
                status_bg = STATUS_COLORS.get(app.status, "6C7086")
                cell.fill = PatternFill("solid", fgColor=status_bg)
                cell.font = _cell_font(bold=True, color="1E1E2E", size=9)
                cell.alignment = Alignment(horizontal="center", vertical="center")

            # Colonne Lien → hyperlien
            if col_idx == 9 and value:
                cell.hyperlink = value
                cell.font = _cell_font(color="89B4FA")
                cell.value = "🔗 Voir l'offre"

        ws.row_dimensions[row_idx].height = 20

    # ── Ligne de total ────────────────────────────────────────────────────────
    total_row = len(applications) + 2
    ws.cell(row=total_row, column=1, value=f"Total : {len(applications)} candidature(s)").font = \
        _cell_font(bold=True, color=C_ACCENT, size=10)

    # ── Métadonnées ───────────────────────────────────────────────────────────
    wb.properties.title   = "Suivi des candidatures — JobHunter"
    wb.properties.creator = "JobHunter"
    wb.properties.description = f"Exporté le {datetime.now().strftime('%d/%m/%Y à %H:%M')}"

    wb.save(str(EXCEL_PATH))
    log.info(f"[Excel] Exporté : {EXCEL_PATH} ({len(applications)} candidature(s))")
    return EXCEL_PATH
