"""
Panneau de recherche pour la Suisse (colonne gauche de l'onglet Suisse).
Champs : mots-clés, temps max depuis la frontière.
"""
from PyQt6.QtCore import pyqtSignal, Qt
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QSpinBox, QPushButton, QFrame, QScrollArea, QCheckBox,
)

from scrapers.aggregator import SWISS_SOURCE_NAMES
from data.swiss_search_cities import SWISS_BORDER_CITIES


class SwissSearchPanel(QWidget):
    search_requested        = pyqtSignal(dict)
    template_save_requested = pyqtSignal(dict)
    template_load_requested = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("panel_left")
        self.setFixedWidth(280)
        self._build_ui()

    def _build_ui(self):
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)

        container = QWidget()
        layout = QVBoxLayout(container)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(12)

        title = QLabel("\U0001f1e8\U0001f1ed  Suisse")
        title.setStyleSheet(
            "font-size:15px; font-weight:700; color:#f38ba8; padding:4px 0;"
        )
        layout.addWidget(title)

        # ── Mots-clés ──
        layout.addWidget(self._section_label("MOTS-CLÉS"))
        self.input_keywords = QLineEdit()
        self.input_keywords.setPlaceholderText("Développeur, Chef de projet…")
        self.input_keywords.returnPressed.connect(self._on_search)
        layout.addWidget(self.input_keywords)

        # ── Temps max depuis frontière ──
        layout.addWidget(self._section_label("DISTANCE FRONTIÈRE"))
        border_row = QHBoxLayout()
        border_label = QLabel("Temps max :")
        border_label.setStyleSheet("color:#a6adc8;")
        self.spin_border = QSpinBox()
        self.spin_border.setRange(5, 120)
        self.spin_border.setValue(40)
        self.spin_border.setSuffix(" min")
        self.spin_border.setSingleStep(5)
        self.spin_border.setFixedWidth(120)
        border_row.addWidget(border_label)
        border_row.addStretch()
        border_row.addWidget(self.spin_border)
        layout.addLayout(border_row)

        info = QLabel(
            "Temps de trajet en voiture depuis la ville\n"
            "française la plus proche de la frontière."
        )
        info.setWordWrap(True)
        info.setStyleSheet("color:#6c7086; font-size:10px; font-style:italic;")
        layout.addWidget(info)

        # ── Régions ──
        layout.addWidget(self._section_label("RÉGIONS"))

        # Tout cocher / décocher
        toggle_row = QHBoxLayout()
        toggle_row.setSpacing(6)
        btn_all = QPushButton("Tout cocher")
        btn_all.setObjectName("btn_secondary")
        btn_all.setFixedHeight(24)
        btn_all.setStyleSheet("font-size:10px;")
        btn_all.clicked.connect(lambda: self._set_all_regions(True))
        btn_none = QPushButton("Tout décocher")
        btn_none.setObjectName("btn_secondary")
        btn_none.setFixedHeight(24)
        btn_none.setStyleSheet("font-size:10px;")
        btn_none.clicked.connect(lambda: self._set_all_regions(False))
        toggle_row.addWidget(btn_all)
        toggle_row.addWidget(btn_none)
        toggle_row.addStretch()
        layout.addLayout(toggle_row)

        self._region_checks: list[tuple[str, QCheckBox]] = []
        for city_name, region_label in SWISS_BORDER_CITIES:
            cb = QCheckBox(region_label)
            cb.setChecked(True)
            cb.setStyleSheet("color:#cdd6f4; font-size:11px; padding:1px 0;")
            layout.addWidget(cb)
            self._region_checks.append((city_name, cb))

        # ── Bouton Rechercher ──
        self.btn_search = QPushButton("\U0001f1e8\U0001f1ed  Lancer la recherche")
        self.btn_search.setObjectName("btn_primary")
        self.btn_search.setMinimumHeight(38)
        self.btn_search.clicked.connect(self._on_search)
        layout.addWidget(self.btn_search)

        # ── Templates ──
        layout.addSpacing(4)
        tpl_row = QHBoxLayout()
        tpl_row.setSpacing(6)

        self.btn_save_tpl = QPushButton("💾  Sauvegarder")
        self.btn_save_tpl.setObjectName("btn_secondary")
        self.btn_save_tpl.setMinimumHeight(30)
        self.btn_save_tpl.clicked.connect(
            lambda: self.template_save_requested.emit(self.get_params())
        )
        tpl_row.addWidget(self.btn_save_tpl)

        self.btn_load_tpl = QPushButton("📂  Charger")
        self.btn_load_tpl.setObjectName("btn_secondary")
        self.btn_load_tpl.setMinimumHeight(30)
        self.btn_load_tpl.clicked.connect(self.template_load_requested.emit)
        tpl_row.addWidget(self.btn_load_tpl)

        layout.addLayout(tpl_row)

        # ── Source info ──
        layout.addSpacing(8)
        src_text = " · ".join(SWISS_SOURCE_NAMES)
        src_label = QLabel(f"Sources : {src_text}")
        src_label.setStyleSheet(
            "color:#6c7086; font-size:10px; font-style:italic;"
        )
        src_label.setWordWrap(True)
        layout.addWidget(src_label)

        layout.addStretch()
        scroll.setWidget(container)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.addWidget(scroll)

    # ── Helpers ──

    @staticmethod
    def _section_label(text: str) -> QLabel:
        lbl = QLabel(text)
        lbl.setObjectName("label_section")
        lbl.setStyleSheet(
            "font-size:10px; font-weight:700; color:#6c7086;"
            "letter-spacing:1px; margin-top:4px;"
        )
        return lbl

    # ── API publique ──

    def _set_all_regions(self, checked: bool) -> None:
        for _, cb in self._region_checks:
            cb.setChecked(checked)

    def get_selected_cities(self) -> list[str]:
        """Retourne la liste des noms de villes cochées."""
        return [city for city, cb in self._region_checks if cb.isChecked()]

    def get_params(self) -> dict:
        return {
            "keywords":           self.input_keywords.text().strip(),
            "max_border_minutes": self.spin_border.value(),
            "cities":             self.get_selected_cities(),
        }

    def set_searching(self, searching: bool) -> None:
        self.btn_search.setEnabled(not searching)
        self.btn_search.setText(
            "⏳  Recherche en cours…" if searching
            else "\U0001f1e8\U0001f1ed  Lancer la recherche"
        )

    def load_template(self, keywords: str, max_border_minutes: int) -> None:
        """Charge un template suisse dans les champs de recherche."""
        self.input_keywords.setText(keywords)
        self.spin_border.setValue(max_border_minutes)

    # ── Slots ──

    def _on_search(self):
        params = self.get_params()
        if not params["keywords"]:
            return
        if not params["cities"]:
            return
        self.search_requested.emit(params)
