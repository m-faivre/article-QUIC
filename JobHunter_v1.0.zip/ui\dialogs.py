"""
Boîtes de dialogue : templates, paramètres, édition candidature.
"""
import html

from PyQt6.QtCore import Qt, QRegularExpression
from PyQt6.QtGui import QRegularExpressionValidator
from PyQt6.QtWidgets import (
    QDialog, QDialogButtonBox, QVBoxLayout, QHBoxLayout,
    QLabel, QLineEdit, QTextEdit, QPushButton,
    QListWidget, QListWidgetItem, QMessageBox, QTabWidget,
    QWidget, QFormLayout, QSpinBox, QFrame, QCheckBox
)

import database.db_manager as db
from utils.communes import search as commune_search, get_display_name
from utils.geocoder import geocode
from models.models import Application, SearchTemplate, SwissSearchTemplate
from ui.styles import COLORS


def _esc(text: str) -> str:
    """Échappe le HTML pour éviter l'injection dans les QLabels."""
    return html.escape(str(text or ""), quote=True)


def _iso_to_fr(iso_date: str) -> str:
    """Convertit une date ISO (YYYY-MM-DD...) en format FR (JJ/MM/AAAA)."""
    if not iso_date:
        return ""
    try:
        from datetime import datetime
        dt = datetime.fromisoformat(iso_date.replace(" ", "T")[:19])
        return dt.strftime("%d/%m/%Y")
    except (ValueError, TypeError):
        return iso_date[:10]


def _fr_to_iso(fr_date: str) -> str:
    """Convertit une date FR (JJ/MM/AAAA) en ISO (YYYY-MM-DD).
    Retourne None si le format est invalide."""
    if not fr_date or not fr_date.strip():
        return ""
    fr_date = fr_date.strip()
    try:
        from datetime import datetime
        dt = datetime.strptime(fr_date, "%d/%m/%Y")
        return dt.strftime("%Y-%m-%d")
    except ValueError:
        return None


# ─── Template Dialog ──────────────────────────────────────────────────────────

class SaveTemplateDialog(QDialog):
    def __init__(self, params: dict, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Sauvegarder le template")
        self.setMinimumWidth(360)
        self._params = params
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("Nom du template :"))
        self.input_name = QLineEdit()
        self.input_name.setPlaceholderText("Ex : Tech info Bourg-en-Bresse")
        layout.addWidget(self.input_name)
        summary = (
            f"<b>Mots-clés :</b> {_esc(params.get('keywords', '—'))}<br>"
            f"<b>Lieu :</b> {_esc(params.get('location', '—'))}  ({params.get('radius', 30)} km)<br>"
            f"<b>Contrat :</b> {_esc(params.get('contract_type', 'Tous'))}<br>"
            f"<b>Sources :</b> {_esc(', '.join(params.get('sources', [])))}"
        )
        lbl = QLabel(summary)
        lbl.setStyleSheet("color:#a6adc8; font-size:12px; background:#252536; "
                          "border-radius:6px; padding:8px;")
        lbl.setWordWrap(True)
        layout.addWidget(lbl)
        btns = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        btns.accepted.connect(self._on_accept)
        btns.rejected.connect(self.reject)
        layout.addWidget(btns)
        self._result_template = None

    def _on_accept(self):
        name = self.input_name.text().strip()
        if not name:
            QMessageBox.warning(self, "Nom requis", "Veuillez entrer un nom pour le template.")
            return
        self._result_template = SearchTemplate(
            name=name,
            keywords=self._params.get("keywords", ""),
            location=self._params.get("location", ""),
            radius=self._params.get("radius", 30),
            contract_types=[self._params.get("contract_type", "Tous")],
            sources=self._params.get("sources", []),
        )
        self.accept()

    def get_template(self) -> SearchTemplate | None:
        return self._result_template


class LoadTemplateDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Charger un template")
        self.setMinimumSize(400, 350)
        self._selected = None
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("Sélectionnez un template :"))
        self.list_widget = QListWidget()
        self._templates = db.get_templates()
        for tpl in self._templates:
            item = QListWidgetItem(
                f"{tpl.name}  —  {tpl.keywords or '—'}  ·  {tpl.location or '—'}"
            )
            item.setData(Qt.ItemDataRole.UserRole, tpl)
            self.list_widget.addItem(item)
        self.list_widget.doubleClicked.connect(self._on_double_click)
        layout.addWidget(self.list_widget, 1)

        btn_del = QPushButton("🗑  Supprimer le template sélectionné")
        btn_del.setObjectName("btn_danger")
        btn_del.clicked.connect(self._on_delete)
        layout.addWidget(btn_del)

        btns = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        layout.addWidget(btns)

    def _on_double_click(self):
        self.accept()

    def _on_delete(self):
        item = self.list_widget.currentItem()
        if not item:
            return
        tpl: SearchTemplate = item.data(Qt.ItemDataRole.UserRole)
        db.delete_template(tpl.id)
        self.list_widget.takeItem(self.list_widget.row(item))

    def get_selected(self) -> SearchTemplate | None:
        item = self.list_widget.currentItem()
        return item.data(Qt.ItemDataRole.UserRole) if item else None


# ─── Swiss Template Dialogs ───────────────────────────────────────────────────

class SaveSwissTemplateDialog(QDialog):
    def __init__(self, params: dict, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Sauvegarder le template Suisse")
        self.setMinimumWidth(360)
        self._params = params
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("Nom du template :"))
        self.input_name = QLineEdit()
        self.input_name.setPlaceholderText("Ex : Admin Sys Suisse 40min")
        layout.addWidget(self.input_name)
        summary = (
            f"<b>Mots-clés :</b> {_esc(params.get('keywords', '—'))}<br>"
            f"<b>Distance max :</b> {params.get('max_border_minutes', 40)} min"
        )
        lbl = QLabel(summary)
        lbl.setStyleSheet("color:#a6adc8; font-size:12px; background:#252536; "
                          "border-radius:6px; padding:8px;")
        lbl.setWordWrap(True)
        layout.addWidget(lbl)
        btns = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        btns.accepted.connect(self._on_accept)
        btns.rejected.connect(self.reject)
        layout.addWidget(btns)
        self._result_template = None

    def _on_accept(self):
        name = self.input_name.text().strip()
        if not name:
            QMessageBox.warning(self, "Nom requis", "Veuillez entrer un nom pour le template.")
            return
        self._result_template = SwissSearchTemplate(
            name=name,
            keywords=self._params.get("keywords", ""),
            max_border_minutes=self._params.get("max_border_minutes", 40),
        )
        self.accept()

    def get_template(self) -> SwissSearchTemplate | None:
        return self._result_template


class LoadSwissTemplateDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Charger un template Suisse")
        self.setMinimumSize(400, 300)
        self._selected = None
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("Sélectionnez un template :"))
        self.list_widget = QListWidget()
        self._templates = db.get_swiss_templates()
        for tpl in self._templates:
            item = QListWidgetItem(
                f"{tpl.name}  —  {tpl.keywords or '—'}  ·  {tpl.max_border_minutes} min"
            )
            item.setData(Qt.ItemDataRole.UserRole, tpl)
            self.list_widget.addItem(item)
        self.list_widget.doubleClicked.connect(self._on_double_click)
        layout.addWidget(self.list_widget, 1)

        btn_del = QPushButton("🗑  Supprimer le template sélectionné")
        btn_del.setObjectName("btn_danger")
        btn_del.clicked.connect(self._on_delete)
        layout.addWidget(btn_del)

        btns = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        layout.addWidget(btns)

    def _on_double_click(self):
        self.accept()

    def _on_delete(self):
        item = self.list_widget.currentItem()
        if not item:
            return
        tpl: SwissSearchTemplate = item.data(Qt.ItemDataRole.UserRole)
        db.delete_swiss_template(tpl.id)
        self.list_widget.takeItem(self.list_widget.row(item))

    def get_selected(self) -> SwissSearchTemplate | None:
        item = self.list_widget.currentItem()
        return item.data(Qt.ItemDataRole.UserRole) if item else None


# ─── Widget horaire HH:mm avec boutons ▲▼ ────────────────────────────────────

class _TimePickerWidget(QWidget):
    """Champ HH:mm éditable manuellement + boutons ▲▼.
    Curseur sur HH → ±1 h, curseur sur mm → ±15 min.
    Boucle des minutes → report automatique sur les heures."""

    _BTN_STYLE = """
        QPushButton {
            background: #313244; color: #cdd6f4; border: none;
            border-radius: 3px; font-size: 11px; font-weight: 700;
            padding: 0px;
        }
        QPushButton:hover { background: #45475a; }
        QPushButton:pressed { background: #585b70; }
    """

    def __init__(self, hour: int = 8, minute: int = 0, parent=None):
        super().__init__(parent)
        self._section = "hour"          # "hour" ou "min"

        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(4)

        # Champ texte HH:mm
        self._edit = QLineEdit(f"{hour:02d}:{minute:02d}")
        self._edit.setInputMask("99:99")
        self._edit.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._edit.setFixedWidth(64)
        self._edit.setStyleSheet(
            "font-size:14px; font-weight:700; padding:4px 6px;"
            "background:#1e1e2e; color:#cdd6f4; border:1px solid #45475a;"
            "border-radius:6px;"
        )
        rx = QRegularExpression(r"([01]\d|2[0-3]):[0-5]\d")
        self._edit.setValidator(QRegularExpressionValidator(rx))
        self._edit.editingFinished.connect(self._clamp)
        self._edit.cursorPositionChanged.connect(self._on_cursor_moved)
        lay.addWidget(self._edit)

        # Boutons ▲ / ▼ — setFocusPolicy(NoFocus) pour ne pas voler le focus
        btn_col = QVBoxLayout()
        btn_col.setContentsMargins(0, 0, 0, 0)
        btn_col.setSpacing(1)

        btn_up = QPushButton("▲")
        btn_up.setFixedSize(22, 18)
        btn_up.setStyleSheet(self._BTN_STYLE)
        btn_up.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        btn_up.setAutoRepeat(True)
        btn_up.setAutoRepeatDelay(400)
        btn_up.setAutoRepeatInterval(150)
        btn_up.clicked.connect(lambda: self._step(1))
        btn_col.addWidget(btn_up)

        btn_down = QPushButton("▼")
        btn_down.setFixedSize(22, 18)
        btn_down.setStyleSheet(self._BTN_STYLE)
        btn_down.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        btn_down.setAutoRepeat(True)
        btn_down.setAutoRepeatDelay(400)
        btn_down.setAutoRepeatInterval(150)
        btn_down.clicked.connect(lambda: self._step(-1))
        btn_col.addWidget(btn_down)

        lay.addLayout(btn_col)

        # Sélection initiale sur les heures
        self._highlight_section()

    # ── API publique ──

    def time_str(self) -> str:
        """Retourne 'HH:mm'."""
        self._clamp()
        return self._edit.text()

    def set_time(self, hour: int, minute: int) -> None:
        self._edit.setText(f"{hour:02d}:{minute:02d}")

    # ── Interne ──

    def _cur_hm(self) -> tuple[int, int]:
        parts = self._edit.text().split(":")
        try:
            return int(parts[0]), int(parts[1])
        except (ValueError, IndexError):
            return 8, 0

    def _clamp(self) -> None:
        """Force les valeurs dans les bornes après saisie libre."""
        h, m = self._cur_hm()
        h = max(0, min(23, h))
        m = max(0, min(59, m))
        self._edit.setText(f"{h:02d}:{m:02d}")

    def _on_cursor_moved(self, _old: int, new: int) -> None:
        """Détecte la section active selon la position du curseur."""
        self._section = "hour" if new <= 2 else "min"

    def _highlight_section(self) -> None:
        """Sélectionne visuellement la section active (HH ou mm)."""
        if self._section == "hour":
            self._edit.setSelection(0, 2)
        else:
            self._edit.setSelection(3, 2)

    def _step(self, direction: int) -> None:
        """Incrémente/décrémente selon la section active."""
        h, m = self._cur_hm()
        section = self._section           # figer avant toute modif

        if section == "hour":
            h = (h + direction) % 24
        else:
            old_m = m
            m = (m + direction * 15) % 60
            # Boucle des minutes → report sur les heures
            if direction > 0 and m < old_m:
                h = (h + 1) % 24
            elif direction < 0 and m > old_m:
                h = (h - 1) % 24

        # Bloquer cursorPositionChanged pendant la mise à jour
        self._edit.blockSignals(True)
        self._edit.setText(f"{h:02d}:{m:02d}")
        self._edit.blockSignals(False)
        self._highlight_section()


# ─── Settings Dialog ──────────────────────────────────────────────────────────

class SettingsDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("⚙️  Paramètres")
        self.setMinimumSize(520, 440)
        layout = QVBoxLayout(self)
        tabs = QTabWidget()

        # ── Onglet Localisation domicile ──
        tab_loc = QWidget()
        loc_layout = QVBoxLayout(tab_loc)
        loc_layout.setSpacing(12)
        loc_layout.setContentsMargins(16, 16, 16, 16)

        info_lbl = QLabel(
            "Définissez votre adresse de domicile. Elle servira à calculer "
            "la distance routière jusqu\'au lieu de chaque offre."
        )
        info_lbl.setWordWrap(True)
        info_lbl.setStyleSheet("color:#a6adc8; font-size:12px;")
        loc_layout.addWidget(info_lbl)

        form = QFormLayout()
        form.setSpacing(10)

        self.home_city_edit = QLineEdit(db.get_setting("home_city", ""))
        self.home_city_edit.setPlaceholderText("Ex: Bourg-en-Bresse")

        # Completer autocomplétion commune
        from PyQt6.QtCore import QStringListModel, QTimer
        from PyQt6.QtWidgets import QCompleter
        self._home_completer_model = QStringListModel()
        self._home_completer = QCompleter(self)
        self._home_completer.setModel(self._home_completer_model)
        self._home_completer.setCompletionMode(QCompleter.CompletionMode.UnfilteredPopupCompletion)
        self._home_completer.setMaxVisibleItems(8)
        self._home_completer.popup().setStyleSheet(
            "QListView { background:#1e1e2e; color:#cdd6f4; border:1px solid #45475a;"
            " border-radius:6px; padding:4px; font-size:12px; }"
            "QListView::item { padding:4px 8px; border-radius:4px; }"
            "QListView::item:selected { background:#313244; color:#cba6f7; }"
        )
        self.home_city_edit.setCompleter(self._home_completer)
        self._home_timer = QTimer(self)
        self._home_timer.setSingleShot(True)
        self._home_timer.setInterval(200)
        self._home_timer.timeout.connect(self._update_home_completions)
        self.home_city_edit.textChanged.connect(lambda t: self._home_timer.start() if len(t) >= 2 else None)
        self._home_completer.activated.connect(
            lambda t: (self.home_city_edit.blockSignals(True),
                       self.home_city_edit.setText(t.split(" (")[0]),
                       self.home_city_edit.blockSignals(False))
        )

        self.home_addr_edit = QLineEdit(db.get_setting("home_address", ""))
        self.home_addr_edit.setPlaceholderText("Ex: 12 rue de la Paix (optionnel, pour plus de précision)")

        form.addRow("Ville :", self.home_city_edit)
        form.addRow("Adresse :", self.home_addr_edit)
        loc_layout.addLayout(form)

        # Bouton tester + status
        test_row = QHBoxLayout()
        self.btn_test_loc = QPushButton("📍  Vérifier la localisation")
        self.btn_test_loc.clicked.connect(self._on_test_location)
        self.lbl_loc_status = QLabel("")
        self.lbl_loc_status.setWordWrap(True)
        self.lbl_loc_status.setStyleSheet("font-size:11px; color:#a6e3a1;")
        test_row.addWidget(self.btn_test_loc)
        test_row.addStretch()
        loc_layout.addLayout(test_row)
        loc_layout.addWidget(self.lbl_loc_status)

        # Coordonnées (lecture seule, remplies par le geocoder)
        self._home_lat = db.get_setting("home_lat", "")
        self._home_lng = db.get_setting("home_lng", "")
        coord_lbl = QLabel("")
        if self._home_lat and self._home_lng:
            try:
                coord_lbl.setText(f"📌 Coordonnées : {float(self._home_lat):.4f}, {float(self._home_lng):.4f}")
                coord_lbl.setStyleSheet("color:#6c7086; font-size:10px;")
            except (ValueError, TypeError):
                self._home_lat = ""
                self._home_lng = ""
        self._coord_lbl = coord_lbl
        loc_layout.addWidget(coord_lbl)

        loc_layout.addStretch()
        tabs.addTab(tab_loc, "📍  Localisation")

        # ── Onglet Auto-scan ──
        tab_scan = QWidget()
        scan_lay = QVBoxLayout(tab_scan)
        scan_lay.setSpacing(12)
        scan_lay.setContentsMargins(16, 16, 16, 16)

        self.chk_auto_scan = QCheckBox("Activer l'auto-scan au lancement")
        self.chk_auto_scan.setChecked(
            db.get_setting("auto_scan_enabled", "false") == "true"
        )
        self.chk_auto_scan.setStyleSheet("font-size:13px; font-weight:600;")
        scan_lay.addWidget(self.chk_auto_scan)

        # Horaire d'auto-scan
        sched_row = QHBoxLayout()
        sched_row.setSpacing(8)
        sched_lbl = QLabel("🕐  Horaire du scan quotidien :")
        sched_lbl.setStyleSheet("font-size:12px; font-weight:600; color:#cdd6f4;")
        sched_row.addWidget(sched_lbl)

        saved_time = db.get_setting("auto_scan_time", "08:00")
        try:
            _parts = saved_time.split(":")
            _h, _m = int(_parts[0]), int(_parts[1])
        except (ValueError, IndexError):
            _h, _m = 8, 0

        self.time_auto_scan = _TimePickerWidget(_h, _m)
        sched_row.addWidget(self.time_auto_scan)
        sched_row.addStretch()
        scan_lay.addLayout(sched_row)

        scan_info = QLabel(
            "Lorsque cette option est activée, JobHunter scanne automatiquement "
            "toutes vos recherches sauvegardées (templates) au lancement de "
            "l'application.\n\n"
            "• Le scan se déclenche une fois par jour à l'horaire choisi.\n"
            "• Si l'application est lancée après l'horaire, le scan se fait "
            "immédiatement (s'il n'a pas été fait aujourd'hui).\n"
            "• Les résultats apparaissent dans des onglets séparés et fermables.\n"
            "• Les offres déjà postulées ou masquées sont filtrées.\n"
            "• Une notification Windows s'affiche si de nouvelles offres sont trouvées."
        )
        scan_info.setWordWrap(True)
        scan_info.setStyleSheet("color:#a6adc8; font-size:12px; line-height:1.5;")
        scan_lay.addWidget(scan_info)

        # Info dernier scan
        last_scan = db.get_setting("last_auto_scan", "")
        if last_scan:
            try:
                from datetime import datetime
                last_dt = datetime.fromisoformat(last_scan)
                last_str = last_dt.strftime("%d/%m/%Y à %H:%M")
                lbl_last = QLabel(f"📅  Dernier auto-scan : {last_str}")
            except (ValueError, TypeError):
                lbl_last = QLabel("📅  Dernier auto-scan : date inconnue")
        else:
            lbl_last = QLabel("📅  Aucun auto-scan effectué")
        lbl_last.setStyleSheet("color:#6c7086; font-size:11px; margin-top:8px;")
        scan_lay.addWidget(lbl_last)

        scan_lay.addStretch()
        tabs.addTab(tab_scan, "🔄  Auto-scan")

        layout.addWidget(tabs, 1)
        btns = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        btns.accepted.connect(self._on_save)
        btns.rejected.connect(self.reject)
        layout.addWidget(btns)

    def _update_home_completions(self):
        query = self.home_city_edit.text()
        if len(query) < 2:
            return
        results = commune_search(query, limit=8)
        self._home_completer_model.setStringList([r.label() for r in results])
        if results:
            self._home_completer.complete()

    def _on_test_location(self):
        city = self.home_city_edit.text().strip()
        addr = self.home_addr_edit.text().strip()
        query = f"{addr}, {city}" if addr else city
        if not query:
            self.lbl_loc_status.setText("Saisissez une ville d\'abord.")
            self.lbl_loc_status.setStyleSheet("color:#f38ba8; font-size:11px;")
            return
        self.btn_test_loc.setEnabled(False)
        self.btn_test_loc.setText("⏳  Recherche…")
        # Normaliser le nom de ville
        official = get_display_name(city)
        if official:
            self.home_city_edit.blockSignals(True)
            self.home_city_edit.setText(official)
            self.home_city_edit.blockSignals(False)
            if addr:
                query = f"{addr}, {official}"
            else:
                query = official
        coords = geocode(query)
        self.btn_test_loc.setEnabled(True)
        self.btn_test_loc.setText("📍  Vérifier la localisation")
        if coords:
            self._home_lat = str(coords[0])
            self._home_lng = str(coords[1])
            self.lbl_loc_status.setText(f"✅  Trouvé : {query}")
            self.lbl_loc_status.setStyleSheet("color:#a6e3a1; font-size:11px;")
            self._coord_lbl.setText(f"📌 Coordonnées : {coords[0]:.4f}, {coords[1]:.4f}")
            self._coord_lbl.setStyleSheet("color:#6c7086; font-size:10px;")
        else:
            self._home_lat = ""
            self._home_lng = ""
            self.lbl_loc_status.setText("❌  Adresse introuvable. Essayez avec juste la ville.")
            self.lbl_loc_status.setStyleSheet("color:#f38ba8; font-size:11px;")

    def _on_save(self):
        db.set_setting("home_city",    self.home_city_edit.text().strip())
        db.set_setting("home_address", self.home_addr_edit.text().strip())
        db.set_setting("home_lat",     self._home_lat)
        db.set_setting("home_lng",     self._home_lng)
        # Auto-scan
        db.set_setting(
            "auto_scan_enabled",
            "true" if self.chk_auto_scan.isChecked() else "false",
        )
        db.set_setting("auto_scan_time", self.time_auto_scan.time_str())
        self.accept()


# ─── Edit Application Dialog ─────────────────────────────────────────────────

class EditApplicationDialog(QDialog):
    """Dialogue pour éditer les infos d'une candidature (entreprise, contact, lieu, etc.)."""

    def __init__(self, app, parent=None):
        super().__init__(parent)
        self.app = app
        self.setWindowTitle(f"Éditer la candidature — {app.job_title}")
        self.setMinimumWidth(480)
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setSpacing(12)

        # Résumé
        info = QFrame()
        info.setStyleSheet("QFrame { background:#252536; border-radius:8px; }")
        i_lay = QVBoxLayout(info)
        i_lay.setContentsMargins(12, 10, 12, 10)
        lbl = QLabel(f"<b style='color:#cdd6f4;font-size:13px;'>{_esc(self.app.job_title)}</b>")
        i_lay.addWidget(lbl)
        layout.addWidget(info)

        form = QFormLayout()
        form.setSpacing(10)

        self.edit_title = QLineEdit(self.app.job_title or "")
        self.edit_title.setPlaceholderText("Intitulé du poste")

        self.edit_company = QLineEdit(self.app.company or "")
        self.edit_company.setPlaceholderText("Nom de l'entreprise")

        self.edit_location = QLineEdit(getattr(self.app, "location", "") or "")
        self.edit_location.setPlaceholderText("Ville, département…")

        self.edit_source = QLineEdit(self.app.source or "")
        self.edit_source.setPlaceholderText("France Travail, HelloWork…")

        self.edit_contact = QLineEdit(getattr(self.app, "contact", "") or "")
        self.edit_contact.setPlaceholderText("Prénom Nom, email, poste…")

        from datetime import date as _date
        existing_date = _iso_to_fr(self.app.sent_at) if self.app.sent_at else _date.today().strftime("%d/%m/%Y")
        self.edit_date = QLineEdit(existing_date)
        self.edit_date.setPlaceholderText("JJ/MM/AAAA")
        self.edit_date.setToolTip("Format attendu : JJ/MM/AAAA")
        self.lbl_date_error = QLabel("")
        self.lbl_date_error.setStyleSheet("color:#f38ba8; font-size:10px;")
        self.lbl_date_error.setVisible(False)
        self.edit_date.textChanged.connect(self._validate_date)

        self.combo_status = QComboBox()
        statuses = [("pending","En attente"), ("sent","Envoyée"),
                    ("interview","Entretien"), ("rejected","Refusée"), ("accepted","Acceptée")]
        for val, label in statuses:
            self.combo_status.addItem(label, val)
        cur_status = self.app.status or "sent"
        idx = next((i for i,(v,_) in enumerate(statuses) if v == cur_status), 1)
        self.combo_status.setCurrentIndex(idx)

        self.edit_notes = QTextEdit(self.app.notes or "")
        self.edit_notes.setPlaceholderText("Notes, remarques…")
        self.edit_notes.setMaximumHeight(80)

        form.addRow("Poste :", self.edit_title)
        form.addRow("Entreprise :", self.edit_company)
        form.addRow("Lieu :", self.edit_location)
        form.addRow("Plateforme :", self.edit_source)
        form.addRow("Contact :", self.edit_contact)
        date_widget = QWidget()
        date_lay = QVBoxLayout(date_widget)
        date_lay.setContentsMargins(0, 0, 0, 0)
        date_lay.setSpacing(2)
        date_lay.addWidget(self.edit_date)
        date_lay.addWidget(self.lbl_date_error)
        form.addRow("Date d'envoi :", date_widget)
        form.addRow("Statut :", self.combo_status)
        form.addRow("Notes :", self.edit_notes)
        layout.addLayout(form)

        btns = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel
        )
        btns.accepted.connect(self._on_save)
        btns.rejected.connect(self.reject)
        layout.addWidget(btns)

    def _validate_date(self) -> bool:
        """Valide le format de date FR et affiche une erreur si invalide."""
        text = self.edit_date.text().strip()
        if not text:
            self.lbl_date_error.setVisible(False)
            return True
        iso = _fr_to_iso(text)
        if iso is None:
            self.lbl_date_error.setText("Format invalide — attendu : JJ/MM/AAAA")
            self.lbl_date_error.setVisible(True)
            self.edit_date.setStyleSheet("border: 1px solid #f38ba8; border-radius:4px; padding:4px;")
            return False
        self.lbl_date_error.setVisible(False)
        self.edit_date.setStyleSheet("")
        return True

    def _on_save(self):
        # Valider la date avant de sauvegarder
        date_text = self.edit_date.text().strip()
        if date_text:
            iso_date = _fr_to_iso(date_text)
            if iso_date is None:
                QMessageBox.warning(
                    self, "Date invalide",
                    f"Le format de date « {date_text} » n'est pas valide.\n"
                    "Utilisez le format JJ/MM/AAAA (ex: 15/03/2026)."
                )
                self.edit_date.setFocus()
                return
        else:
            iso_date = ""

        import database.db_manager as _db
        fields = {
            "job_title": self.edit_title.text().strip(),
            "company":   self.edit_company.text().strip(),
            "location":  self.edit_location.text().strip(),
            "source":    self.edit_source.text().strip(),
            "contact":   self.edit_contact.text().strip(),
            "sent_at":   iso_date,
            "status":    self.combo_status.currentData(),
            "notes":     self.edit_notes.toPlainText().strip(),
        }
        if self.app.id:
            _db.update_application(self.app.id, fields)
            # Sync local object
            for k, v in fields.items():
                setattr(self.app, k, v)
        self.accept()
