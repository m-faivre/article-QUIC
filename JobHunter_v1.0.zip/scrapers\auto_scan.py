"""
Auto-scan — scanne tous les templates sauvegardés au lancement.

Le worker itère les templates séquentiellement (un seul QThread).
Pour chaque template, il interroge toutes les sources configurées,
filtre les offres déjà postulées / masquées, puis émet les résultats
par signal afin que l'UI crée un onglet par template.
"""
import time
from typing import List

from PyQt6.QtCore import QThread, pyqtSignal

import database.db_manager as db
import utils.logger as log
from models.models import Job, SearchTemplate
from scrapers.aggregator import _create_scraper, ALL_SOURCE_NAMES


class AutoScanWorker(QThread):
    """Worker séquentiel : un template à la fois, toutes sources."""

    # Signaux vers l'UI
    template_started = pyqtSignal(str)            # nom du template
    template_jobs    = pyqtSignal(str, list)       # nom, liste de Jobs
    template_done    = pyqtSignal(str, int)        # nom, nb résultats
    all_done         = pyqtSignal(int)             # total global

    def __init__(self, templates: List[SearchTemplate]):
        super().__init__()
        self.templates = templates
        self._cancelled = False

    def cancel(self):
        self._cancelled = True

    def run(self):
        total = 0

        # Pré-charger les ensembles de filtrage (une seule lecture DB)
        try:
            applied_ids = db.get_applied_job_ids()
        except Exception:
            applied_ids = set()
        try:
            hidden_ids = db.get_hidden_job_ids()
        except Exception:
            hidden_ids = set()

        log.info(f"[AutoScan] Démarrage — {len(self.templates)} template(s)")

        for tpl in self.templates:
            if self._cancelled:
                log.info("[AutoScan] Annulé par l'utilisateur")
                break

            name = tpl.name
            self.template_started.emit(name)
            log.info(f"[AutoScan] ━━ Template «{name}» : '{tpl.keywords}' @ {tpl.location or 'France'}")

            tpl_jobs: List[Job] = []

            # Le template stocke contract_types comme liste.
            # Les scrapers attendent un seul contract_type (str).
            # Si le template a un seul type → on le passe ; sinon "Tous".
            contract_type = "Tous"
            if tpl.contract_types and len(tpl.contract_types) == 1:
                contract_type = tpl.contract_types[0]

            for source_name in (tpl.sources or ALL_SOURCE_NAMES):
                if self._cancelled:
                    break

                # Nouvelle instance par source → thread-safe
                scraper = _create_scraper(source_name)
                if scraper is None:
                    continue

                try:
                    jobs = scraper.search(
                        keywords=tpl.keywords,
                        location=tpl.location,
                        radius=tpl.radius,
                        contract_type=contract_type,
                        max_results=50,
                    )
                    tpl_jobs.extend(jobs)
                    log.info(f"[AutoScan]   {source_name} → {len(jobs)} offre(s)")
                except Exception as e:
                    log.warning(f"[AutoScan]   {source_name} erreur : {e}")

                # Petit délai inter-source pour ne pas spammer
                time.sleep(0.3)

            # Filtrer applied + hidden
            filtered = [
                j for j in tpl_jobs
                if j.id not in applied_ids and j.id not in hidden_ids
            ]

            count = len(filtered)
            total += count
            log.info(f"[AutoScan] «{name}» → {count} offre(s) nouvelles (sur {len(tpl_jobs)} brutes)")

            if filtered:
                self.template_jobs.emit(name, filtered)

            self.template_done.emit(name, count)

        log.info(f"[AutoScan] Terminé — {total} offre(s) nouvelles au total")
        self.all_done.emit(total)
