"""
Jobs.ch — API JSON publique (JobCloud AG).

Même API que Jobup.ch mais pool d'offres différent (Suisse alémanique).
Endpoint recherche :
  GET /api/v1/public/search
    ?query=<keywords>&rows=20&start=0

Aucune authentification requise.
Les coordonnées GPS sont incluses dans les résultats de recherche.
"""
import re
import time
from typing import List, Optional

import utils.logger as log
from models.models import Job
from scrapers.base_scraper import BaseScraper

BASE = "https://www.jobs.ch"
SEARCH_URL = f"{BASE}/api/v1/public/search"

# Mapping des employment_type_ids → libellés
_TYPE_MAP = {
    "1": "Temporaire",
    "2": "CDD",
    "3": "Stage",
    "4": "Freelance",
    "5": "CDI",
}

PAGE_SIZE = 20


class JobsChScraper(BaseScraper):
    SOURCE_NAME = "Jobs.ch"

    def __init__(self):
        super().__init__()
        self.session.headers.update({
            "Accept": "application/json, text/plain, */*",
            "Referer": f"{BASE}/en/jobs/",
        })

    # ── Recherche ─────────────────────────────────────────────────────────────

    def search(self, keywords, location, radius=30,
               contract_type="Tous", max_results=50) -> List[Job]:
        params = {
            "query": keywords,
            "rows": min(PAGE_SIZE, max_results),
            "start": 0,
        }
        if location:
            params["location"] = location

        log.info(
            f"[Jobs.ch] Recherche : '{keywords}' | lieu={location or 'Suisse'}"
        )

        all_jobs: List[Job] = []
        pages_fetched = 0
        max_pages = max(1, (max_results + PAGE_SIZE - 1) // PAGE_SIZE)

        while pages_fetched < max_pages:
            r = self._get(SEARCH_URL, params=params)
            if r is None:
                break

            try:
                data = r.json()
            except Exception:
                log.warning("[Jobs.ch] Réponse non-JSON")
                break

            documents = data.get("documents", [])

            if pages_fetched == 0:
                total = data.get("total_hits", 0)
                log.info(f"[Jobs.ch] {total} offres totales")

            if not documents:
                break

            for doc in documents:
                if len(all_jobs) >= max_results:
                    break
                job = self._parse(doc)
                if job:
                    all_jobs.append(job)

            pages_fetched += 1

            if len(all_jobs) >= max_results or len(documents) < PAGE_SIZE:
                break

            params["start"] = pages_fetched * PAGE_SIZE
            time.sleep(0.5)

        log.info(f"[Jobs.ch] {len(all_jobs)} offres parsées")
        return all_jobs

    # ── Parsing ───────────────────────────────────────────────────────────────

    def _parse(self, doc: dict) -> Optional[Job]:
        try:
            job_id = doc.get("job_id", "")
            title = self._clean(doc.get("title", ""))
            if not title:
                return None

            company = self._clean_company(doc.get("company_name", ""))
            place = self._clean(doc.get("place", ""))

            # Type de contrat
            type_ids = doc.get("employment_type_ids") or []
            contract_parts = [_TYPE_MAP.get(str(t), str(t)) for t in type_ids]
            contract_type = ", ".join(contract_parts) if contract_parts else ""

            # Taux d'activité → ajouté au type de contrat
            grades = doc.get("employment_grades") or []
            if grades:
                g_min, g_max = min(grades), max(grades)
                grade_str = f"{g_min}%" if g_min == g_max else f"{g_min}-{g_max}%"
                contract_type = f"{contract_type} · {grade_str}" if contract_type else grade_str

            # Date de publication (format JJ/MM/AAAA)
            pub = doc.get("publication_date", "")
            date_str = ""
            if pub:
                raw = str(pub)[:10]  # "2026-03-11"
                if len(raw) == 10 and raw[4] == "-":
                    parts = raw.split("-")
                    date_str = f"{parts[2]}/{parts[1]}/{parts[0]}"
                else:
                    date_str = raw

            # URL — préfère de/fr/en dans cet ordre
            links = doc.get("_links", {})
            detail = (links.get("detail_de") or links.get("detail_fr")
                      or links.get("detail_en") or {})
            url = detail.get("href", "")

            # Description preview
            preview = self._clean(doc.get("preview", ""))

            # Coordonnées GPS → stockées dans company_info
            company_info = {}
            if company:
                company_info["name"] = company
            coords = doc.get("coordinates") or {}
            if coords.get("lat") and coords.get("lon"):
                company_info["_lat"] = coords["lat"]
                company_info["_lng"] = coords["lon"]

            # Salaire (taux d'activité affiché comme info)
            salary = ""  # l'API Jobs.ch ne fournit pas de salaire

            # Tags : langues requises
            tags = []
            for lang in (doc.get("language_skills") or []):
                if isinstance(lang, dict):
                    tags.append(lang.get("language", "").upper())

            return Job(
                id=self._make_id("Jobs.ch", job_id or title),
                title=title,
                company=company,
                location=place,
                contract_type=contract_type,
                salary=salary,
                posted_date=date_str,
                description=preview,
                source="Jobs.ch",
                url=url,
                company_info=company_info,
                tags=tags,
            )
        except Exception as e:
            log.warning(f"[Jobs.ch] Offre ignorée : {e}")
            return None

    # ── Détail ────────────────────────────────────────────────────────────────

    def get_details(self, job: Job) -> Job:
        """Récupère la description complète depuis la page HTML de l'offre."""
        if not job.url:
            return job

        old_accept = self.session.headers.get("Accept", "")
        self.session.headers["Accept"] = "text/html"
        soup = self._soup(job.url)
        self.session.headers["Accept"] = old_accept

        if soup is None:
            return job

        desc_el = soup.select_one(
            "[data-cy='vacancy-description'], .oc-richtext, "
            "article, .vacancy-description"
        )
        if desc_el:
            text = desc_el.get_text(separator="\n", strip=True)
            if text and len(text) > len(job.description or ""):
                job.description = text

        return job
