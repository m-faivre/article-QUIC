"""
Référentiel local des communes françaises (INSEE).
Source : data.gouv.fr — v_commune_2025.csv

Fournit :
  - search(query, limit)  → liste de CommuneResult pour l'autocomplétion
  - get_code(query)       → code INSEE exact ou None

La recherche tolère :
  - casse : "bourg EN BRESSE", "Bourg en Bresse", "BOURG-EN-BRESSE"
  - tirets/espaces interchangeables
  - accents optionnels : "saint-etienne" → "Saint-Étienne"
  - abréviation ST/STE : "st etienne" → "Saint-Étienne"
"""
import csv
import os
import re
import unicodedata
from dataclasses import dataclass
from typing import List, Optional

# Chemin absolu vers le CSV (relatif à ce fichier)
_CSV_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "communes.csv")

# Abréviations courantes
_ABBREVS = [
    (r"\bSTE\b",   "SAINTE"),
    (r"\bST\b",    "SAINT"),
]


@dataclass
class CommuneResult:
    code:    str   # code INSEE ex: "01053"
    name:    str   # nom affiché ex: "Bourg-en-Bresse"
    dept:    str   # département ex: "01"

    def label(self) -> str:
        """Texte affiché dans l'autocomplétion : "Bourg-en-Bresse (01)" """
        return f"{self.name} ({self.dept})"


def _normalize(text: str) -> str:
    """Normalise un texte pour la comparaison : sans accents, majuscules, tirets→espaces, ST→SAINT."""
    # Retirer le suffixe "(01)" ajouté par autocomplétion
    import re as _re
    text = _re.sub(r"\s*\(\d{2,3}\)\s*$", "", text.strip())
    text = unicodedata.normalize("NFD", text)
    text = "".join(c for c in text if unicodedata.category(c) != "Mn")
    text = text.upper().strip()
    text = re.sub(r"[-]", " ", text)
    text = re.sub(r"\s+", " ", text)
    for pattern, replacement in _ABBREVS:
        text = re.sub(pattern, replacement, text)
    return text


# ── Chargement du dictionnaire ─────────────────────────────────────────────

_communes: dict = {}   # clé normalisée → CommuneResult
_loaded = False


def _load():
    global _loaded
    if _loaded:
        return
    _loaded = True
    path = os.path.normpath(_CSV_PATH)
    if not os.path.exists(path):
        return
    with open(path, encoding="utf-8", newline="") as f:
        for row in csv.DictReader(f):
            if row.get("TYPECOM") not in ("COM", "ARM"):
                continue
            code  = row["COM"]
            name  = row["NCCENR"]   # ex: "Bourg-en-Bresse"
            dept  = row["DEP"]
            ncc   = row["NCC"]      # ex: "BOURG EN BRESSE"
            key   = _normalize(ncc)
            _communes[key] = CommuneResult(code=code, name=name, dept=dept)


# ── API publique ───────────────────────────────────────────────────────────

def search(query: str, limit: int = 10) -> List[CommuneResult]:
    """
    Retourne jusqu'à `limit` communes dont le nom commence par `query`.
    Résultats triés par longueur de nom (communes les plus courtes en premier).
    """
    _load()
    if not query or not query.strip():
        return []
    q = _normalize(query)
    # Match exact d'abord
    if q in _communes:
        exact = [_communes[q]]
    else:
        exact = []
    # Starts-with
    starts = [v for k, v in _communes.items() if k.startswith(q) and v not in exact]
    starts.sort(key=lambda c: len(c.name))
    return (exact + starts)[:limit]


def get_code(query: str) -> Optional[str]:
    """
    Retourne le code INSEE de la commune dont le nom correspond exactement.
    Retourne None si aucun match exact.
    """
    _load()
    if not query:
        return None
    q = _normalize(query)
    result = _communes.get(q)
    return result.code if result else None


def get_display_name(query: str) -> Optional[str]:
    """Retourne le nom officiel (avec accents/tirets) pour un nom saisi."""
    _load()
    if not query:
        return None
    q = _normalize(query)
    result = _communes.get(q)
    return result.name if result else None
