"""Classe de base — toutes les requêtes HTTP passent ici et sont loguées."""
import time
import hashlib
from abc import ABC, abstractmethod
from typing import List, Optional

import requests
from bs4 import BeautifulSoup

import utils.logger as log
from models.models import Job


REQUEST_TIMEOUT = 15
REQUEST_DELAY   = 0.8

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/122.0.0.0 Safari/537.36"
    ),
    "Accept-Language": "fr-FR,fr;q=0.9,en;q=0.8",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
}


class BaseScraper(ABC):
    SOURCE_NAME: str = ""

    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update(HEADERS)

    @abstractmethod
    def search(self, keywords, location, radius=30,
               contract_type="Tous", max_results=50) -> List[Job]:
        ...

    def get_details(self, job: Job) -> Job:
        return job

    # ── HTTP ──────────────────────────────────────────────────────────────────

    def _get(self, url: str, **kwargs) -> Optional[requests.Response]:
        params = kwargs.get("params", {})
        log.debug(f"[{self.SOURCE_NAME}] GET {url}")
        if params:
            log.debug(f"[{self.SOURCE_NAME}]   params={params}")
        try:
            time.sleep(REQUEST_DELAY)
            r = self.session.get(url, timeout=REQUEST_TIMEOUT, **kwargs)
            log.info(f"[{self.SOURCE_NAME}] → {r.status_code}  {len(r.content)} octets  ({r.url[:100]})")
            if r.status_code == 200:
                return r
            log.warning(f"[{self.SOURCE_NAME}] Statut {r.status_code} — ignoré")
            return None
        except requests.exceptions.ConnectionError as e:
            log.error(f"[{self.SOURCE_NAME}] Connexion impossible : {e}")
        except requests.exceptions.Timeout:
            log.error(f"[{self.SOURCE_NAME}] Timeout ({REQUEST_TIMEOUT}s)")
        except requests.RequestException as e:
            log.error(f"[{self.SOURCE_NAME}] Erreur : {e}")
        return None

    def _soup(self, url: str, **kwargs) -> Optional[BeautifulSoup]:
        r = self._get(url, **kwargs)
        if r is None:
            return None
        return BeautifulSoup(r.text, "lxml")

    # ── Helpers ───────────────────────────────────────────────────────────────

    @staticmethod
    def _make_id(source: str, key: str) -> str:
        return hashlib.md5(f"{source}:{key}".encode()).hexdigest()

    @staticmethod
    def _clean(text) -> str:
        return " ".join((text or "").split())

    @staticmethod
    def _clean_company(text, max_words: int = 5) -> str:
        """Nettoie et tronque un nom d'entreprise (max_words mots).

        Évite de stocker des descriptions entières dans le champ company.
        Coupe proprement au dernier mot complet, sans couper les noms
        composés avec tiret ou apostrophe.
        """
        name = " ".join((text or "").split())
        if not name:
            return ""
        # Couper au premier séparateur de phrase évident
        for sep in (".", ",", " - ", " – ", " | ", " / "):
            pos = name.find(sep)
            if 0 < pos < len(name) - 1:
                candidate = name[:pos].strip()
                # Garder seulement si c'est un vrai nom (pas un seul mot tronqué)
                if len(candidate) >= 2:
                    name = candidate
                    break
        # Limiter le nombre de mots
        words = name.split()
        if len(words) > max_words:
            name = " ".join(words[:max_words])
        return name
