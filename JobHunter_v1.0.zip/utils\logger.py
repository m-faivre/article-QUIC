"""
Logger centralisé JobHunter.
  - Écrit dans la console (stdout)
  - Écrit dans ~/.jobhunter/app.log (rotation à 2 Mo)
  - Émet un signal Qt pour le panneau de debug (après init_ui_logging)

Usage :
    import utils.logger as log
    log.debug("message")
    log.info("message")
    log.warning("message")
    log.error("message")
    log.exception("message")   # inclut la traceback courante
"""
import logging
import logging.handlers
import traceback
from pathlib import Path

# Fichier de log dans ~/.jobhunter/
LOG_DIR  = Path.home() / ".jobhunter"
LOG_DIR.mkdir(parents=True, exist_ok=True)
LOG_FILE = LOG_DIR / "app.log"

_FMT = logging.Formatter(
    "%(asctime)s [%(levelname)-7s] %(message)s",
    datefmt="%H:%M:%S",
)

_logger = logging.getLogger("jobhunter")
_logger.setLevel(logging.DEBUG)
_logger.propagate = False

# ── Console ──────────────────────────────────────────────────────────────────
_ch = logging.StreamHandler()
_ch.setLevel(logging.DEBUG)
_ch.setFormatter(_FMT)
_logger.addHandler(_ch)

# ── Fichier tournant (2 Mo × 3 fichiers) ─────────────────────────────────────
try:
    _fh = logging.handlers.RotatingFileHandler(
        str(LOG_FILE), maxBytes=2 * 1024 * 1024, backupCount=3,
        encoding="utf-8", delay=True,
    )
    _fh.setLevel(logging.DEBUG)
    _fh.setFormatter(_FMT)
    _logger.addHandler(_fh)
except Exception as e:
    _logger.warning(f"Impossible d'ouvrir le fichier log : {e}")

# ── Signal Qt (lazy) ─────────────────────────────────────────────────────────
_signals    = None
_ui_handler = None


def init_ui_logging() -> None:
    """
    Initialise le signal Qt pour le panneau de debug.
    Doit être appelé APRÈS QApplication.__init__().
    """
    global _signals, _ui_handler
    if _signals is not None:
        return

    try:
        from PyQt6.QtCore import QObject, pyqtSignal

        class _LogSignals(QObject):
            message = pyqtSignal(str, str)  # (level, formatted_text)

        _signals = _LogSignals()

        class _UIHandler(logging.Handler):
            def emit(self, record: logging.LogRecord) -> None:
                try:
                    _signals.message.emit(record.levelname, self.format(record))
                except Exception:
                    pass

        _ui_handler = _UIHandler()
        _ui_handler.setLevel(logging.DEBUG)
        _ui_handler.setFormatter(_FMT)
        _logger.addHandler(_ui_handler)

    except Exception as e:
        _logger.warning(f"init_ui_logging échoué : {e}")


def get_signal():
    """Retourne l'objet signal (ou None si pas encore initialisé)."""
    return _signals


# ── API publique ──────────────────────────────────────────────────────────────

def debug(msg: str)   -> None: _logger.debug(msg)
def info(msg: str)    -> None: _logger.info(msg)
def warning(msg: str) -> None: _logger.warning(msg)
def error(msg: str)   -> None: _logger.error(msg)

def exception(msg: str) -> None:
    """Log ERROR + traceback complète de l'exception courante."""
    tb = traceback.format_exc()
    _logger.error(f"{msg}\n{tb}")
