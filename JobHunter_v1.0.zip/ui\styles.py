"""
Thème sombre professionnel — palette Catppuccin Mocha.
"""

DARK_STYLESHEET = """
/* ── Base ──────────────────────────────────────────────── */
QMainWindow, QDialog, QWidget {
    background-color: #1e1e2e;
    color: #cdd6f4;
    font-family: "Segoe UI", sans-serif;
    font-size: 13px;
}

/* ── Tabs ───────────────────────────────────────────────── */
QTabWidget::pane {
    border: 1px solid #313244;
    border-radius: 6px;
    background-color: #1e1e2e;
}
QTabBar::tab {
    background-color: #181825;
    color: #6c7086;
    padding: 8px 20px;
    margin-right: 2px;
    border-top-left-radius: 6px;
    border-top-right-radius: 6px;
    font-weight: 500;
}
QTabBar::tab:selected {
    background-color: #1e1e2e;
    color: #cba6f7;
    border-bottom: 2px solid #cba6f7;
}
QTabBar::tab:hover:!selected {
    background-color: #252536;
    color: #cdd6f4;
}

/* ── Buttons ─────────────────────────────────────────────── */
QPushButton {
    background-color: #313244;
    color: #cdd6f4;
    border: 1px solid #45475a;
    border-radius: 6px;
    padding: 7px 16px;
    font-weight: 500;
}
QPushButton:hover {
    background-color: #45475a;
    border-color: #585b70;
}
QPushButton:pressed {
    background-color: #585b70;
}
QPushButton#btn_primary {
    background-color: #cba6f7;
    color: #1e1e2e;
    border: none;
    font-weight: 600;
}
QPushButton#btn_primary:hover {
    background-color: #d4b8f9;
}
QPushButton#btn_primary:pressed {
    background-color: #b891f5;
}
QPushButton#btn_success {
    background-color: #a6e3a1;
    color: #1e1e2e;
    border: none;
    font-weight: 600;
}
QPushButton#btn_success:hover {
    background-color: #b8ebb4;
}
QPushButton#btn_danger {
    background-color: #f38ba8;
    color: #1e1e2e;
    border: none;
    font-weight: 600;
}
QPushButton#btn_danger:hover {
    background-color: #f5a0b5;
}
QPushButton:disabled {
    background-color: #313244;
    color: #45475a;
    border-color: #313244;
}

/* ── Inputs ──────────────────────────────────────────────── */
QLineEdit, QTextEdit, QPlainTextEdit {
    background-color: #181825;
    border: 1px solid #45475a;
    border-radius: 6px;
    padding: 7px 10px;
    color: #cdd6f4;
    selection-background-color: #cba6f7;
    selection-color: #1e1e2e;
}
QLineEdit:focus, QTextEdit:focus, QPlainTextEdit:focus {
    border-color: #cba6f7;
}
QLineEdit::placeholder { color: #6c7086; }

QSpinBox, QDoubleSpinBox, QComboBox {
    background-color: #181825;
    border: 1px solid #45475a;
    border-radius: 6px;
    padding: 6px 10px;
    color: #cdd6f4;
    min-height: 28px;
}
QSpinBox:focus, QComboBox:focus {
    border-color: #cba6f7;
}
QComboBox::drop-down {
    border: none;
    width: 24px;
}
QComboBox::down-arrow {
    image: none;
    border-left: 5px solid transparent;
    border-right: 5px solid transparent;
    border-top: 6px solid #cdd6f4;
    margin-right: 6px;
}
QComboBox QAbstractItemView {
    background-color: #181825;
    border: 1px solid #45475a;
    color: #cdd6f4;
    selection-background-color: #313244;
}

/* ── CheckBox ────────────────────────────────────────────── */
QCheckBox {
    color: #cdd6f4;
    spacing: 8px;
}
QCheckBox::indicator {
    width: 16px;
    height: 16px;
    border-radius: 4px;
    border: 1px solid #45475a;
    background-color: #181825;
}
QCheckBox::indicator:checked {
    background-color: #cba6f7;
    border-color: #cba6f7;
    image: none;
}
QCheckBox::indicator:hover {
    border-color: #cba6f7;
}

/* ── Labels ─────────────────────────────────────────────── */
QLabel#label_title {
    font-size: 22px;
    font-weight: 700;
    color: #cba6f7;
}
QLabel#label_section {
    font-size: 11px;
    font-weight: 600;
    color: #6c7086;
    letter-spacing: 1px;
}
QLabel#label_company {
    font-size: 14px;
    font-weight: 600;
    color: #89b4fa;
}

/* ── List / Table ────────────────────────────────────────── */
QListWidget {
    background-color: #181825;
    border: 1px solid #313244;
    border-radius: 6px;
    outline: none;
}
QListWidget::item {
    padding: 0;
    border-bottom: 1px solid #313244;
}
QListWidget::item:selected {
    background-color: #313244;
}
QListWidget::item:hover:!selected {
    background-color: #252536;
}

QTableWidget {
    background-color: #181825;
    gridline-color: #313244;
    border: 1px solid #313244;
    border-radius: 6px;
}
QTableWidget::item {
    padding: 8px;
}
QTableWidget::item:selected {
    background-color: #313244;
    color: #cdd6f4;
}
QHeaderView::section {
    background-color: #1e1e2e;
    color: #6c7086;
    padding: 8px;
    border: none;
    border-bottom: 1px solid #313244;
    font-weight: 600;
    font-size: 11px;
    letter-spacing: 0.5px;
}

/* ── ScrollBar ───────────────────────────────────────────── */
QScrollBar:vertical {
    background-color: #181825;
    width: 8px;
    border-radius: 4px;
}
QScrollBar::handle:vertical {
    background-color: #45475a;
    border-radius: 4px;
    min-height: 30px;
}
QScrollBar::handle:vertical:hover {
    background-color: #585b70;
}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
QScrollBar:horizontal {
    background-color: #181825;
    height: 8px;
    border-radius: 4px;
}
QScrollBar::handle:horizontal {
    background-color: #45475a;
    border-radius: 4px;
}
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal { width: 0; }

/* ── Splitter ─────────────────────────────────────────────── */
QSplitter::handle {
    background-color: #313244;
}
QSplitter::handle:hover {
    background-color: #cba6f7;
}
QSplitter::handle:horizontal { width: 3px; }
QSplitter::handle:vertical { height: 3px; }

/* ── GroupBox ─────────────────────────────────────────────── */
QGroupBox {
    border: 1px solid #313244;
    border-radius: 8px;
    margin-top: 16px;
    padding: 12px 8px 8px 8px;
    color: #a6adc8;
    font-weight: 600;
}
QGroupBox::title {
    subcontrol-origin: margin;
    left: 10px;
    top: -8px;
    padding: 2px 6px;
    background-color: #1e1e2e;
    color: #cba6f7;
    font-size: 11px;
    letter-spacing: 0.5px;
}

/* ── ToolBar ─────────────────────────────────────────────── */
QToolBar {
    background-color: #181825;
    border-bottom: 1px solid #313244;
    spacing: 6px;
    padding: 4px 8px;
}
QToolBar QLabel {
    color: #a6adc8;
    font-size: 12px;
}

/* ── StatusBar ───────────────────────────────────────────── */
QStatusBar {
    background-color: #181825;
    color: #6c7086;
    border-top: 1px solid #313244;
    font-size: 12px;
}

/* ── MenuBar ─────────────────────────────────────────────── */
QMenuBar {
    background-color: #181825;
    color: #cdd6f4;
    border-bottom: 1px solid #313244;
}
QMenuBar::item:selected {
    background-color: #313244;
    border-radius: 4px;
}
QMenu {
    background-color: #1e1e2e;
    border: 1px solid #45475a;
    border-radius: 6px;
    padding: 4px;
}
QMenu::item {
    padding: 6px 20px;
    border-radius: 4px;
}
QMenu::item:selected {
    background-color: #313244;
}
QMenu::separator {
    height: 1px;
    background-color: #313244;
    margin: 4px 0;
}

/* ── ProgressBar ─────────────────────────────────────────── */
QProgressBar {
    background-color: #313244;
    border-radius: 4px;
    height: 6px;
    text-align: center;
}
QProgressBar::chunk {
    background-color: #cba6f7;
    border-radius: 4px;
}

/* ── Frame panels ─────────────────────────────────────────── */
QFrame#panel_left {
    background-color: #181825;
    border-right: 1px solid #313244;
}
QFrame#panel_detail {
    background-color: #181825;
    border-left: 1px solid #313244;
}
"""

# Couleurs pour usage programmatique
COLORS = {
    "base":    "#1e1e2e",
    "mantle":  "#181825",
    "surface": "#313244",
    "overlay": "#45475a",
    "text":    "#cdd6f4",
    "subtext": "#6c7086",
    "purple":  "#cba6f7",
    "blue":    "#89b4fa",
    "green":   "#a6e3a1",
    "yellow":  "#f9e2af",
    "red":     "#f38ba8",
    "orange":  "#fab387",
    "teal":    "#94e2d5",
    "pink":    "#f5c2e7",
}

STATUS_COLORS = {
    "pending":   ("#f9e2af", "#1e1e2e"),
    "sent":      ("#89b4fa", "#1e1e2e"),
    "interview": ("#cba6f7", "#1e1e2e"),
    "rejected":  ("#f38ba8", "#1e1e2e"),
    "accepted":  ("#a6e3a1", "#1e1e2e"),
}

SOURCE_COLORS = {
    "France Travail":        "#89b4fa",
    "HelloWork":             "#a6e3a1",
    "Welcome to the Jungle": "#cba6f7",
    "APEC":                  "#74c7ec",
    "Meteojob":              "#94e2d5",
    "Jobup.ch":              "#f38ba8",
    "Jobs.ch":               "#fab387",
}
