"""
HelloWork — scraping HTML.
Liste : ul[aria-label="liste des offres"] > li
Détail : /fr-fr/emplois/{id}.html (fetchée à la demande via get_details)
"""
from typing import List, Optional
import re, json

import utils.logger as log
from models.models import Job
from scrapers.base_scraper import BaseScraper

BASE_URL   = "https://www.hellowork.com"
SEARCH_URL = f"{BASE_URL}/fr-fr/emploi/recherche.html"

CONTRACT_MAP = {
    "CDI": "CDI", "CDD": "CDD", "Stage": "stage",
    "Alternance": "alternance", "Intérim": "interim",
}


class HelloWorkScraper(BaseScraper):
    SOURCE_NAME = "HelloWork"

    def search(self, keywords, location, radius=30, contract_type="Tous", max_results=50):
        params = {"k": keywords, "ray": str(radius), "d": "all"}
        if location: params["l"] = location
        ct = CONTRACT_MAP.get(contract_type)
        if ct: params["c"] = ct
        self.session.headers["Referer"] = BASE_URL + "/"

        soup = self._soup(SEARCH_URL, params=params)
        if soup is None:
            return []

        ul = soup.select_one('ul[aria-label="liste des offres"]')
        if ul is None:
            log.warning("[HelloWork] Liste d'offres non trouvée dans la page")
            return []

        cards = ul.find_all("li", recursive=False)
        log.info(f"[HelloWork] {len(cards)} offres trouvées")
        jobs = [j for j in (self._parse(c) for c in cards[:max_results]) if j]
        log.info(f"[HelloWork] {len(jobs)} offres parsées")
        return jobs

    def _parse(self, li) -> Optional[Job]:
        try:
            offer_id = li.get("data-hide-offer-item-id-value", "")

            # Titre et entreprise depuis les inputs cachés (les plus fiables)
            title   = (li.select_one("input[name='title']")  or {}).get("value", "")
            company = self._clean_company(
                (li.select_one("input[name='company']") or {}).get("value", "")
            )
            if not title:
                return None

            # Lien vers le détail
            link_el = li.select_one("a[href*='/emplois/']")
            href    = link_el.get("href", "") if link_el else ""
            url     = href if href.startswith("http") else f"{BASE_URL}{href}"

            # Tags : [localité, contrat, salaire?, durée?]
            tags = [t.get_text(strip=True)
                    for t in li.select("[class*='tw-readonly'], [class*='tw-tag']")
                    if t.get_text(strip=True)]
            location = tags[0] if len(tags) > 0 else ""
            contract = tags[1] if len(tags) > 1 else ""
            salary   = tags[2] if len(tags) > 2 else ""

            # Date relative
            date_el  = li.select_one("[class*='tw-text-grey-500']")
            date_str = date_el.get_text(strip=True) if date_el else ""

            return Job(
                id=self._make_id("HelloWork", offer_id or url or title),
                title=title, company=company,
                location=location, contract_type=contract,
                salary=salary, posted_date=date_str,
                source="HelloWork", url=url,
            )
        except Exception as e:
            log.warning(f"[HelloWork] Card ignorée : {e}")
            return None

    # ── Détails ──────────────────────────────────────────────────────────────

    def get_details(self, job: Job) -> Job:
        """Récupère la description complète + infos détaillées de la page offre."""
        if not job.url:
            return job

        log.debug(f"[HelloWork] Détail → {job.url}")
        soup = self._soup(job.url)
        if soup is None:
            return job

        # 1) JSON-LD — source la plus structurée
        for script in soup.find_all("script", type="application/ld+json"):
            try:
                ld = json.loads(script.string or "")
                if isinstance(ld, list):
                    ld = next((x for x in ld if x.get("@type") == "JobPosting"), {})
                if ld.get("@type") == "JobPosting":
                    if not job.description and ld.get("description"):
                        raw = ld["description"]
                        # Nettoyer les balises HTML éventuelles
                        job.description = re.sub(r'<[^>]+>', '\n', raw).strip()
                    if not job.salary and ld.get("baseSalary"):
                        sal = ld["baseSalary"]
                        if isinstance(sal, dict):
                            val = sal.get("value", {})
                            mn  = val.get("minValue", "")
                            mx  = val.get("maxValue", "")
                            cur = sal.get("currency", "€")
                            if mn and mx: job.salary = f"{mn}–{mx} {cur}"
                            elif mn:     job.salary = f"à partir de {mn} {cur}"
                    if not job.contract_type and ld.get("employmentType"):
                        job.contract_type = ld["employmentType"]
                    if not job.location and ld.get("jobLocation"):
                        loc = ld["jobLocation"]
                        if isinstance(loc, dict):
                            addr = loc.get("address", {})
                            job.location = addr.get("addressLocality", "")
                    break
            except Exception:
                pass

        # 2) HTML si JSON-LD incomplet
        if not job.description:
            # HelloWork met la description dans un div avec class contenant 'description'
            for sel in [
                "[data-cy='jobDescription']",
                ".job-description",
                "[class*='description']",
                "article",
                "section[class*='content']",
            ]:
                el = soup.select_one(sel)
                if el and len(el.get_text(strip=True)) > 100:
                    job.description = self._clean(el.get_text(separator="\n"))
                    break

        # 3) Infos complémentaires (critères, profil, etc.)
        extras = []
        for section in soup.select("section, [class*='criteria'], [class*='info-block']"):
            heading = section.select_one("h2, h3, [class*='title']")
            if heading:
                h_text = heading.get_text(strip=True)
                # Éviter de dupliquer la description principale
                if any(w in h_text.lower() for w in ["description", "mission", "poste"]):
                    continue
                body = section.get_text(separator="\n", strip=True)
                if len(body) > 20:
                    extras.append(f"## {h_text}\n{body}")
        if extras and job.description:
            job.description = job.description + "\n\n" + "\n\n".join(extras[:3])

        # 4) Expérience, télétravail
        page_text = soup.get_text()
        if not job.experience:
            m = re.search(r'(\d+\s*(?:an|année|ans)[^.]{0,30})', page_text, re.I)
            if m: job.experience = m.group(1).strip()

        log.debug(f"[HelloWork] Détail chargé, description: {len(job.description or '')} chars")
        return job
