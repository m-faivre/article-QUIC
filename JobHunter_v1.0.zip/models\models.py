import json
from dataclasses import dataclass, field
from typing import Optional, List, Dict


@dataclass
class Job:
    id: str
    title: str
    company: str
    location: str
    contract_type: str
    source: str
    url: str
    description: str = ""
    salary: str = ""
    experience: str = ""
    posted_date: str = ""
    company_info: Dict = field(default_factory=dict)
    tags: List[str] = field(default_factory=list)

    def to_db_dict(self) -> dict:
        return {
            "id": self.id,
            "title": self.title,
            "company": self.company,
            "location": self.location,
            "contract_type": self.contract_type,
            "source": self.source,
            "url": self.url,
            "description": self.description,
            "salary": self.salary,
            "posted_date": self.posted_date,
            "company_info": json.dumps(self.company_info, ensure_ascii=False),
            "tags": json.dumps(self.tags, ensure_ascii=False),
        }

    @classmethod
    def from_db_row(cls, row) -> "Job":
        d = dict(row)
        return cls(
            id=d["id"],
            title=d["title"],
            company=d["company"],
            location=d["location"],
            contract_type=d["contract_type"],
            source=d["source"],
            url=d["url"],
            description=d.get("description", ""),
            salary=d.get("salary", ""),
            posted_date=d.get("posted_date", ""),
            company_info=json.loads(d.get("company_info") or "{}"),
            tags=json.loads(d.get("tags") or "[]"),
        )


@dataclass
class SearchTemplate:
    name: str
    keywords: str
    location: str
    radius: int
    contract_types: List[str]
    sources: List[str]
    id: Optional[int] = None
    created_at: str = ""

    def to_db_dict(self) -> dict:
        return {
            "name": self.name,
            "keywords": self.keywords,
            "location": self.location,
            "radius": self.radius,
            "contract_types": json.dumps(self.contract_types, ensure_ascii=False),
            "sources": json.dumps(self.sources, ensure_ascii=False),
        }

    @classmethod
    def from_db_row(cls, row) -> "SearchTemplate":
        d = dict(row)
        return cls(
            id=d["id"],
            name=d["name"],
            keywords=d["keywords"],
            location=d["location"],
            radius=d["radius"],
            contract_types=json.loads(d.get("contract_types") or "[]"),
            sources=json.loads(d.get("sources") or "[]"),
            created_at=d.get("created_at", ""),
        )


@dataclass
class SwissSearchTemplate:
    name: str
    keywords: str
    max_border_minutes: int
    id: Optional[int] = None
    created_at: str = ""

    def to_db_dict(self) -> dict:
        return {
            "name": self.name,
            "keywords": self.keywords,
            "max_border_minutes": self.max_border_minutes,
        }

    @classmethod
    def from_db_row(cls, row) -> "SwissSearchTemplate":
        d = dict(row)
        return cls(
            id=d["id"],
            name=d["name"],
            keywords=d["keywords"],
            max_border_minutes=d["max_border_minutes"],
            created_at=d.get("created_at", ""),
        )


@dataclass
class Application:
    job_id: str
    job_title: str
    company: str
    source: str
    status: str = "pending"
    cv_path: str = ""
    cover_letter_path: str = ""
    notes: str = ""
    job_url: str = ""
    location: str = ""
    contact: str = ""
    id: Optional[int] = None
    sent_at: str = ""
    updated_at: str = ""

    def to_db_dict(self) -> dict:
        return {
            "job_id": self.job_id,
            "job_title": self.job_title,
            "company": self.company,
            "source": self.source,
            "status": self.status,
            "cv_path": self.cv_path,
            "cover_letter_path": self.cover_letter_path,
            "notes": self.notes,
            "job_url": self.job_url,
            "location": self.location,
            "contact": self.contact,
            "sent_at": self.sent_at,
        }

    @classmethod
    def from_db_row(cls, row) -> "Application":
        d = dict(row)
        return cls(
            id=d["id"],
            job_id=d["job_id"],
            job_title=d["job_title"],
            company=d["company"],
            source=d["source"],
            status=d["status"],
            cv_path=d.get("cv_path", ""),
            cover_letter_path=d.get("cover_letter_path", ""),
            notes=d.get("notes", ""),
            job_url=d.get("job_url", ""),
            location=d.get("location", ""),
            contact=d.get("contact", ""),
            sent_at=d.get("sent_at", ""),
            updated_at=d.get("updated_at", ""),
        )
