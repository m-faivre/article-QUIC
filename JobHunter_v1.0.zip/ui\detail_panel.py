"""
Panneau de détail d'une offre (colonne droite).
Affiche titre, entreprise, métadonnées, distance routière domicile→poste,
description complète, et boutons d'action.
"""
import webbrowser

from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QColor, QFont
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QScrollArea, QFrame, QTextBrowser, QSizePolicy, QProgressBar
)

from models.models import Job
from ui.styles import COLORS, SOURCE_COLORS


def _format_date_fr(date_str: str) -> str:
    """Convertit YYYY-MM-DD → JJ/MM/AAAA. Passe le reste tel quel."""
    if not date_str:
        return date_str
    s = date_str.strip()
    if len(s) == 10 and s[4] == "-":
        parts = s.split("-")
        return f"{parts[2]}/{parts[1]}/{parts[0]}"
    return s


class DetailPanel(QWidget):
    save_job_requested = pyqtSignal(object)   # Job
    quick_tag_requested = pyqtSignal(object)  # Job — tag rapide "postulé"
    distance_clicked = pyqtSignal(str, str)   # (french_town, job_location) → carte

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("panel_detail")
        self._current_job: Job | None = None
        self._build_ui()
        self._show_placeholder()

    # ─── Build ────────────────────────────────────────────────────────────────

    def _build_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        # ── Header ──
        self._header = QWidget()
        self._header.setStyleSheet("background-color:#181825; border-bottom:1px solid #313244;")
        h_lay = QVBoxLayout(self._header)
        h_lay.setContentsMargins(16, 12, 16, 12)
        h_lay.setSpacing(4)

        self.lbl_title = QLabel("—")
        self.lbl_title.setObjectName("label_title")
        self.lbl_title.setWordWrap(True)
        self.lbl_title.setStyleSheet("font-size:18px; font-weight:700; color:#cdd6f4;")
        h_lay.addWidget(self.lbl_title)

        self.lbl_company = QLabel("")
        self.lbl_company.setStyleSheet("font-size:13px; font-weight:600; color:#89b4fa;")
        h_lay.addWidget(self.lbl_company)

        self.lbl_meta = QLabel("")
        self.lbl_meta.setStyleSheet("font-size:11px; color:#6c7086;")
        h_lay.addWidget(self.lbl_meta)

        # Badge source
        self.lbl_source = QLabel("")
        self.lbl_source.setStyleSheet("font-size:10px; font-weight:700; padding:2px 8px; border-radius:10px;")
        self.lbl_source.setFixedHeight(20)
        h_lay.addWidget(self.lbl_source, 0, Qt.AlignmentFlag.AlignLeft)

        main_layout.addWidget(self._header)

        # ── Barre de progression (chargement détails + distance) ──
        self.progress = QProgressBar()
        self.progress.setRange(0, 0)
        self.progress.setFixedHeight(3)
        self.progress.setVisible(False)
        self.progress.setStyleSheet("QProgressBar::chunk { background:#cba6f7; }")
        main_layout.addWidget(self.progress)

        # ── Corps scrollable ──
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        body = QWidget()
        self._body_layout = QVBoxLayout(body)
        self._body_layout.setContentsMargins(16, 16, 16, 16)
        self._body_layout.setSpacing(12)
        scroll.setWidget(body)
        main_layout.addWidget(scroll, 1)

        # ── Widget distance (cliquable → carte) ────────────────
        self._dist_frame = QFrame()
        self._dist_frame.setStyleSheet(
            "QFrame { background:#1e3a2e; border:1px solid #2d5a3d; border-radius:8px; }"
        )
        self._dist_frame.setCursor(Qt.CursorShape.PointingHandCursor)
        dist_lay = QHBoxLayout(self._dist_frame)
        dist_lay.setContentsMargins(12, 8, 12, 8)
        self.lbl_distance = QLabel("🚗  Calcul de la distance…")
        self.lbl_distance.setStyleSheet("color:#a6e3a1; font-size:12px; font-weight:600;")
        dist_lay.addWidget(self.lbl_distance)
        dist_lay.addStretch()
        lbl_hint = QLabel("🗺️")
        lbl_hint.setStyleSheet("color:#6c7086; font-size:12px;")
        lbl_hint.setToolTip("Voir sur la carte")
        dist_lay.addWidget(lbl_hint)
        self._dist_frame.setVisible(False)
        self._dist_french_town = ""
        self._dist_job_location = ""
        self._dist_frame.mousePressEvent = lambda e: self._on_distance_clicked()
        self._body_layout.addWidget(self._dist_frame)

        # ── Entreprise ──
        company_frame = QFrame()
        company_frame.setStyleSheet("QFrame { background:#252536; border-radius:8px; }")
        c_lay = QVBoxLayout(company_frame)
        c_lay.setContentsMargins(12, 10, 12, 10)
        c_lay.setSpacing(6)
        c_lay.addWidget(self._section_label("À PROPOS DE L'ENTREPRISE"))
        self.lbl_company_info = QLabel("—")
        self.lbl_company_info.setWordWrap(True)
        self.lbl_company_info.setStyleSheet("color:#a6adc8; font-size:12px;")
        c_lay.addWidget(self.lbl_company_info)
        self._body_layout.addWidget(company_frame)

        # ── Description ──
        self._body_layout.addWidget(self._section_label("DESCRIPTION DU POSTE"))
        self.text_description = QTextBrowser()
        self.text_description.setOpenExternalLinks(True)
        self.text_description.setStyleSheet(
            "QTextBrowser { background:#181825; border:1px solid #313244; "
            "border-radius:8px; padding:12px; color:#cdd6f4; font-size:13px; }"
        )
        self.text_description.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self._body_layout.addWidget(self.text_description, 1)
        self._body_layout.addStretch()

        # ── Boutons d'action ──
        btn_bar = QWidget()
        btn_bar.setStyleSheet("background-color:#181825; border-top:1px solid #313244;")
        b_lay = QHBoxLayout(btn_bar)
        b_lay.setContentsMargins(12, 8, 12, 8)
        b_lay.setSpacing(8)

        self.btn_tag = QPushButton("🏷️  Marquer postulé")
        self.btn_tag.setMinimumHeight(36)
        self.btn_tag.setEnabled(False)
        self.btn_tag.setToolTip("Marquer cette offre comme 'postulé'")
        self.btn_tag.clicked.connect(self._on_quick_tag)
        b_lay.addWidget(self.btn_tag, 1)

        self.btn_open = QPushButton("🌐  Ouvrir")
        self.btn_open.setMinimumHeight(36)
        self.btn_open.setEnabled(False)
        self.btn_open.clicked.connect(self._on_open)
        b_lay.addWidget(self.btn_open, 1)

        self.btn_save = QPushButton("⭐  Sauvegarder")
        self.btn_save.setMinimumHeight(36)
        self.btn_save.setEnabled(False)
        self.btn_save.clicked.connect(self._on_save)
        b_lay.addWidget(self.btn_save, 1)

        main_layout.addWidget(btn_bar)

    # ─── Public API ───────────────────────────────────────────────────────────

    def show_job(self, job: Job) -> None:
        self._current_job = job
        self.lbl_title.setText(job.title or "—")
        self.lbl_company.setText(job.company or "Entreprise inconnue")

        meta_parts = []
        if job.location:      meta_parts.append(f"📍 {job.location}")
        if job.contract_type: meta_parts.append(f"📋 {job.contract_type}")
        if job.salary:        meta_parts.append(f"💰 {job.salary}")
        if job.posted_date:   meta_parts.append(f"📅 {_format_date_fr(job.posted_date)}")
        self.lbl_meta.setText("   ·   ".join(meta_parts))

        src_color = SOURCE_COLORS.get(job.source, "#cba6f7")
        self.lbl_source.setText(f"  {job.source}  ")
        self.lbl_source.setStyleSheet(
            f"font-size:10px; font-weight:700; padding:2px 10px; border-radius:10px;"
            f"background-color:{src_color}; color:#1e1e2e;"
        )

        # Entreprise
        ci = job.company_info if isinstance(job.company_info, dict) else {}
        info_parts = []
        if ci.get("name"):        info_parts.append(ci["name"])
        if ci.get("description"): info_parts.append(ci["description"][:300])
        if ci.get("url"):         info_parts.append(f"🔗 {ci['url']}")
        self.lbl_company_info.setText("\n".join(info_parts) if info_parts else "Informations non disponibles")

        # Description
        self.text_description.setPlainText(job.description or "Chargement de la description…")

        # Distance : indiquer calcul en cours si domicile configuré
        import database.db_manager as db
        if db.get_setting("home_lat") and job.location:
            self._dist_frame.setVisible(True)
            self.lbl_distance.setText("🚗  Calcul de la distance…")
            self.lbl_distance.setStyleSheet("color:#6c7086; font-size:12px;")
            self._dist_frame.setStyleSheet(
                "QFrame { background:#252536; border:1px solid #45475a; border-radius:8px; }"
            )
        else:
            self._dist_frame.setVisible(False)

        self.btn_open.setEnabled(bool(job.url))
        self.btn_save.setEnabled(True)
        self._update_tag_button(job)

    def show_loading(self, loading: bool) -> None:
        self.progress.setVisible(loading)

    def update_description(self, job: Job) -> None:
        if self._current_job and self._current_job.id == job.id:
            self._current_job = job
            self.text_description.setPlainText(job.description or "Aucune description disponible.")
            ci = job.company_info if isinstance(job.company_info, dict) else {}
            info_parts = []
            if ci.get("name"):        info_parts.append(ci["name"])
            if ci.get("description"): info_parts.append(ci["description"][:400])
            if ci.get("url"):         info_parts.append(f"🔗 {ci['url']}")
            self.lbl_company_info.setText(
                "\n".join(info_parts) if info_parts else "Informations non disponibles"
            )

    def update_distance(self, job: Job, result: dict | None) -> None:
        """Appelé par DistanceWorker quand le calcul est terminé."""
        if self._current_job and self._current_job.id == job.id:
            if result:
                self.lbl_distance.setText(result["label"])
                self.lbl_distance.setStyleSheet("color:#a6e3a1; font-size:12px; font-weight:600;")
                self._dist_frame.setStyleSheet(
                    "QFrame { background:#1e3a2e; border:1px solid #2d5a3d; border-radius:8px; }"
                )
                self._dist_frame.setVisible(True)
                # Stocker pour le clic → carte
                self._dist_french_town = result.get("french_town", "")
                self._dist_job_location = job.location or ""
            else:
                self._dist_frame.setVisible(False)

    def _on_distance_clicked(self):
        """Émet le signal pour ouvrir la carte avec les lieux pré-remplis."""
        if self._dist_french_town and self._dist_job_location:
            self.distance_clicked.emit(self._dist_french_town, self._dist_job_location)

    # ─── Slots ────────────────────────────────────────────────────────────────

    def _on_open(self):
        if self._current_job and self._current_job.url:
            webbrowser.open(self._current_job.url)

    def _on_save(self):
        if self._current_job: self.save_job_requested.emit(self._current_job)

    # ─── Helpers ─────────────────────────────────────────────────────────────

    def _update_tag_button(self, job: Job) -> None:
        """Met à jour l'apparence du bouton tag selon le statut postulé."""
        try:
            import database.db_manager as db
            applied = job.id in db.get_applied_job_ids()
        except Exception:
            applied = False
        self.btn_tag.setEnabled(True)
        if applied:
            self.btn_tag.setText("✅  Postulé")
            self.btn_tag.setStyleSheet(
                "QPushButton { background:#1e3a2e; color:#a6e3a1; border:1px solid #2d5a3d; "
                "border-radius:6px; font-size:12px; }"
                "QPushButton:hover { background:#2d5a3d; }"
            )
            self.btn_tag.setToolTip("Vous avez postulé à cette offre. Clic pour retirer le tag.")
            self.btn_tag.setProperty("applied", True)
        else:
            self.btn_tag.setText("🏷️  Marquer postulé")
            self.btn_tag.setStyleSheet("")
            self.btn_tag.setToolTip("Tager cette offre comme postulé sans envoyer de candidature")
            self.btn_tag.setProperty("applied", False)

    def _on_quick_tag(self) -> None:
        if self._current_job:
            self.quick_tag_requested.emit(self._current_job)

    def refresh_tag_status(self, job: Job) -> None:
        """Appelé depuis main_window pour rafraîchir le bouton après tag/untag."""
        if self._current_job and self._current_job.id == job.id:
            self._update_tag_button(job)

    def _show_placeholder(self):
        self.lbl_title.setText("Sélectionnez une offre")
        self.lbl_company.setText("")
        self.lbl_meta.setText("")
        self.lbl_source.setText("")
        self.lbl_company_info.setText("—")
        self._dist_frame.setVisible(False)
        self.btn_tag.setEnabled(False)
        self.btn_tag.setText("🏷️  Marquer postulé")
        self.btn_tag.setStyleSheet("")
        self.text_description.setPlainText(
            "Cliquez sur une offre dans la liste pour afficher ses détails ici."
        )

    @staticmethod
    def _section_label(text: str) -> QLabel:
        lbl = QLabel(text)
        lbl.setStyleSheet("font-size:10px; font-weight:700; color:#6c7086; letter-spacing:1px;")
        return lbl
