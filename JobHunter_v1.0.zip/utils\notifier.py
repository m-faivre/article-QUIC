"""
Notifications Windows — toast via winotify.
Fallback silencieux si winotify n'est pas installé.
"""
import utils.logger as log


def notify_toast(title: str, message: str) -> None:
    """Affiche une notification Windows (toast).

    Utilise winotify (léger, sans COM).
    Si winotify n'est pas installé, log un warning et continue.
    """
    try:
        from winotify import Notification, audio

        toast = Notification(
            app_id="JobHunter",
            title=title,
            msg=message,
            duration="short",
        )
        toast.set_audio(audio.Default, loop=False)
        toast.show()
        log.debug(f"[Toast] {title} — {message}")
    except ImportError:
        log.warning(
            "[Toast] winotify non installé — pip install winotify "
            "pour activer les notifications Windows."
        )
    except Exception as e:
        log.debug(f"[Toast] Erreur notification : {e}")
