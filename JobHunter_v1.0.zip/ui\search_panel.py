"""
Panneau de recherche (colonne gauche).
Autocomplétion du champ Localisation via le référentiel INSEE local.
"""
from PyQt6.QtCore import pyqtSignal, Qt, QStringListModel, QTimer
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QComboBox, QSpinBox, QCheckBox, QPushButton, QGroupBox,
    QScrollArea, QFrame, QCompleter, QListView
)

from config import CONTRACT_TYPES, SOURCES
from models.models import SearchTemplate
from ui.styles import SOURCE_COLORS
from utils.communes import search as commune_search, get_display_name


class SearchPanel(QWidget):
    search_requested         = pyqtSignal(dict)
    template_save_requested  = pyqtSignal(dict)
    template_load_requested  = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("panel_left")
        self.setFixedWidth(280)
        self._build_ui()

    def _build_ui(self):
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)

        container = QWidget()
        layout = QVBoxLayout(container)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(12)

        title = QLabel("🔍  Recherche")
        title.setStyleSheet("font-size:15px; font-weight:700; color:#cba6f7; padding:4px 0;")
        layout.addWidget(title)

        # ── Mots-clés ──
        layout.addWidget(self._section_label("MOTS-CLÉS"))
        self.input_keywords = QLineEdit()
        self.input_keywords.setPlaceholderText("Développeur Python, Chef de projet…")
        self.input_keywords.returnPressed.connect(self._on_search)
        layout.addWidget(self.input_keywords)

        # ── Localisation + autocomplétion ──
        layout.addWidget(self._section_label("LOCALISATION"))
        self.input_location = QLineEdit()
        self.input_location.setPlaceholderText("Bourg-en-Bresse, Lyon, Paris…")
        self.input_location.returnPressed.connect(self._on_search)
        layout.addWidget(self.input_location)

        # Completer en mode "non filtré" : on gère nous-mêmes le contenu du modèle
        self._completer_model = QStringListModel()
        self._completer = QCompleter(self)
        self._completer.setModel(self._completer_model)
        self._completer.setCompletionMode(QCompleter.CompletionMode.UnfilteredPopupCompletion)
        self._completer.setMaxVisibleItems(10)
        popup = self._completer.popup()
        popup.setStyleSheet(
            "QListView { background:#1e1e2e; color:#cdd6f4; border:1px solid #45475a;"
            "  border-radius:6px; padding:4px; font-size:12px; }"
            "QListView::item { padding:4px 8px; border-radius:4px; }"
            "QListView::item:selected { background:#313244; color:#cba6f7; }"
        )
        self.input_location.setCompleter(self._completer)

        # Timer : mise à jour 200 ms après la dernière frappe
        self._complete_timer = QTimer(self)
        self._complete_timer.setSingleShot(True)
        self._complete_timer.setInterval(200)
        self._complete_timer.timeout.connect(self._update_completions)
        self.input_location.textChanged.connect(self._on_location_text_changed)

        # Quand l'utilisateur clique sur une suggestion → retirer "(01)"
        self._completer.activated.connect(self._on_completion_selected)

        # ── Rayon ──
        radius_row = QHBoxLayout()
        radius_label = QLabel("Rayon :")
        radius_label.setStyleSheet("color:#a6adc8;")
        self.spin_radius = QSpinBox()
        self.spin_radius.setRange(0, 500)
        self.spin_radius.setValue(30)
        self.spin_radius.setSuffix(" km")
        self.spin_radius.setFixedWidth(120)
        radius_row.addWidget(radius_label)
        radius_row.addStretch()
        radius_row.addWidget(self.spin_radius)
        layout.addLayout(radius_row)

        # ── Type de contrat ──
        layout.addWidget(self._section_label("TYPE DE CONTRAT"))
        self.combo_contract = QComboBox()
        self.combo_contract.addItems(CONTRACT_TYPES)
        layout.addWidget(self.combo_contract)

        # ── Sources ──
        src_group = QGroupBox("Sources")
        src_layout = QVBoxLayout(src_group)
        src_layout.setSpacing(4)
        btn_row = QHBoxLayout()
        btn_all  = QPushButton("Tout")
        btn_none = QPushButton("Rien")
        btn_all.setFixedHeight(22);  btn_none.setFixedHeight(22)
        btn_all.setStyleSheet("font-size:10px; padding:0 6px;")
        btn_none.setStyleSheet("font-size:10px; padding:0 6px;")
        btn_all.clicked.connect(lambda:  [cb.setChecked(True)  for cb in self._source_checks.values()])
        btn_none.clicked.connect(lambda: [cb.setChecked(False) for cb in self._source_checks.values()])
        btn_row.addWidget(btn_all); btn_row.addWidget(btn_none); btn_row.addStretch()
        src_layout.addLayout(btn_row)
        self._source_checks = {}
        for src in SOURCES:
            cb = QCheckBox(src); cb.setChecked(True)
            color = SOURCE_COLORS.get(src, "#cdd6f4")
            cb.setStyleSheet(f"QCheckBox::indicator:checked {{ background-color:{color}; border-color:{color}; }}")
            self._source_checks[src] = cb
            src_layout.addWidget(cb)
        layout.addWidget(src_group)

        # ── Bouton Rechercher ──
        self.btn_search = QPushButton("🔍  Lancer la recherche")
        self.btn_search.setObjectName("btn_primary")
        self.btn_search.setMinimumHeight(38)
        self.btn_search.clicked.connect(self._on_search)
        layout.addWidget(self.btn_search)

        # ── Templates ──
        tpl_group = QGroupBox("Templates")
        tpl_layout = QVBoxLayout(tpl_group)
        tpl_layout.setSpacing(6)
        self.btn_save_tpl = QPushButton("💾  Sauvegarder ce template")
        self.btn_save_tpl.clicked.connect(lambda: self.template_save_requested.emit(self.get_params()))
        tpl_layout.addWidget(self.btn_save_tpl)
        self.btn_load_tpl = QPushButton("📂  Charger un template")
        self.btn_load_tpl.clicked.connect(self.template_load_requested)
        tpl_layout.addWidget(self.btn_load_tpl)
        layout.addWidget(tpl_group)

        layout.addStretch()
        scroll.setWidget(container)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.addWidget(scroll)

    # ─── Autocomplétion ───────────────────────────────────────────────────────

    def _on_location_text_changed(self, text: str):
        """Démarre le timer, ou vide la liste si texte trop court."""
        if len(text) < 2:
            self._completer_model.setStringList([])
            return
        self._complete_timer.start()

    def _update_completions(self):
        """Interroge le référentiel INSEE et force l'affichage du popup."""
        query = self.input_location.text()
        if len(query) < 2:
            return
        results = commune_search(query, limit=10)
        labels  = [r.label() for r in results]
        self._completer_model.setStringList(labels)
        if labels:
            self._completer.complete()   # ← force l'ouverture du popup

    def _on_completion_selected(self, text: str):
        """'Bourg-en-Bresse (01)' → 'Bourg-en-Bresse' dans le champ."""
        name = text.split(" (")[0]
        self.input_location.blockSignals(True)
        self.input_location.setText(name)
        self.input_location.blockSignals(False)
        self._completer_model.setStringList([])

    # ─── Helpers ─────────────────────────────────────────────────────────────

    @staticmethod
    def _section_label(text: str) -> QLabel:
        lbl = QLabel(text)
        lbl.setObjectName("label_section")
        lbl.setStyleSheet("font-size:10px; font-weight:700; color:#6c7086; letter-spacing:1px; margin-top:4px;")
        return lbl

    # ─── Public API ───────────────────────────────────────────────────────────

    def get_params(self) -> dict:
        return {
            "keywords":      self.input_keywords.text().strip(),
            "location":      self.input_location.text().strip(),
            "radius":        self.spin_radius.value(),
            "contract_type": self.combo_contract.currentText(),
            "sources":       [s for s, cb in self._source_checks.items() if cb.isChecked()],
        }

    def load_template(self, tpl: SearchTemplate) -> None:
        self.input_keywords.setText(tpl.keywords)
        self.input_location.setText(tpl.location)
        self.spin_radius.setValue(tpl.radius)
        idx = self.combo_contract.findText(tpl.contract_types[0] if tpl.contract_types else "Tous")
        if idx >= 0:
            self.combo_contract.setCurrentIndex(idx)
        for src, cb in self._source_checks.items():
            cb.setChecked(src in tpl.sources if tpl.sources else True)

    def set_searching(self, searching: bool) -> None:
        self.btn_search.setEnabled(not searching)
        self.btn_search.setText("⏳  Recherche en cours…" if searching else "🔍  Lancer la recherche")

    # ─── Slots ────────────────────────────────────────────────────────────────

    def _on_search(self):
        # Normaliser le nom de ville (accentuation + tirets officiels)
        raw = self.input_location.text().strip()
        official = get_display_name(raw)
        if official and official != raw:
            self.input_location.blockSignals(True)
            self.input_location.setText(official)
            self.input_location.blockSignals(False)
        self.search_requested.emit(self.get_params())
