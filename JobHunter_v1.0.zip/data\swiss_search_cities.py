"""
Villes suisses frontalières utilisées pour cibler les recherches Jobup/Jobs.ch.

L'API JobCloud résout le nom de ville en « geo-shapes » (canton/district).
On utilise une ville par zone géographique pour couvrir l'ensemble de la
frontière franco-suisse, sans doublons inutiles.

Chaque entrée : (nom_ville, label_région)
  - nom_ville : valeur envoyée à l'API (paramètre location=)
  - label_région : texte affiché dans l'interface (checkbox)
"""

SWISS_BORDER_CITIES = [
    ("Genève",           "Genève"),
    ("Nyon",             "Nyon · Morges (Vaud ouest)"),
    ("Lausanne",         "Lausanne (Vaud centre)"),
    ("Vevey",            "Vevey · Riviera (Vaud est)"),
    ("Yverdon-les-Bains", "Yverdon (Vaud nord)"),
    ("Neuchâtel",        "Neuchâtel"),
    ("Delémont",         "Jura · Delémont"),
    ("Biel/Bienne",      "Bienne (Berne)"),
    ("Basel",            "Bâle"),
]

# Raccourci : liste des noms uniquement (rétrocompatibilité)
SWISS_BORDER_CITY_NAMES = [city for city, _ in SWISS_BORDER_CITIES]
