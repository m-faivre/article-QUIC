"""
Panneau des résultats — liste d'offres avec cards personnalisées.

Marquages visuels :
  - Doublon  : bordure gauche orange, icône 🔁, fond violet sombre
  - Postulé  : bordure gauche verte,  icône ✅, fond vert sombre

Filtres header :
  - Bouton "Doublons"       : affiche/masque les doublons
  - Bouton "Masquer postulées" : masque les offres où l'on a déjà postulé
"""
from PyQt6.QtCore import Qt, pyqtSignal, QSize, QRect, QPoint
from PyQt6.QtGui import QPainter, QColor, QFont, QPen, QFontMetrics
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QListWidget,
    QListWidgetItem, QAbstractItemView, QStyledItemDelegate,
    QStyleOptionViewItem, QComboBox, QLineEdit, QFrame, QPushButton
)

from models.models import Job
from ui.styles import COLORS, SOURCE_COLORS
from utils.deduplicator import deduplicate


def _format_date_fr(date_str: str) -> str:
    """Convertit YYYY-MM-DD → JJ/MM/AAAA."""
    if not date_str:
        return date_str
    s = date_str.strip()
    if len(s) == 10 and s[4] == "-":
        parts = s.split("-")
        return f"{parts[2]}/{parts[1]}/{parts[0]}"
    return s

_ROLE_JOB     = Qt.ItemDataRole.UserRole
_ROLE_IS_DUP  = Qt.ItemDataRole.UserRole + 1
_ROLE_APPLIED = Qt.ItemDataRole.UserRole + 2
_ROLE_HIDDEN  = Qt.ItemDataRole.UserRole + 3


# ─── Custom delegate ─────────────────────────────────────────────────────────

class JobCardDelegate(QStyledItemDelegate):
    CARD_HEIGHT = 88

    def sizeHint(self, option, index) -> QSize:
        return QSize(option.rect.width(), self.CARD_HEIGHT)

    def paint(self, painter: QPainter, option: QStyleOptionViewItem, index):
        job: Job = index.data(_ROLE_JOB)
        if job is None:
            return

        is_dup     = bool(index.data(_ROLE_IS_DUP))
        is_applied = bool(index.data(_ROLE_APPLIED))
        is_hidden  = bool(index.data(_ROLE_HIDDEN))
        selected   = bool(option.state & option.state.State_Selected)
        hovered    = bool(option.state & option.state.State_MouseOver)

        painter.save()
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        rect = option.rect.adjusted(6, 4, -6, -4)

        # ── Background ──
        if is_hidden:
            bg = QColor("#252536" if selected else ("#1f1f30" if hovered else "#181825"))
        elif is_applied:
            bg = QColor("#1e2e26" if selected else ("#1d2922" if hovered else "#191f1b"))
        elif is_dup:
            bg = QColor("#2a1f2e" if selected else ("#252030" if hovered else "#1e1a22"))
        else:
            bg = QColor("#313244" if selected else ("#252536" if hovered else "#1e1e2e"))
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(bg)
        painter.drawRoundedRect(rect, 8, 8)

        # ── Bordure gauche ──
        if is_hidden:
            border_color = QColor("#585b70")  # gris
        elif is_applied:
            border_color = QColor("#a6e3a1")  # vert
        elif is_dup:
            border_color = QColor("#f9e2af")  # orange
        else:
            border_color = None

        if border_color:
            painter.setBrush(border_color)
            painter.drawRoundedRect(QRect(rect.left(), rect.top(), 3, rect.height()), 2, 2)

        # ── Source badge (barre droite) ──
        src_color = QColor(SOURCE_COLORS.get(job.source, "#cba6f7"))
        if is_dup: src_color = src_color.darker(160)
        badge_rect = QRect(rect.right() - 10, rect.top() + 4, 8, rect.height() - 8)
        painter.setBrush(src_color)
        painter.drawRoundedRect(badge_rect, 3, 3)

        text_rect = rect.adjusted(14, 8, -24, -8)

        # ── Titre ──
        font_title = QFont("Segoe UI", 12, QFont.Weight.DemiBold)
        painter.setFont(font_title)
        if is_hidden:
            title_color = QColor("#585b70")
        elif is_applied:
            title_color = QColor("#a6e3a1")
        elif is_dup:
            title_color = QColor("#a6adc8")
        else:
            title_color = QColor("#cdd6f4")
        painter.setPen(title_color)

        prefix = "🙈 " if is_hidden else ("✅ " if is_applied else ("🔁 " if is_dup else ""))
        fm = QFontMetrics(font_title)
        title_text = fm.elidedText(prefix + job.title, Qt.TextElideMode.ElideRight, text_rect.width())
        painter.drawText(text_rect, Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignLeft, title_text)

        # ── Entreprise + lieu ──
        font_sub = QFont("Segoe UI", 10)
        painter.setFont(font_sub)
        painter.setPen(QColor("#45475a" if is_hidden else ("#6c7086" if is_dup else "#89b4fa")))
        company_line = job.company
        if job.location:
            company_line += f"  ·  {job.location}"
        fm_sub = QFontMetrics(font_sub)
        painter.drawText(
            text_rect.adjusted(0, 24, 0, 0),
            Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignLeft,
            fm_sub.elidedText(company_line, Qt.TextElideMode.ElideRight, text_rect.width()),
        )

        # ── Tags ──
        font_tag = QFont("Segoe UI", 9)
        painter.setFont(font_tag)
        painter.setPen(QColor("#313244" if is_hidden else ("#45475a" if is_dup else "#6c7086")))
        tags = []
        if job.contract_type: tags.append(job.contract_type)
        if job.salary:        tags.append(f"💰 {job.salary}")
        if job.posted_date:   tags.append(f"📅 {_format_date_fr(job.posted_date)}")
        if is_hidden:         tags.append("masquée")
        elif is_applied:      tags.append("postulé ✅")
        elif is_dup:          tags.append("doublon")
        fm_tag = QFontMetrics(font_tag)
        painter.drawText(
            text_rect.adjusted(0, 46, 0, 0),
            Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignLeft,
            fm_tag.elidedText("   ".join(tags), Qt.TextElideMode.ElideRight, text_rect.width()),
        )

        painter.restore()


# ─── Results panel ────────────────────────────────────────────────────────────

class ResultsPanel(QWidget):
    job_selected       = pyqtSignal(object)
    save_job_requested = pyqtSignal(object)
    application_changed = pyqtSignal(object)  # Job — tag ajouté/retiré, édition

    def __init__(self, parent=None):
        super().__init__(parent)
        self._jobs: list[Job]       = []
        self._unique: list[Job]     = []
        self._duplicates: list[Job] = []
        self._unique_object_ids: set[int] = set()
        self._applied_ids: set[str] = set()   # job.id des offres où l'on a postulé
        self._hidden_ids: set[str]  = set()   # job.id des offres masquées
        self._show_duplicates: bool = False
        self._show_applied: bool    = False   # masquées par défaut
        self._show_hidden: bool     = False
        self._build_ui()
        self._reload_applied()
        self._reload_hidden()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # ── Header ──
        header = QWidget()
        header.setFixedHeight(44)
        header.setStyleSheet("background-color:#181825; border-bottom:1px solid #313244;")
        h_lay = QHBoxLayout(header)
        h_lay.setContentsMargins(12, 0, 12, 0)
        h_lay.setSpacing(6)

        self.lbl_count = QLabel("Aucune offre")
        self.lbl_count.setStyleSheet("font-weight:600; color:#a6adc8;")
        h_lay.addWidget(self.lbl_count)
        h_lay.addStretch()

        self.combo_sort = QComboBox()
        self.combo_sort.setFixedWidth(140)
        self.combo_sort.addItems(["Pertinence", "Date ↓", "Entreprise A→Z", "Source"])
        self.combo_sort.currentIndexChanged.connect(self._on_sort_changed)
        h_lay.addWidget(QLabel("Trier :"))
        h_lay.addWidget(self.combo_sort)

        # Bouton afficher postulées (décoché = masquées, coché = affichées)
        self.btn_show_applied = QPushButton("✅ Postulées : 0")
        self.btn_show_applied.setCheckable(True)
        self.btn_show_applied.setChecked(False)  # masquées par défaut
        self.btn_show_applied.setFixedWidth(135)
        self.btn_show_applied.setStyleSheet(
            "QPushButton { background:#313244; color:#6c7086; border:1px solid #45475a; "
            "border-radius:6px; padding:4px 8px; font-size:11px; }"
            "QPushButton:checked { background:#a6e3a122; color:#a6e3a1; border-color:#a6e3a155; }"
        )
        self.btn_show_applied.toggled.connect(self._on_toggle_show_applied)
        h_lay.addWidget(self.btn_show_applied)

        # Bouton doublons
        self.btn_duplicates = QPushButton("Doublons : 0")
        self.btn_duplicates.setCheckable(True)
        self.btn_duplicates.setChecked(False)
        self.btn_duplicates.setFixedWidth(120)
        self.btn_duplicates.setStyleSheet(
            "QPushButton { background:#313244; color:#6c7086; border:1px solid #45475a; "
            "border-radius:6px; padding:4px 8px; font-size:11px; }"
            "QPushButton:checked { background:#f9e2af22; color:#f9e2af; border-color:#f9e2af55; }"
        )
        self.btn_duplicates.toggled.connect(self._on_toggle_duplicates)
        h_lay.addWidget(self.btn_duplicates)

        # Bouton afficher masquées
        self.btn_show_hidden = QPushButton("🙈 Masquées : 0")
        self.btn_show_hidden.setCheckable(True)
        self.btn_show_hidden.setChecked(False)
        self.btn_show_hidden.setFixedWidth(130)
        self.btn_show_hidden.setStyleSheet(
            "QPushButton { background:#313244; color:#6c7086; border:1px solid #45475a; "
            "border-radius:6px; padding:4px 8px; font-size:11px; }"
            "QPushButton:checked { background:#585b7022; color:#bac2de; border-color:#585b7055; }"
        )
        self.btn_show_hidden.toggled.connect(self._on_toggle_show_hidden)
        h_lay.addWidget(self.btn_show_hidden)
        layout.addWidget(header)

        # ── Filter bar ──
        filter_bar = QWidget()
        filter_bar.setFixedHeight(38)
        filter_bar.setStyleSheet("background-color:#1e1e2e; border-bottom:1px solid #313244;")
        f_lay = QHBoxLayout(filter_bar)
        f_lay.setContentsMargins(8, 0, 8, 0)
        self.input_filter = QLineEdit()
        self.input_filter.setPlaceholderText("Filtrer les résultats…")
        self.input_filter.setStyleSheet(
            "background:#181825; border:1px solid #313244; border-radius:4px; "
            "padding:4px 8px; color:#cdd6f4;"
        )
        self.input_filter.textChanged.connect(self._on_filter_changed)
        f_lay.addWidget(self.input_filter)
        layout.addWidget(filter_bar)

        # ── Liste ──
        self.list_widget = QListWidget()
        self.list_widget.setItemDelegate(JobCardDelegate())
        self.list_widget.setSpacing(2)
        self.list_widget.setUniformItemSizes(True)
        self.list_widget.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.list_widget.currentItemChanged.connect(self._on_item_changed)
        self.list_widget.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.list_widget.customContextMenuRequested.connect(self._on_context_menu)
        layout.addWidget(self.list_widget, 1)

    # ─── Public API ───────────────────────────────────────────────────────────

    def set_jobs(self, jobs: list) -> None:
        self._jobs = jobs
        self._run_dedup()

    def add_jobs(self, jobs: list) -> None:
        self._jobs.extend(jobs)
        self._run_dedup()

    def clear(self) -> None:
        self._jobs = []; self._unique = []; self._duplicates = []
        self._unique_object_ids = set()
        self.list_widget.clear()
        self.lbl_count.setText("Aucune offre")
        self.btn_duplicates.setText("Doublons : 0")
        self.btn_show_applied.setText("✅ Postulées : 0")
        self.btn_show_hidden.setText("🙈 Masquées : 0")

    def reload_applied(self) -> None:
        """Recharger les IDs des offres postulées depuis la DB (à appeler après candidature)."""
        self._reload_applied()
        self._apply_filter()

    def reload_hidden(self) -> None:
        """Recharger les IDs des offres masquées depuis la DB."""
        self._reload_hidden()
        self._apply_filter()

    # ─── Internal ─────────────────────────────────────────────────────────────

    def _reload_applied(self):
        try:
            import database.db_manager as db
            self._applied_ids = db.get_applied_job_ids()
        except Exception:
            self._applied_ids = set()
        self._update_applied_count()

    def _reload_hidden(self):
        try:
            import database.db_manager as db
            self._hidden_ids = db.get_hidden_job_ids()
        except Exception:
            self._hidden_ids = set()
        self._update_hidden_count()

    def _run_dedup(self) -> None:
        self._unique, self._duplicates = deduplicate(self._jobs)
        self._unique_object_ids = {id(j) for j in self._unique}
        n_dup = len(self._duplicates)
        self.btn_duplicates.setText(f"Doublons : {n_dup}")
        self.btn_duplicates.setEnabled(n_dup > 0)
        self._update_applied_count()
        self._update_hidden_count()
        self._apply_filter()

    def _render(self, jobs: list) -> None:
        self.list_widget.clear()
        for job in jobs:
            item = QListWidgetItem()
            item.setData(_ROLE_JOB, job)
            item.setData(_ROLE_IS_DUP, id(job) not in self._unique_object_ids)
            item.setData(_ROLE_APPLIED, job.id in self._applied_ids)
            item.setData(_ROLE_HIDDEN, job.id in self._hidden_ids)
            item.setSizeHint(QSize(0, JobCardDelegate.CARD_HEIGHT))
            self.list_widget.addItem(item)
        n = len(jobs)
        self.lbl_count.setText(f"{n} offre{'s' if n > 1 else ''} trouvée{'s' if n > 1 else ''}")

    def _apply_filter(self, sort_idx: int | None = None) -> None:
        base = self._jobs if self._show_duplicates else self._unique

        # Afficher les offres postulées seulement si le toggle est activé
        if not self._show_applied:
            base = [j for j in base if j.id not in self._applied_ids]

        # Afficher les offres masquées seulement si le toggle est activé
        if self._show_hidden:
            # Montrer tout, les masquées seront marquées visuellement
            pass
        else:
            base = [j for j in base if j.id not in self._hidden_ids]

        query = self.input_filter.text().lower().strip()
        filtered = list(base) if not query else [
            j for j in base
            if query in j.title.lower()
            or query in j.company.lower()
            or query in j.location.lower()
        ]

        # Tri
        idx = sort_idx if sort_idx is not None else self.combo_sort.currentIndex()
        if idx == 1:
            filtered.sort(key=lambda j: j.posted_date or "", reverse=True)
        elif idx == 2:
            filtered.sort(key=lambda j: j.company.lower())
        elif idx == 3:
            filtered.sort(key=lambda j: j.source)

        self._render(filtered)

    def _update_applied_count(self):
        """Met à jour le compteur d'offres postulées dans le bouton."""
        n = sum(1 for j in self._jobs if j.id in self._applied_ids)
        self.btn_show_applied.setText(f"✅ Postulées : {n}")
        self.btn_show_applied.setEnabled(n > 0)

    def _update_hidden_count(self):
        """Met à jour le compteur d'offres masquées dans le bouton."""
        n = sum(1 for j in self._jobs if j.id in self._hidden_ids)
        self.btn_show_hidden.setText(f"🙈 Masquées : {n}")
        self.btn_show_hidden.setEnabled(n > 0)

    def _on_toggle_duplicates(self, checked: bool) -> None:
        self._show_duplicates = checked
        self._apply_filter()

    def _on_toggle_show_applied(self, checked: bool) -> None:
        self._show_applied = checked
        self._apply_filter()

    def _on_toggle_show_hidden(self, checked: bool) -> None:
        self._show_hidden = checked
        self._apply_filter()

    def _on_filter_changed(self, _) -> None:
        self._apply_filter()

    def _on_sort_changed(self, idx: int) -> None:
        # Re-appliquer les filtres avec le nouveau tri
        self._apply_filter(sort_idx=idx)

    def _on_item_changed(self, current, _) -> None:
        if current:
            job: Job = current.data(_ROLE_JOB)
            if job: self.job_selected.emit(job)

    def _on_context_menu(self, pos: QPoint) -> None:
        from PyQt6.QtWidgets import QMenu
        item = self.list_widget.itemAt(pos)
        if not item: return
        job: Job = item.data(_ROLE_JOB)
        is_applied = job.id in self._applied_ids
        is_hidden  = job.id in self._hidden_ids

        menu = QMenu(self)

        if not is_applied:
            act_quick_tag = menu.addAction("🏷️  Marquer comme postulé")
            act_apply     = menu.addAction("📨  Postuler (envoyer candidature)")
            act_edit      = None
            act_unapply   = None
        else:
            act_quick_tag = None
            act_apply     = menu.addAction("📨  Postuler à nouveau")
            act_edit      = menu.addAction("✏️  Éditer la candidature")
            menu.addSeparator()
            act_unapply   = menu.addAction("❌  Retirer le tag 'postulé'")

        menu.addSeparator()

        # Masquer / Démasquer
        if is_hidden:
            act_hide   = None
            act_unhide = menu.addAction("👁️  Rendre visible")
        else:
            act_hide   = menu.addAction("🙈  Masquer cette offre")
            act_unhide = None

        menu.addSeparator()
        act_save = menu.addAction("⭐  Sauvegarder l'offre")
        act_open = menu.addAction("🌐  Ouvrir dans le navigateur")

        action = menu.exec(self.list_widget.mapToGlobal(pos))

        if act_quick_tag and action == act_quick_tag:
            self._on_quick_tag(job)

        elif action == act_apply:
            self.job_selected.emit(job)

        elif act_edit and action == act_edit:
            self._on_edit_application(job)

        elif action == act_save:
            self.save_job_requested.emit(job)

        elif action == act_open:
            import webbrowser; webbrowser.open(job.url)

        elif act_unapply and action == act_unapply:
            self._on_remove_applied_tag(job)

        elif act_hide and action == act_hide:
            self._on_hide_job(job)

        elif act_unhide and action == act_unhide:
            self._on_unhide_job(job)


    def _on_quick_tag(self, job: Job):
        """Émet application_changed → main_window ouvre le dialogue d'édition."""
        self.application_changed.emit(job)

    def _on_edit_application(self, job: Job):
        """Émet application_changed → main_window ouvre le dialogue d'édition."""
        self.application_changed.emit(job)

    def _on_hide_job(self, job: Job):
        """Masque une offre pour qu'elle n'apparaisse plus par défaut."""
        import database.db_manager as db
        db.hide_job(job.id)
        self._hidden_ids.add(job.id)
        self._update_hidden_count()
        self._apply_filter()

    def _on_unhide_job(self, job: Job):
        """Rend une offre masquée à nouveau visible."""
        import database.db_manager as db
        db.unhide_job(job.id)
        self._hidden_ids.discard(job.id)
        self._update_hidden_count()
        self._apply_filter()

    def _on_remove_applied_tag(self, job: Job):
        """Supprime la candidature liée (retire le tag 'postulé')."""
        from PyQt6.QtWidgets import QMessageBox
        import database.db_manager as db
        reply = QMessageBox.question(
            self, "Retirer le tag",
            f"Retirer le marquage 'postulé' pour :\n{job.title} — {job.company} ?\n\n"
            "(La candidature sera supprimée du suivi.)",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
        )
        if reply == QMessageBox.StandardButton.Yes:
            apps = db.get_applications()
            for a in apps:
                if a.job_id == job.id:
                    db.delete_application(a.id)
            self._reload_applied()
            self._apply_filter()
            self.application_changed.emit(job)


